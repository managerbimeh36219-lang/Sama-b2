# Sama Frontend (V2 - Phase B)

## اجرا
```bash
npm i
npm run dev
```

پروکسی بک‌اند:
- API: `/api/*` -> `http://localhost:8000/*`
- Static: `/static/*` -> `http://localhost:8000/static/*`
