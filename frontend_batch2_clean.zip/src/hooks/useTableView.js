import { useEffect, useMemo, useState } from 'react'
import { useUserSetting } from './useUserSetting'

// ذخیره تنظیمات جدول برای هر کاربر در دیتابیس (user_settings)
// view: { pageSize, dense }
export function useTableView(key, defaults = { pageSize: 20, dense: false }) {
  const setting = useUserSetting(key)
  const [local, setLocal] = useState(defaults)

  useEffect(() => {
    if (setting.data?.value) {
      try {
        const v = JSON.parse(setting.data.value)
        setLocal({ ...defaults, ...v })
      } catch {
        // ignore
      }
    }
  }, [setting.data])

  const save = async (next) => {
    const merged = { ...local, ...next }
    setLocal(merged)
    await setting.save(JSON.stringify(merged))
  }

  return useMemo(
    () => ({
      view: local,
      save,
      loading: setting.isLoading,
      saving: setting.saving,
    }),
    [local, setting.isLoading, setting.saving]
  )
}
