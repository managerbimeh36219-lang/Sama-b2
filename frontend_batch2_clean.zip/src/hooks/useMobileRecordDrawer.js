import React from 'react'

/**
 * Mobile record drawer controller
 */
export function useMobileRecordDrawer({ title = 'جزئیات', columns = [] } = {}) {
  const [isOpen, setIsOpen] = React.useState(false)
  const [record, setRecord] = React.useState(null)

  function open(record) {
    setRecord(record)
    setIsOpen(true)
  }

  function close() {
    setIsOpen(false)
  }

  return {
    title,
    columns,
    isOpen,
    record,
    open,
    close,
  }
}
