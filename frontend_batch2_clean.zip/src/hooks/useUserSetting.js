import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { getUserSetting, setUserSetting } from '../api/userSettings'

export function useUserSetting(key, { enabled = true } = {}) {
  const qc = useQueryClient()

  const q = useQuery({
    queryKey: ['user-setting', key],
    queryFn: () => getUserSetting(key),
    enabled: !!key && enabled,
    staleTime: 5 * 60 * 1000,
  })

  const m = useMutation({
    mutationFn: (value) => setUserSetting(key, value),
    onSuccess: (data) => {
      qc.setQueryData(['user-setting', key], data)
    },
  })

  return {
    ...q,
    save: (value) => m.mutateAsync(value),
    saving: m.isPending,
  }
}
