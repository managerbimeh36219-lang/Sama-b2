import { useEffect, useMemo, useState } from 'react'

// حفظ وضعیت صفحه تا زمانی که مرورگر بسته نشده (sessionStorage)
export function usePageState(key, initialState) {
  const storageKey = useMemo(() => `page_state:${key}`, [key])
  const [state, setState] = useState(() => {
    try {
      const raw = sessionStorage.getItem(storageKey)
      if (!raw) return initialState
      return { ...initialState, ...JSON.parse(raw) }
    } catch {
      return initialState
    }
  })

  useEffect(() => {
    try {
      sessionStorage.setItem(storageKey, JSON.stringify(state))
    } catch {}
  }, [storageKey, state])

  const reset = () => setState(initialState)

  return { state, setState, reset }
}
