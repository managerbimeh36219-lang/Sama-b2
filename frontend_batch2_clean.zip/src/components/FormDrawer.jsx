import React from 'react'
import { Drawer, Space, Button } from 'antd'

/**
 * Drawer استاندارد برای فرم‌های ویرایش/ایجاد
 * - Footer ثابت: انصراف / ذخیره
 * - width پیش‌فرض 520
 */
export default function FormDrawer({
  open,
  title,
  onClose,
  onSubmit,
  submitting = false,
  submitText = 'ثبت',
  cancelText = 'انصراف',
  width = 520,
  children,
}) {
  return (
    <Drawer
      open={open}
      title={title}
      onClose={onClose}
      width={width}
      destroyOnClose
      footer={
        <Space>
          <Button onClick={onClose}>{cancelText}</Button>
          <Button type="primary" onClick={onSubmit} loading={submitting}>
            {submitText}
          </Button>
        </Space>
      }
    >
      {children}
    </Drawer>
  )
}
