import React, { useMemo } from "react";
import DatePicker from "react-multi-date-picker";
import persian from "react-date-object/calendars/persian";
import persian_fa from "react-date-object/locales/persian_fa";

function normalizeDigits(s) {
  return (s || "")
    .replace(/[۰-۹]/g, (d) => "۰۱۲۳۴۵۶۷۸۹".indexOf(d))
    .replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d));
}

export default function JalaliDatePicker({
  value,
  onChange,
  placeholder = "تاریخ",
  style,
  disabled,
  min,
  max,
}) {
  const inputClass = useMemo(
    () => "ant-input" + (disabled ? " ant-input-disabled" : ""),
    [disabled]
  );

  return (
    <DatePicker
      value={value || ""}
      onChange={(v) => {
        if (!v) return onChange?.("");
        const s = typeof v === "string" ? v : v.format?.("YYYY/MM/DD");
        onChange?.(normalizeDigits(s || ""));
      }}
      calendar={persian}
      locale={persian_fa}
      format="YYYY/MM/DD"
      editable
      inputClass={inputClass}
      placeholder={placeholder}
      style={style}
      disabled={disabled}
      minDate={min}
      maxDate={max}
      calendarPosition="bottom-right"
      portal
      portalTarget={typeof document !== 'undefined' ? document.body : undefined}
      zIndex={9999}
      containerStyle={{ zIndex: 9999 }}
    />
  );
}
