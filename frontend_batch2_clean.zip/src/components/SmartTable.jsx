import React, { useMemo, useState } from 'react'
import { Button, Dropdown, Space, Switch, Table, Tooltip, Typography } from 'antd'
import { SettingOutlined, ReloadOutlined, SaveOutlined } from '@ant-design/icons'

/**
 * SmartTable
 * - Sticky header + controlled scroll
 * - Column show/hide
 * - Save/Reset view via callbacks
 */
export default function SmartTable({
  tableKey,
  columns,
  dataSource,
  loading,
  rowKey = 'id',
  pagination,
  onChange,
  view,
  onSaveView,
  onResetView,
  mobileDrawer,
  ...rest
}) {
  const [dense, setDense] = useState(view?.dense ?? false)

  const normalizedColumns = useMemo(() => {
    const hidden = new Set(view?.hiddenColumns || [])
    return (columns || []).filter((c) => !hidden.has(c.key || c.dataIndex))
  }, [columns, view])

  const allCols = useMemo(() => {
    return (columns || []).map((c) => ({
      key: c.key || c.dataIndex,
      title: typeof c.title === 'string' ? c.title : String(c.title || ''),
    }))
  }, [columns])

  const menuItems = useMemo(() => {
    const hidden = new Set(view?.hiddenColumns || [])
    return [
      {
        key: 'dense',
        label: (
          <Space style={{ width: '100%', justifyContent: 'space-between' }}>
            <span>حالت فشرده</span>
            <Switch checked={dense} onChange={setDense} />
          </Space>
        ),
      },
      { type: 'divider' },
      ...allCols.map((c) => ({
        key: `col:${c.key}`,
        label: (
          <Space style={{ width: '100%', justifyContent: 'space-between' }}>
            <span style={{ maxWidth: 220, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.title}</span>
            <Switch
              checked={!hidden.has(c.key)}
              onChange={(checked) => {
                const next = new Set(view?.hiddenColumns || [])
                if (checked) next.delete(c.key)
                else next.add(c.key)
                onSaveView?.({
                  ...(view || {}),
                  dense,
                  hiddenColumns: Array.from(next),
                })
              }}
            />
          </Space>
        ),
      })),
      { type: 'divider' },
      {
        key: 'save',
        icon: <SaveOutlined />,
        label: 'ذخیره همین نما',
        onClick: () => onSaveView?.({ ...(view || {}), dense }),
      },
      {
        key: 'reset',
        icon: <ReloadOutlined />,
        label: 'بازگشت به حالت پیش‌فرض',
        onClick: () => onResetView?.(),
      },
    ]
  }, [allCols, view, onSaveView, onResetView, dense])

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <Typography.Text type="secondary">نمای جدول: {tableKey}</Typography.Text>
        <Space>
          <Tooltip title="تنظیمات جدول">
            <Dropdown menu={{ items: menuItems }} trigger={['click']} placement="bottomRight">
              <Button icon={<SettingOutlined />} />
            </Dropdown>
          </Tooltip>
        </Space>
      </div>

      <Table
        size={dense ? 'small' : 'middle'}
        sticky
        columns={normalizedColumns}
        dataSource={dataSource}
        loading={loading}
        rowKey={rowKey}
        pagination={pagination}
        onChange={onChange}
        scroll={{ x: 'max-content' }}
        {...rest}
        onRow={
          mobileDrawer
            ? (record) => ({
                onClick: () => mobileDrawer.open(record),
                style: { cursor: 'pointer' },
              })
            : undefined
        }
      />
    </div>
  )
}
