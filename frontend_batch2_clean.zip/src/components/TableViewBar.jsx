import React from 'react'
import { Space, Select, Switch, Typography } from 'antd'

export default function TableViewBar({ view, onChange }) {
  return (
    <Space wrap>
      <Space>
        <Typography.Text type="secondary">سایز صفحه:</Typography.Text>
        <Select
          size="small"
          value={view.pageSize}
          onChange={(v) => onChange({ pageSize: v })}
          options={[10, 20, 30, 50, 100].map((n) => ({ value: n, label: n }))}
          style={{ width: 90 }}
        />
      </Space>

      <Space>
        <Typography.Text type="secondary">فشرده:</Typography.Text>
        <Switch size="small" checked={!!view.dense} onChange={(v) => onChange({ dense: v })} />
      </Space>
    </Space>
  )
}
