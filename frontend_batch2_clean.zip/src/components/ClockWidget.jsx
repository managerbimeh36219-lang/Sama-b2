import React, { useEffect, useMemo, useState } from 'react'
import dayjs from 'dayjs'
import jalaliday from 'jalaliday'

dayjs.extend(jalaliday)

function pad(n){return String(n).padStart(2,'0')}

export default function ClockWidget(){
  const [now, setNow] = useState(() => new Date())
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(t)
  }, [])

  const d = useMemo(() => dayjs(now).calendar('jalali'), [now])
  const time = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`

  const sec = now.getSeconds()
  const min = now.getMinutes() + sec/60
  const hr = (now.getHours()%12) + min/60

  const secDeg = sec * 6
  const minDeg = min * 6
  const hrDeg = hr * 30

  return (
    <div style={{display:'flex', gap:16, alignItems:'center'}}>
      <div style={{width:86, height:86, borderRadius:24, position:'relative',
        background:'linear-gradient(180deg, rgba(255,255,255,.12), rgba(255,255,255,.06))',
        boxShadow:'0 10px 22px rgba(0,0,0,.35), inset 0 1px 0 rgba(255,255,255,.2)'
      }}>
        <div style={{position:'absolute', inset:10, borderRadius:18, border:'1px solid rgba(255,255,255,.12)'}} />
        <div style={{position:'absolute', left:'50%', top:'50%', width:2, height:24, background:'rgba(255,255,255,.85)', transform:`translate(-50%,-100%) rotate(${hrDeg}deg)`, transformOrigin:'50% 100%', borderRadius:2}} />
        <div style={{position:'absolute', left:'50%', top:'50%', width:2, height:30, background:'rgba(255,255,255,.65)', transform:`translate(-50%,-100%) rotate(${minDeg}deg)`, transformOrigin:'50% 100%', borderRadius:2}} />
        <div style={{position:'absolute', left:'50%', top:'50%', width:1, height:34, background:'rgba(255,100,120,.95)', transform:`translate(-50%,-100%) rotate(${secDeg}deg)`, transformOrigin:'50% 100%', borderRadius:2}} />
        <div style={{position:'absolute', left:'50%', top:'50%', width:8, height:8, borderRadius:999, background:'rgba(255,255,255,.9)', transform:'translate(-50%,-50%)'}} />
      </div>
      <div>
        <div style={{fontSize:18, fontWeight:800}}>{time}</div>
        <div style={{opacity:.8}}>{d.format('YYYY/MM/DD')}</div>
      </div>
    </div>
  )
}
