import React from 'react';
import { Modal, Image, Typography } from 'antd';

function isImage(mimeType = '', url = '') {
  const m = (mimeType || '').toLowerCase();
  if (m.startsWith('image/')) return true;
  return /\.(png|jpe?g|webp|gif|bmp|svg)(\?|#|$)/i.test(url || '');
}

function isPdf(mimeType = '', url = '') {
  const m = (mimeType || '').toLowerCase();
  if (m === 'application/pdf') return true;
  return /\.(pdf)(\?|#|$)/i.test(url || '');
}

export default function FilePreviewModal({ open, url, title, mimeType, onClose }) {
  return (
    <Modal
      open={!!open}
      title={title || 'پیش‌نمایش فایل'}
      onCancel={onClose}
      onOk={onClose}
      okText="بستن"
      cancelButtonProps={{ style: { display: 'none' } }}
      width={900}
      bodyStyle={{ paddingTop: 8 }}
      destroyOnClose
    >
      {!url ? (
        <Typography.Text type="secondary">فایلی برای نمایش انتخاب نشده است.</Typography.Text>
      ) : isImage(mimeType, url) ? (
        <div style={{ textAlign: 'center' }}>
          <Image
            src={url}
            alt={title || 'preview'}
            style={{ maxHeight: '70vh', objectFit: 'contain' }}
            preview={{
              // آنت دیزاین خودش Zoom/Rotate را ارائه می‌دهد
              mask: 'بزرگ‌نمایی / چرخش',
            }}
          />
        </div>
      ) : isPdf(mimeType, url) ? (
        <iframe
          title={title || 'pdf-preview'}
          src={url}
          style={{ width: '100%', height: '70vh', border: 'none' }}
        />
      ) : (
        <Typography.Text>
          پیش‌نمایش برای این نوع فایل فعال نیست. از گزینه دانلود استفاده کنید.
        </Typography.Text>
      )}
    </Modal>
  );
}
