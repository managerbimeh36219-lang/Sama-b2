import React, { useMemo } from 'react'
import { Drawer, Descriptions, Typography } from 'antd'

function safeRender(col, value, record) {
  try {
    if (typeof col.render === 'function') return col.render(value, record)
  } catch {
    // ignore
  }
  return value == null ? '' : String(value)
}

export default function MobileRecordDrawer({ controller }) {
  const { isOpen, close, record, title, columns } = controller || {}

  const items = useMemo(() => {
    if (!record) return []
    return (columns || [])
      .filter((c) => !!(c && (c.dataIndex || c.key) && c.title))
      .map((c) => {
        const key = c.key || (Array.isArray(c.dataIndex) ? c.dataIndex.join('.') : c.dataIndex)
        const value = Array.isArray(c.dataIndex)
          ? c.dataIndex.reduce((acc, k) => (acc ? acc[k] : undefined), record)
          : record[c.dataIndex]

        return {
          key,
          label: typeof c.title === 'string' ? c.title : String(c.title || ''),
          children: (
            <Typography.Text style={{ wordBreak: 'break-word' }}>
              {safeRender(c, value, record)}
            </Typography.Text>
          ),
        }
      })
  }, [record, columns])

  return (
    <Drawer open={!!isOpen} onClose={close} placement="bottom" height="75vh" title={title || 'جزئیات'}>
      <Descriptions column={1} bordered size="small" items={items} />
    </Drawer>
  )
}
