import React, { useEffect, useState } from "react";
import { Image, Spin } from "antd";

import { fetchFileBlob, blobToObjectUrl } from "../utils/fileAccess";

// نمایش تصویر با دریافت Blob (برای اینکه لینک مستقیم بدون هدرِ Authorization شکسته نشود)
// نکته: بعضی صفحات قدیمی prop را با نام `url` پاس می‌دهند؛ هر دو پشتیبانی می‌شود.
export default function AuthenticatedImage({ fileUrl, url, alt, style, width, height, previewMask }) {
  const [src, setSrc] = useState(null);
  const finalUrl = fileUrl || url;

  useEffect(() => {
    let objectUrl = null;
    let cancelled = false;

    (async () => {
      try {
        const blob = await fetchFileBlob(finalUrl);
        if (cancelled) return;
        objectUrl = blobToObjectUrl(blob);
        setSrc(objectUrl);
      } catch {
        // ignore
      }
    })();

    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [finalUrl]);

  if (!finalUrl) return null;
  if (!src) return <Spin size="small" />;

  return (
    <Image
      src={src}
      alt={alt}
      width={width}
      height={height}
      style={style}
      // AntD preview شامل زوم/چرخش/… است
      preview={{ mask: previewMask || "پیش‌نمایش (زوم)" }}
    />
  );
}
