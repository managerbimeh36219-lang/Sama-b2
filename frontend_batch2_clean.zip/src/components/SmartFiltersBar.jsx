import React from 'react'
import { Card, Input, Space, Typography, Tooltip } from 'antd'

/**
 * نوار جستجوی سراسری (شبیه Ctrl+F)
 * - بدون دکمه Apply
 * - والد می‌تواند debounce کند
 */
export default function SmartFiltersBar({ title, value, onChange, hint, right }) {
  return (
    <Card className="sama-card" size="small" styles={{ body: { padding: 10 } }}>
      <Space style={{ width: '100%', justifyContent: 'space-between' }} wrap>
        <Space size={10} wrap style={{ flex: 1 }}>
          <Typography.Text style={{ fontWeight: 900, fontSize: 14 }}>
            {title}
          </Typography.Text>

          <Input
            value={value}
            onChange={(e) => onChange?.(e.target.value)}
            allowClear
            placeholder="جستجو..."
            style={{ minWidth: 260, flex: 1 }}
          />

          {hint ? (
            <Tooltip title={hint}>
              <Typography.Text type="secondary" style={{ fontSize: 12, cursor: 'help' }}>
                راهنما
              </Typography.Text>
            </Tooltip>
          ) : null}
        </Space>

        {right || null}
      </Space>
    </Card>
  )
}
