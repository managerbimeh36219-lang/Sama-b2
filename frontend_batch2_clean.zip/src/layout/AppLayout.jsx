import React, { useMemo, useState } from 'react'
import { Layout, Menu, Button, Dropdown, Space, Typography, Badge, List } from 'antd'
import {
  DashboardOutlined, CheckCircleOutlined,
  ClockCircleOutlined,
  ExclamationCircleOutlined, FileTextOutlined, DollarOutlined, SyncOutlined, BookOutlined,
  AlertOutlined, MessageOutlined, SettingOutlined, QuestionCircleOutlined,
  DesktopOutlined, TabletOutlined, MobileOutlined, BellOutlined, FilePdfOutlined,
  UploadOutlined
} from '@ant-design/icons'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { useAppStore } from '../store/appStore'
import { useQuery } from '@tanstack/react-query'
import { getHeaderStats } from '../api/header'

const { Header, Sider, Content } = Layout

function I({icon}){return <span className="icon-3d">{icon}</span>}

function DigitalHeaderClock(){
  const [now, setNow] = React.useState(new Date())
  React.useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(t)
  }, [])
  const hh = String(now.getHours()).padStart(2, '0')
  const mm = String(now.getMinutes()).padStart(2, '0')
  const ss = String(now.getSeconds()).padStart(2, '0')
  const date = now.toLocaleDateString('fa-IR', { year: 'numeric', month: '2-digit', day: '2-digit' })
  return (
    <div style={{ textAlign: 'center', lineHeight: 1.2 }}>
      <div style={{ fontWeight: 900, fontSize: 16 }}>{hh}:{mm}:{ss}</div>
      <div style={{ fontSize: 12, opacity: .75 }}>{date}</div>
    </div>
  )
}

export default function AppLayout({ children }){
  const loc = useLocation()
  const nav = useNavigate()
  const { user, ui, viewport, setViewport } = useAppStore()
  const [collapsed, setCollapsed] = useState(false)

  const isMarketer = user?.user_type === 'marketer'
  const isCustomer = user?.user_type === 'customer'


  const { data: stats } = useQuery({
    queryKey: ['headerStats'],
    queryFn: getHeaderStats,
    refetchInterval: 15000,
  })


  const menuLabel = (to, title, count) => (
    <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
      <Link to={to} style={{ flex: 1 }}>{title}</Link>
      {count ? <Badge count={count} size="small" overflowCount={99} /> : null}
    </span>
  )

  const items = useMemo(() => {
    // Customer: show only customer portal + guide (avoid admin pages that may 403)
    if (isCustomer) {
      return [
        { key:'/customer', icon:<I icon={<DashboardOutlined />} />, label:<Link to="/customer">پنل مشتری</Link> },
        { key:'/guide', icon:<I icon={<QuestionCircleOutlined />} />, label:<Link to="/guide">راهنما</Link> },
      ]
    }

    const main = [
      { key:'/dashboard', icon:<I icon={<DashboardOutlined />} />, label:<Link to="/dashboard">داشبورد</Link> },
      { key:'/requests', icon:<I icon={<MessageOutlined />} />, label: menuLabel('/requests', 'کارتابل', stats?.requests_unread || 0) },

      // فقط مدیر/کاربر داخلی
      !isMarketer && !isCustomer ? { key:'/import', icon:<I icon={<UploadOutlined />} />, label:<Link to="/import">ایمپورت</Link> } : null,

      { key:'/policies', icon:<I icon={<FileTextOutlined />} />, label:<Link to="/policies">بیمه‌نامه‌ها</Link> },
      { key:'/installments', icon:<I icon={<DollarOutlined />} />, label:<Link to="/installments">اقساط</Link> },
      !isMarketer && !isCustomer ? { key:'/receipts-review', icon:<I icon={<CheckCircleOutlined />} />, label: menuLabel('/receipts-review', 'رسیدهای مشتری', stats?.pending_receipts || 0) } : null,
      { key:'/renewals', icon:<I icon={<SyncOutlined />} />, label:<Link to="/renewals">تمدید</Link> },
      { key:'/docs', icon:<I icon={<BookOutlined />} />, label:<Link to="/docs">مستندات</Link> },
      { key:'/circulars', icon:<I icon={<FilePdfOutlined />} />, label: menuLabel('/circulars', 'بخشنامه‌ها', stats?.circulars_unread || 0) },
      {!isMarketer && !isCustomer ? { key:'/debts', icon:<I icon={<AlertOutlined />} />, label:<Link to="/debts">بدهی</Link> } : null,
      { key:'/tasks', icon:<I icon={<BookOutlined />} />, label: menuLabel('/tasks', 'وظایف', stats?.tasks_today || 0) },
      {!isMarketer && !isCustomer ? { key:'/sms', icon:<I icon={<MessageOutlined />} />, label: menuLabel('/sms', 'پیامک', stats?.sms_in_24h || 0) } : null,
      {!isMarketer && !isCustomer ? { key:'/commissions', icon:<I icon={<DollarOutlined />} />, label:<Link to="/commissions">کارمزد</Link> } : null,
      { key:'/guide', icon:<I icon={<QuestionCircleOutlined />} />, label:<Link to="/guide">راهنما</Link> },
    ].filter(Boolean)

    if (!isMarketer && !isCustomer) {
      main.push({
        key:'/settings',
        icon:<I icon={<SettingOutlined />} />,
        label:'تنظیمات',
        children: [
          { key:'/settings/ui', label:<Link to="/settings/ui">تم و رنگ</Link> },
          { key:'/settings/users', label:<Link to="/settings/users">کاربران</Link> },
          { key:'/settings/marketers', label:<Link to="/settings/marketers">بازاریابان</Link> },
          { key:'/settings/checklist', label:<Link to="/settings/checklist">چک‌لیست مستندات</Link> },
          { key:'/settings/lines', label:<Link to="/settings/lines">تعریف رشته‌های بیمه</Link> },
          { key:'/settings/rates', label:<Link to="/settings/rates">نرخ‌ها</Link> },
          { key:'/settings/financial', label:<Link to="/settings/financial">تنظیمات مالی</Link> },
          { key:'/settings/backup', label:<Link to="/settings/backup">بکاپ</Link> },
        ]
      })
    }

    return main
  }, [isCustomer, isMarketer, stats])

  const selectedKey = useMemo(() => {
    const p = loc.pathname
    if (p.startsWith('/settings')) return '/settings'
    return p
  }, [loc.pathname])

  const viewportMenu = [
    { key:'desktop', icon:<DesktopOutlined />, label:'Desktop' },
    { key:'tablet', icon:<TabletOutlined />, label:'Tablet' },
    { key:'mobile', icon:<MobileOutlined />, label:'Mobile' },
  ]

  const notifCount = (stats?.requests_unread || 0) + (stats?.notifications_unread || 0) + (stats?.tasks_today || 0) + (stats?.sms_in_24h || 0) + (stats?.circulars_unread || 0) + (stats?.pending_receipts || 0)

  const notifList = [
    { key: 'requests', title: 'کارتابل (خوانده‌نشده)', value: stats?.requests_unread || 0, link: '/requests' },
    { key: 'circulars', title: 'بخشنامه‌های جدید', value: stats?.circulars_unread || 0, link: '/circulars' },
    { key: 'tasks', title: 'وظایف امروز', value: stats?.tasks_today || 0, link: '/tasks' },
    { key: 'receipts', title: 'رسیدهای مشتری (منتظر تایید)', value: stats?.pending_receipts || 0, link: '/receipts-review' },
    { key: 'sms', title: 'پیامک‌های دریافتی ۲۴ ساعت اخیر', value: stats?.sms_in_24h || 0, link: '/sms' },
    { key: 'notifs', title: 'اعلان‌های شخصی (خوانده‌نشده)', value: stats?.notifications_unread || 0, link: '/notifications' },
  ]

  const notifDropdown = {
    items: [
      {
        key: 'list',
        label: (
          <div style={{ width: 320 }}>
            <Typography.Text style={{ fontWeight: 800 }}>اعلان‌ها</Typography.Text>
            <List
              size="small"
              dataSource={notifList}
              renderItem={(it) => (
                <List.Item
                  style={{ cursor: 'pointer' }}
                  onClick={() => nav(it.link)}
                  actions={[<span key="v" style={{ fontWeight: 900 }}>{it.value}</span>]}
                >
                  <List.Item.Meta title={it.title} />
                </List.Item>
              )}
            />
          </div>
        )
      }
    ]
  }

  const siderBg = ui?.sidebar_bg || undefined
  const headerBg = ui?.header_bg || undefined
  const contentBg = ui?.content_bg || undefined
  const textColor = ui?.text_color || undefined
  const borderColor = ui?.border_color || undefined
  const effectiveTheme = ui?.theme === 'light' ? 'light' : 'dark'
  const effectiveText = textColor || (effectiveTheme === 'light' ? '#111' : '#fff')

  return (
    <Layout style={{ minHeight:'100vh', background: contentBg }}>
      <Sider
        collapsible
        collapsed={collapsed}
        onCollapse={setCollapsed}
        width={260}
        theme={effectiveTheme}
        style={{ background: siderBg, borderLeft: borderColor ? `1px solid ${borderColor}` : undefined }}
      >
        <div style={{padding:12, display:'flex', alignItems:'center', gap:10}}>
          {ui?.logo_url ? (
            <img src={ui.logo_url} alt="SAMA" style={{height:32, objectFit:'contain'}} />
          ) : (
            <Typography.Text style={{color: effectiveText, fontWeight:900}}>SAMA</Typography.Text>
          )}
        </div>
        <Menu
          mode="inline"
          theme={effectiveTheme}
          selectedKeys={[selectedKey]}
          defaultOpenKeys={['/settings']}
          items={items}
          style={{ borderInlineEnd:0, background: siderBg }}
        />
      </Sider>
      <Layout>
        <Header style={{display:'flex', alignItems:'center', justifyContent:'space-between', padding:'0 12px', background: headerBg, borderBottom: borderColor ? `1px solid ${borderColor}` : undefined }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, minWidth: 220 }}>
            <Typography.Text style={{color: effectiveText, fontWeight:800}}>
              {user?.user_type === 'admin' ? 'مدیر' : (user?.user_type === 'marketer' ? 'بازاریاب' : (user?.user_type === 'customer' ? 'مشتری' : 'کاربر'))}
              {user?.full_name ? ` — ${user.full_name}` : ''}
            </Typography.Text>
          </div>

          <div style={{ flex: 1, display:'flex', justifyContent:'center' }}>
            <DigitalHeaderClock />
          </div>

          <Space style={{ minWidth: 260, justifyContent:'flex-end' }}>
            <Dropdown menu={notifDropdown} placement="bottomRight" trigger={['click']}>
              <Badge count={notifCount} size="small" overflowCount={99}>
                <Button size="small" icon={<BellOutlined />} />
              </Badge>
            </Dropdown>
            <Dropdown
              menu={{ items: viewportMenu, onClick: ({ key }) => setViewport(key), selectedKeys:[viewport] }}
              placement="bottomRight"
            >
              <Button size="small">نمایش: {viewport}</Button>
            </Dropdown>
            <Button size="small" danger onClick={() => { localStorage.removeItem('token'); nav('/login') }}>خروج</Button>
          </Space>
        </Header>
        <Content style={{padding:12, background: contentBg, color: effectiveText}}>
          <div className={`viewport-preview viewport-${viewport}`}>
            {children}
          </div>
        </Content>
      </Layout>
    </Layout>
  )
}
