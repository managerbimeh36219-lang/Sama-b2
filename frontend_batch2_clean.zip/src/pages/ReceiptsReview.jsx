import React, { useMemo, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Button, Card, Input, Modal, Space, Table, Tag, Typography, message } from 'antd'
import { CheckOutlined, CloseOutlined, EyeOutlined, DownloadOutlined, ReloadOutlined } from '@ant-design/icons'
import { downloadReceiptAttachmentBlob, listPendingReceipts, reviewReceipt } from '../api/installments'

function fmtNum(n) {
  try {
    if (n === null || n === undefined) return ''
    return String(Number(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  } catch {
    return String(n ?? '')
  }
}

function statusTag(status) {
  if (status === 'pending') return <Tag color="gold">منتظر تایید</Tag>
  if (status === 'approved') return <Tag color="green">تایید شده</Tag>
  if (status === 'rejected') return <Tag color="red">رد شده</Tag>
  return <Tag>نامشخص</Tag>
}

export default function ReceiptsReview() {
  const qc = useQueryClient()
  const [q, setQ] = useState('')
  const [preview, setPreview] = useState({ open: false, url: null, title: '', isPdf: false })
  const [rejectModal, setRejectModal] = useState({ open: false, row: null, note: '' })

  const listQ = useQuery({
    queryKey: ['pendingReceipts'],
    queryFn: () => listPendingReceipts(),
  })

  const reviewMut = useMutation({
    mutationFn: ({ id, status, note }) => reviewReceipt(id, { status, note }),
    onSuccess: () => {
      message.success('ثبت شد')
      qc.invalidateQueries({ queryKey: ['pendingReceipts'] })
      qc.invalidateQueries({ queryKey: ['headerStats'] })
      qc.invalidateQueries({ queryKey: ['dashboardKpi'] })
    },
    onError: (e) => message.error(e?.response?.data?.detail || 'خطا در ثبت'),
  })

  const rows = listQ.data || []

  const filtered = useMemo(() => {
    const needle = (q || '').trim().toLowerCase()
    if (!needle) return rows
    return rows.filter((r) => {
      const hay = [
        r.policy_number,
        r.policyholder_name,
        r.mobile,
        r.insurance_line,
        r.description,
        r.paid_date_j,
      ]
        .filter(Boolean)
        .join(' | ')
        .toLowerCase()
      return hay.includes(needle)
    })
  }, [rows, q])

  async function openPreview(row) {
    if (!row.attachment_id) return message.warning('فایل رسید وجود ندارد')
    try {
      const blob = await downloadReceiptAttachmentBlob(row.attachment_id)
      const url = URL.createObjectURL(blob)
      const name = row.attachment_name || `receipt_${row.id}`
      const isPdf = String(name).toLowerCase().endsWith('.pdf')
      setPreview({ open: true, url, title: name, isPdf })
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در دریافت فایل')
    }
  }

  async function downloadFile(row) {
    if (!row.attachment_id) return message.warning('فایل رسید وجود ندارد')
    try {
      const blob = await downloadReceiptAttachmentBlob(row.attachment_id)
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = row.attachment_name || `receipt_${row.id}`
      document.body.appendChild(a)
      a.click()
      a.remove()
      setTimeout(() => URL.revokeObjectURL(url), 5000)
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در دانلود فایل')
    }
  }

  const columns = [
    {
      title: 'بیمه‌نامه',
      dataIndex: 'policy_number',
      width: 150,
      render: (v, r) => (
        <Space direction="vertical" size={0}>
          <Typography.Text strong>{v || '—'}</Typography.Text>
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>{r.insurance_line || ''}</Typography.Text>
        </Space>
      ),
    },
    {
      title: 'بیمه‌گذار',
      dataIndex: 'policyholder_name',
      width: 180,
      render: (v, r) => (
        <Space direction="vertical" size={0}>
          <Typography.Text>{v || '—'}</Typography.Text>
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>{r.mobile || ''}</Typography.Text>
        </Space>
      ),
    },
    {
      title: 'مبلغ',
      dataIndex: 'amount_rial',
      width: 130,
      align: 'right',
      render: (v) => fmtNum(v),
    },
    {
      title: 'تاریخ پرداخت',
      dataIndex: 'paid_date_j',
      width: 120,
      render: (v) => v || '—',
    },
    {
      title: 'پیام مشتری',
      dataIndex: 'description',
      render: (v) => v ? v : '—',
    },
    {
      title: 'وضعیت',
      key: 'status',
      width: 120,
      render: () => statusTag('pending'),
    },
    {
      title: 'عملیات',
      key: 'actions',
      fixed: 'left',
      width: 280,
      render: (_, row) => (
        <Space>
          <Button size="small" icon={<EyeOutlined />} onClick={() => openPreview(row)}>نمایش</Button>
          <Button size="small" icon={<DownloadOutlined />} onClick={() => downloadFile(row)}>دانلود</Button>
          <Button
            size="small"
            type="primary"
            icon={<CheckOutlined />}
            loading={reviewMut.isPending && reviewMut.variables?.id === row.id}
            onClick={() => reviewMut.mutate({ id: row.id, status: 'approved' })}
          >
            تایید
          </Button>
          <Button
            size="small"
            danger
            icon={<CloseOutlined />}
            onClick={() => setRejectModal({ open: true, row, note: '' })}
          >
            رد
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <Space direction="vertical" style={{ width: '100%' }}>
      <Card
        title="رسیدهای مشتری (منتظر تایید)"
        extra={
          <Space>
            <Input
              allowClear
              placeholder="جستجو: شماره بیمه‌نامه/نام/موبایل..."
              value={q}
              onChange={(e) => setQ(e.target.value)}
              style={{ width: 320 }}
            />
            <Button icon={<ReloadOutlined />} onClick={() => listQ.refetch()} loading={listQ.isFetching}>رفرش</Button>
          </Space>
        }
      >
        <Table
          rowKey="id"
          columns={columns}
          dataSource={filtered}
          loading={listQ.isFetching}
          pagination={{ pageSize: 20 }}
          tableLayout="fixed"
        />
        <Typography.Text type="secondary" style={{ fontSize: 12 }}>
          نکته: فقط پس از «تایید»، مبلغ رسید در تسویه قسط لحاظ می‌شود.
        </Typography.Text>
      </Card>

      <Modal
        open={preview.open}
        onCancel={() => {
          if (preview.url) URL.revokeObjectURL(preview.url)
          setPreview({ open: false, url: null, title: '', isPdf: false })
        }}
        footer={null}
        width={920}
        title={preview.title || 'پیش‌نمایش رسید'}
        destroyOnClose
      >
        {preview.url ? (
          preview.isPdf ? (
            <iframe title="preview" src={preview.url} style={{ width: '100%', height: '75vh', border: 'none' }} />
          ) : (
            <img alt="preview" src={preview.url} style={{ width: '100%', maxHeight: '75vh', objectFit: 'contain' }} />
          )
        ) : null}
      </Modal>

      <Modal
        open={rejectModal.open}
        onCancel={() => setRejectModal({ open: false, row: null, note: '' })}
        title="رد رسید"
        okText="ثبت رد"
        cancelText="انصراف"
        okButtonProps={{ danger: true, loading: reviewMut.isPending }}
        onOk={() => {
          if (!rejectModal.row) return
          reviewMut.mutate({ id: rejectModal.row.id, status: 'rejected', note: rejectModal.note || undefined })
          setRejectModal({ open: false, row: null, note: '' })
        }}
      >
        <Typography.Text>در صورت نیاز، دلیل رد را وارد کن:</Typography.Text>
        <Input.TextArea
          rows={4}
          value={rejectModal.note}
          onChange={(e) => setRejectModal((s) => ({ ...s, note: e.target.value }))}
          placeholder="مثلاً: مبلغ/تاریخ ناخوانا است..."
          style={{ marginTop: 10 }}
        />
      </Modal>
    </Space>
  )
}
