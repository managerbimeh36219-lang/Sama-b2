import React, { useEffect, useMemo, useState } from 'react'
import { Card, Form, Input, Switch, Button, Space, Typography, Upload, Divider, Tag, App as AntdApp } from 'antd'
import { UploadOutlined } from '@ant-design/icons'
import { getUi, setUi, uploadLoginBackground } from '../api/settings'

const { Title, Text } = Typography

function ColorPicker({ value, onChange }) {
  return (
    <Space>
      <input
        type="color"
        value={value || '#1677ff'}
        onChange={(e) => onChange?.(e.target.value)}
        style={{ width: 48, height: 32, border: 'none', background: 'transparent', padding: 0 }}
      />
      <Input
        value={value}
        onChange={(e) => onChange?.(e.target.value)}
        placeholder="#1677ff"
        style={{ width: 140 }}
      />
    </Space>
  )
}

const PRESETS = [
  {
    key: 'sama_dark',
    title: 'سما (دارک)',
    values: {
      theme: false,
      accent_color: '#1677ff',
      header_bg: '#0f172a',
      sidebar_bg: '#0b1220',
      content_bg: '#0b1220',
      text_color: '#e5e7eb',
      border_color: '#1f2937',
    },
  },
  {
    key: 'classic_blue',
    title: 'آبی کلاسیک',
    values: {
      theme: true,
      accent_color: '#1677ff',
      header_bg: '#ffffff',
      sidebar_bg: '#f5f7fb',
      content_bg: '#f5f7fb',
      text_color: '#111827',
      border_color: '#e5e7eb',
    },
  },
  {
    key: 'emerald',
    title: 'سبز رسمی',
    values: {
      theme: true,
      accent_color: '#10b981',
      header_bg: '#ffffff',
      sidebar_bg: '#f7fbf9',
      content_bg: '#f7fbf9',
      text_color: '#0f172a',
      border_color: '#d1fae5',
    },
  },
  {
    key: 'gold_dark',
    title: 'طلایی (دارک)',
    values: {
      theme: false,
      accent_color: '#f59e0b',
      header_bg: '#111827',
      sidebar_bg: '#0b1220',
      content_bg: '#0b1220',
      text_color: '#f9fafb',
      border_color: '#374151',
    },
  },
]

export default function SettingsUi() {
  const { message } = AntdApp.useApp()
  const [form] = Form.useForm()
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)

  const load = async () => {
    setLoading(true)
    try {
      const d = await getUi()
      form.setFieldsValue({
        theme: d.theme === 'light',
        accent_color: d.accent_color || '#1677ff',
        logo_url: d.logo_url || '',
        login_background_url: d.login_background_url || '',
        header_bg: d.header_bg || '',
        sidebar_bg: d.sidebar_bg || '',
        content_bg: d.content_bg || '',
        text_color: d.text_color || '',
        border_color: d.border_color || '',
      })
    } catch (e) {
      message.error('خطا در دریافت تنظیمات')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const presetsUi = useMemo(() => (
    <Space wrap>
      {PRESETS.map(p => (
        <Button key={p.key} onClick={() => {
          form.setFieldsValue(p.values)
          message.success(`اعمال شد: ${p.title}`)
        }}>
          {p.title}
          <span style={{ marginInlineStart: 8 }}>
            <Tag color={p.values.accent_color} style={{ margin: 0 }} />
          </span>
        </Button>
      ))}
    </Space>
  ), [])

  const onSave = async (values) => {
    setSaving(true)
    try {
      await setUi({
        theme: values.theme ? 'light' : 'dark',
        accent_color: values.accent_color,
        logo_url: values.logo_url || null,
        login_background_url: values.login_background_url || null,
        header_bg: values.header_bg || null,
        sidebar_bg: values.sidebar_bg || null,
        content_bg: values.content_bg || null,
        text_color: values.text_color || null,
        border_color: values.border_color || null,
      })
      message.success('ذخیره شد')
    } catch (e) {
      message.error('ذخیره انجام نشد')
    } finally {
      setSaving(false)
    }
  }

  const beforeUpload = async (file) => {
    try {
      const res = await uploadLoginBackground(file)
      form.setFieldsValue({
        login_background_url: res.login_background_url || '',
      })
      message.success('پس‌زمینه آپلود شد')
    } catch (e) {
      message.error(e?.response?.data?.detail || 'آپلود انجام نشد')
    }
    return false
  }

  return (
    <Space direction="vertical" style={{ width: '100%' }} size={16}>
      <Title level={3} style={{ margin: 0 }}>تم و رنگ</Title>

      <Card loading={loading} style={{ borderRadius: 16 }}>
        <Space direction="vertical" style={{ width: '100%' }} size={12}>
          <div>
            <Text type="secondary">تم‌های آماده:</Text>
            <div style={{ marginTop: 8 }}>{presetsUi}</div>
          </div>

          <Divider style={{ margin: '8px 0' }} />

          <Form layout="vertical" form={form} onFinish={onSave}>
            <Form.Item label="دارک/لایت" name="theme" valuePropName="checked">
              <Switch checkedChildren="لایت" unCheckedChildren="دارک" />
            </Form.Item>

            <Form.Item label="رنگ اصلی (Primary)" name="accent_color" rules={[{ required: true }]}>
              <ColorPicker />
            </Form.Item>

            <Divider />
            <Title level={5} style={{ margin: 0 }}>رنگ‌های کلیدی</Title>
            <Text type="secondary">این گزینه‌ها اختیاری هستند.</Text>

            <Form.Item label="پس‌زمینه هدر" name="header_bg">
              <ColorPicker />
            </Form.Item>
            <Form.Item label="پس‌زمینه سایدبار" name="sidebar_bg">
              <ColorPicker />
            </Form.Item>
            <Form.Item label="پس‌زمینه محتوای صفحه" name="content_bg">
              <ColorPicker />
            </Form.Item>
            <Form.Item label="رنگ متن" name="text_color">
              <ColorPicker />
            </Form.Item>
            <Form.Item label="رنگ مرزها" name="border_color">
              <ColorPicker />
            </Form.Item>

            <Divider />
            <Title level={5} style={{ margin: 0 }}>لوگو و پس‌زمینه ورود</Title>
            <Form.Item
              label="آدرس لوگو"
              name="logo_url"
              extra={<Text type="secondary">در صورت خالی بودن از لوگوی پیشفرض استفاده می‌شود.</Text>}
            >
              <Input placeholder="/static/ui/logo.png" />
            </Form.Item>

            <Form.Item label="پس‌زمینه صفحه ورود" name="login_background_url">
              <Input placeholder="/static/ui/login_bg.png" />
            </Form.Item>
            <Upload beforeUpload={beforeUpload} showUploadList={false}>
              <Button icon={<UploadOutlined />}>آپلود پس‌زمینه ورود</Button>
            </Upload>

            <Space style={{ marginTop: 16 }}>
              <Button onClick={load}>بازخوانی</Button>
              <Button type="primary" loading={saving} htmlType="submit">ذخیره</Button>
            </Space>
          </Form>
        </Space>
      </Card>
    </Space>
  )
}
