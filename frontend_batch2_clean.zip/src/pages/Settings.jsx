import React, { useEffect, useMemo, useState } from 'react'
import {
  Alert,
  Button,
  Card,
  Checkbox,
  Divider,
  Input,
  Popconfirm,
  Space,
  Tabs,
  Typography,
  message,
  Table,
} from 'antd'
import SmsTemplates from './SmsTemplates.jsx'
import SmsConfigPanel from './SmsConfigPanel.jsx'
import RolesPermissions from './RolesPermissions.jsx'
import AuditLogs from './AuditLogs.jsx'
import { useAppStore } from '../store/appStore'
import { loadSettings, saveSettings } from '../utils/appSettings.js'
import {
  getSessionTimeout,
  setSessionTimeout,
  getVatRates,
  saveVatRates,
} from '../api/settings.js'
import { errorToText } from '../utils/errorText.js'
import { normalizeDigits } from '../utils/normalizeDigits.js'
import JalaliDatePicker from '../components/JalaliDatePicker.jsx'

function CommissionRatesEditor({ rates, setRates, normJ, isJDate }) {
  const [date, setDate] = useState('')
  const [rate, setRate] = useState('')

  const upsert = () => {
    const d = normJ(date)
    const r = Number(normJ(rate))
    if (!isJDate(d)) return message.error('تاریخ شمسی نامعتبر است')
    if (!Number.isFinite(r)) return message.error('نرخ نامعتبر است')
    const exists = (rates || []).some((x) => x.effective_from_j === d)
    const next = exists
      ? (rates || []).map((x) => (x.effective_from_j === d ? { ...x, rate_percent: r } : x))
      : [...(rates || []), { effective_from_j: d, rate_percent: r }]
    next.sort((a, b) => (a.effective_from_j || '').localeCompare(b.effective_from_j || ''))
    setRates(next)
    setDate('')
    setRate('')
  }

  return (
    <div style={{ padding: 8 }}>
      <Space wrap>
        <JalaliDatePicker
          value={date}
          onChange={(v) => setDate(normJ(v))}
          placeholder="تاریخ اعمال (مثلاً 1403/03/03)"
          style={{ width: 220 }}
        />
        <Input value={rate} onChange={(e) => setRate(normJ(e.target.value))} placeholder="نرخ %" style={{ width: 120 }} />
        <Button type="primary" onClick={upsert}>افزودن/به‌روزرسانی</Button>
      </Space>

      <Divider style={{ margin: '12px 0' }} />

      <Table
        size="small"
        rowKey={(r) => r.effective_from_j}
        dataSource={rates || []}
        pagination={false}
        columns={[
          { title: 'تاریخ اعمال (شمسی)', dataIndex: 'effective_from_j' },
          { title: 'نرخ (%)', dataIndex: 'rate_percent' },
          {
            title: 'عملیات',
            width: 170,
            render: (_, row) => (
              <Space>
                <Button size="small" onClick={() => { setDate(row.effective_from_j); setRate(String(row.rate_percent)) }}>ویرایش</Button>
                <Popconfirm
                  title="حذف شود؟"
                  okText="بله"
                  cancelText="خیر"
                  onConfirm={() => setRates((rates || []).filter((x) => x.effective_from_j !== row.effective_from_j))}
                >
                  <Button size="small" danger>حذف</Button>
                </Popconfirm>
              </Space>
            ),
          },
        ]}
      />
    </div>
  )
}

export default function Settings() {
  const [st, setSt] = useState(() => loadSettings())
  const [marketerText, setMarketerText] = useState('')
  const [timeoutText, setTimeoutText] = useState('10')

  // Prefer Zustand user (fresh), fallback to localStorage for backward compatibility
  const storeUser = useAppStore((s) => s.user)

  const currentUser = useMemo(() => {
    if (storeUser) return storeUser
    try {
      const raw = localStorage.getItem('sama_user')
      return raw ? JSON.parse(raw) : null
    } catch {
      return null
    }
  }, [storeUser])

  // Robust admin detection (some older builds used role instead of user_type)
  const isAdmin =
    currentUser?.user_type === 'admin' ||
    currentUser?.role === 'admin' ||
    currentUser?.role === 'super_admin'

  const normJ = (v) => normalizeDigits(String(v || '')).trim()
  const isJDate = (v) => /^\d{4}\/\d{2}\/\d{2}$/.test(normJ(v))

  // VAT (draft)
  const [vatDraft, setVatDraft] = useState([])
  const [vatLoading, setVatLoading] = useState(false)
  const [vatDate, setVatDate] = useState('')
  const [vatRate, setVatRate] = useState('')

  // Lines + commission rates (draft)
  const [linesDraft, setLinesDraft] = useState([]) // [{title, rates:[{effective_from_j, rate_percent}]}]
  const [linesLoading, setLinesLoading] = useState(false)
  const [newLineTitle, setNewLineTitle] = useState('')

  useEffect(() => {
    ;(async () => {
      try {
        const v = await getSessionTimeout()
        const n = Number(v?.session_timeout_minutes || 10)
        setTimeoutText(String(n))
      } catch {
        // ignore
      }
    })()
  }, [])

  useEffect(() => {
    if (!isAdmin) return
    ;(async () => {
      try {
        setVatLoading(true)
        const vr = await getVatRates()
        setVatDraft(vr?.items || [])
      } catch {
        // ignore
      } finally {
        setVatLoading(false)
      }
    })()
  }, [isAdmin])

  const tabs = useMemo(() => {
    const arr = []

    // مدیریت رشته‌ها و نرخ کارمزد به صفحه «کارمزد» منتقل شد (یکپارچه با گزارش‌ها).
    if (false && isAdmin) {
      arr.push({
        key: 'lines_commission',
        label: 'رشته‌ها و نرخ کارمزد',
        children: (
          <Space direction="vertical" size={12} style={{ width: '100%' }}>
            <Typography.Text type="secondary">
              هر رشته را تعریف کن و زیر همان رشته، نرخ‌های کارمزد زمان‌دار (شمسی) را ثبت کن.
            </Typography.Text>

            <Alert
              type="info"
              showIcon
              message="ثبت نهایی"
              description="همه تغییرات (افزودن/حذف/ویرایش رشته و نرخ‌ها) فقط با «ثبت نهایی» ذخیره می‌شوند."
            />

            <Card className="sama-card" styles={{ body: { padding: 12 } }}>
              <Space wrap>
                <Input
                  value={newLineTitle}
                  onChange={(e) => setNewLineTitle(e.target.value)}
                  placeholder="نام رشته جدید (مثلاً: بدنه)"
                  style={{ width: 260 }}
                />
                <Button
                  type="primary"
                  onClick={() => {
                    const t = (newLineTitle || '').trim()
                    if (!t) return
                    if ((linesDraft || []).some((x) => (x.title || '').trim() === t)) return message.info('تکراری است')
                    setLinesDraft((arr2) => [...(arr2 || []), { title: t, rates: [] }])
                    setNewLineTitle('')
                    message.success('اضافه شد (پیش‌نویس)')
                  }}
                >
                  افزودن رشته
                </Button>
                <Button
                  type="primary"
                  loading={linesLoading}
                  onClick={async () => {
                    try {
                      setLinesLoading(true)
                      const payload = (linesDraft || []).map((x) => ({
                        title: (x.title || '').trim(),
                        rates: (x.rates || [])
                          .filter((r) => isJDate(r.effective_from_j) && Number.isFinite(Number(r.rate_percent)))
                          .map((r) => ({ effective_from_j: normJ(r.effective_from_j), rate_percent: Number(r.rate_percent) })),
                      }))
                      const saved = await saveInsuranceLines(payload)
                      setLinesDraft(saved?.items || [])

                      const titles = (saved?.items || []).map((x) => x.title)
                      const next = { ...loadSettings(), insuranceLines: titles }
                      setSt(next)
                      saveSettings(next)

                      message.success('ثبت نهایی انجام شد')
                    } catch (e) {
                      message.error(errorToText(e))
                    } finally {
                      setLinesLoading(false)
                    }
                  }}
                >
                  ثبت نهایی
                </Button>
              </Space>

              <Divider style={{ margin: '12px 0' }} />

              <Table
                size="small"
                rowKey={(r) => r.title}
                loading={linesLoading}
                dataSource={linesDraft || []}
                pagination={false}
                columns={[
                  { title: 'رشته', dataIndex: 'title', key: 'title' },
                  {
                    title: 'عملیات',
                    key: 'ops',
                    width: 120,
                    render: (_, rec) => (
                      <Popconfirm
                        title="حذف رشته"
                        description="در صورت ثبت نهایی، این رشته و نرخ‌هایش حذف می‌شوند."
                        okText="حذف"
                        cancelText="انصراف"
                        onConfirm={() => setLinesDraft((arr2) => (arr2 || []).filter((x) => x.title !== rec.title))}
                      >
                        <Button danger size="small">حذف</Button>
                      </Popconfirm>
                    ),
                  },
                ]}
                expandable={{
                  expandedRowRender: (rec) => (
                    <CommissionRatesEditor
                      rates={rec.rates || []}
                      setRates={(nextRates) => {
                        setLinesDraft((arr2) => (arr2 || []).map((x) => (x.title === rec.title ? { ...x, rates: nextRates } : x)))
                      }}
                      normJ={normJ}
                      isJDate={isJDate}
                    />
                  ),
                }}
              />
            </Card>
          </Space>
        ),
      })

      arr.push({
        key: 'vat',
        label: 'نرخ ارزش افزوده',
        children: (
          <Space direction="vertical" size={12} style={{ width: '100%' }}>
            <Alert
              type="info"
              showIcon
              message="ثبت نهایی"
              description="می‌توانید رکوردها را ویرایش/حذف/اضافه کنید و در پایان با «ثبت نهایی» همه تغییرات یکجا ذخیره می‌شوند."
            />

            <Card className="sama-card" title="نرخ ارزش افزوده (شمسی/زمان‌دار)" styles={{ body: { padding: 12 } }}>
              <Space wrap style={{ width: '100%' }}>
                <JalaliDatePicker
                  value={vatDate}
                  onChange={(v) => setVatDate(normJ(v))}
                  placeholder="تاریخ اعمال (مثلاً 1403/03/03)"
                  style={{ width: 220 }}
                />
                <Input value={vatRate} onChange={(e) => setVatRate(normJ(e.target.value))} placeholder="نرخ %" style={{ width: 120 }} />
                <Button
                  type="primary"
                  onClick={() => {
                    const d = normJ(vatDate)
                    const r = Number(normJ(vatRate))
                    if (!isJDate(d)) return message.error('تاریخ شمسی نامعتبر است')
                    if (!Number.isFinite(r)) return message.error('نرخ نامعتبر است')
                    const exists = (vatDraft || []).some((x) => x.effective_from_j === d)
                    const next = exists
                      ? (vatDraft || []).map((x) => (x.effective_from_j === d ? { ...x, rate_percent: r } : x))
                      : [...(vatDraft || []), { effective_from_j: d, rate_percent: r }]
                    next.sort((a, b) => (a.effective_from_j || '').localeCompare(b.effective_from_j || ''))
                    setVatDraft(next)
                    setVatDate('')
                    setVatRate('')
                  }}
                >
                  افزودن/به‌روزرسانی
                </Button>
                <Button
                  loading={vatLoading}
                  onClick={async () => {
                    try {
                      setVatLoading(true)
                      const out = await saveVatRates(vatDraft || [])
                      setVatDraft(out?.items || [])
                      message.success('ثبت نهایی انجام شد')
                    } catch (e) {
                      message.error(errorToText(e))
                    } finally {
                      setVatLoading(false)
                    }
                  }}
                >
                  ثبت نهایی
                </Button>
              </Space>

              <Divider style={{ margin: '12px 0' }} />

              <Table
                size="small"
                rowKey={(r) => r.effective_from_j}
                loading={vatLoading}
                dataSource={vatDraft || []}
                pagination={false}
                columns={[
                  { title: 'تاریخ اعمال (شمسی)', dataIndex: 'effective_from_j' },
                  { title: 'نرخ (%)', dataIndex: 'rate_percent' },
                  {
                    title: 'عملیات',
                    width: 170,
                    render: (_, row) => (
                      <Space>
                        <Button size="small" onClick={() => { setVatDate(row.effective_from_j); setVatRate(String(row.rate_percent)) }}>ویرایش</Button>
                        <Popconfirm
                          title="حذف شود؟"
                          okText="بله"
                          cancelText="خیر"
                          onConfirm={() => setVatDraft((vatDraft || []).filter((x) => x.effective_from_j !== row.effective_from_j))}
                        >
                          <Button size="small" danger>حذف</Button>
                        </Popconfirm>
                      </Space>
                    ),
                  },
                ]}
              />
            </Card>
          </Space>
        ),
      })
    }

    arr.push({
      key: 'marketers',
      label: 'بازاریاب‌ها',
      children: (
        <Space direction="vertical" size={12} style={{ width: '100%' }}>
          <Typography.Text type="secondary">
            بازاریاب‌ها را اینجا تعریف کن تا در ثبت/ویرایش و فیلترها از لیست انتخاب شوند.
          </Typography.Text>
          <Card className="sama-card" styles={{ body: { padding: 12 } }}>
            <Space wrap style={{ width: '100%' }}>
              <Input
                value={marketerText}
                onChange={(e) => setMarketerText(e.target.value)}
                placeholder="مثلاً: علی احمدی"
                style={{ width: 260 }}
              />
              <Button
                type="primary"
                onClick={() => {
                  const v = (marketerText || '').trim()
                  if (!v) return
                  if ((st.marketers || []).includes(v)) return message.info('تکراری است')
                  const next = { ...st, marketers: [...(st.marketers || []), v] }
                  setSt(next)
                  saveSettings(next)
                  setMarketerText('')
                  message.success('اضافه شد')
                }}
              >
                افزودن
              </Button>
            </Space>

            <Divider style={{ margin: '12px 0' }} />

            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {(st.marketers || []).map((m) => (
                <Button
                  key={m}
                  size="small"
                  danger
                  onClick={() => {
                    const next = { ...st, marketers: (st.marketers || []).filter((x) => x !== m) }
                    setSt(next)
                    saveSettings(next)
                  }}
                >
                  حذف: {m}
                </Button>
              ))}
            </div>
          </Card>
        </Space>
      ),
    })

    arr.push({
      key: 'security',
      label: 'امنیت و زمان خروج',
      children: (
        <Space direction="vertical" size={12} style={{ width: '100%' }}>
          <Card className="sama-card" title="مدت عدم فعالیت (دقیقه)" styles={{ body: { padding: 12 } }}>
            <Space wrap>
              <Input
                value={timeoutText}
                onChange={(e) => setTimeoutText(normJ(e.target.value))}
                placeholder="مثلاً 10"
                style={{ width: 160 }}
              />
              <Button
                type="primary"
                disabled={!timeoutText || !Number.isFinite(Number(timeoutText))}
                onClick={async () => {
                  try {
                    const m = Number(timeoutText)
                    if (!Number.isFinite(m) || m < 1) return message.error('عدد معتبر وارد کنید')
                    await setSessionTimeout(m)
                    message.success('ذخیره شد')
                  } catch (e) {
                    message.error(errorToText(e))
                  }
                }}
              >
                ذخیره
              </Button>
            </Space>
            <Typography.Text type="secondary" style={{ display: 'block', marginTop: 8 }}>
              کاربر بعد از این مدت عدم فعالیت، خودکار خارج می‌شود.
            </Typography.Text>
          </Card>
        </Space>
      ),
    })

    arr.push({ key: 'sms-config', label: 'تنظیمات پیامک', children: <SmsConfigPanel /> })
    arr.push({ key: 'sms', label: 'قالب پیامک', children: <SmsTemplates /> })

    if (isAdmin) {
      arr.push({ key: 'roles', label: 'سطوح دسترسی', children: <RolesPermissions /> })
      arr.push({ key: 'audit', label: 'لاگ فعالیت', children: <AuditLogs /> })
    }

    arr.push({
      key: 'dashboard',
      label: 'داشبورد',
      children: (
        <Space direction="vertical" size={12} style={{ width: '100%' }}>
          <Typography.Text type="secondary">
            فعال/غیرفعال کردن برخی بخش‌های داشبورد (کلاینت-محور).
          </Typography.Text>
          <Card className="sama-card" styles={{ body: { padding: 12 } }}>
            <Space direction="vertical" size={8}>
              <Checkbox
                checked={!!st.dashboardWidgets?.installments7}
                onChange={(e) => {
                  const next = { ...st, dashboardWidgets: { ...(st.dashboardWidgets || {}), installments7: e.target.checked } }
                  setSt(next)
                  saveSettings(next)
                }}
              >
                جدول اقساط ۷ روز آینده
              </Checkbox>
              <Checkbox
                checked={!!st.dashboardWidgets?.renew7}
                onChange={(e) => {
                  const next = { ...st, dashboardWidgets: { ...(st.dashboardWidgets || {}), renew7: e.target.checked } }
                  setSt(next)
                  saveSettings(next)
                }}
              >
                جدول تمدیدهای ۷ روز آینده
              </Checkbox>
            </Space>
          </Card>
        </Space>
      ),
    })

    arr.push({
      key: 'docs',
      label: 'چک‌لیست مستندات',
      children: (
        <Card className="sama-card" styles={{ body: { padding: 12 } }}>
          <Typography.Text type="secondary">
            مدیریت چک‌لیست مستندات از این مسیر انجام می‌شود:
          </Typography.Text>
          <div style={{ marginTop: 8 }}>
            <a href="/settings/checklist">/settings/checklist</a>
          </div>
        </Card>
      ),
    })

    return arr
  }, [
    isAdmin,
    st,
    marketerText,
    timeoutText,
    vatDraft,
    vatLoading,
    vatDate,
    vatRate,
    linesDraft,
    linesLoading,
    newLineTitle,
  ])

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card className="sama-card" styles={{ body: { padding: 16 } }}>
        <Typography.Title level={4} style={{ margin: 0, fontWeight: 800 }}>تنظیمات</Typography.Title>
        <Typography.Text type="secondary">مدیریت آیتم‌های قابل تعریف سیستم</Typography.Text>
      </Card>

      <Card className="sama-card" styles={{ body: { padding: 12 } }}>
        <Tabs items={tabs} />
      </Card>
    </Space>
  )
}
