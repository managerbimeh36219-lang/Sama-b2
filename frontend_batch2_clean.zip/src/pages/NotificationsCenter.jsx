import React, { useMemo, useState } from 'react'
import { Button, Card, Space, Switch, Table, Typography, message } from 'antd'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { listNotifications, markNotificationRead } from '../api/notifications2'

export default function NotificationsCenter() {
  const qc = useQueryClient()
  const [unreadOnly, setUnreadOnly] = useState(true)

  const q = useQuery({
    queryKey: ['notifications', unreadOnly],
    queryFn: () => listNotifications(unreadOnly),
    staleTime: 15 * 1000,
  })

  const rows = useMemo(() => q.data || [], [q.data])

  const columns = [
    { title: 'عنوان', dataIndex: 'title', render: (v) => <b>{v}</b> },
    { title: 'متن', dataIndex: 'body', render: (v) => <Typography.Text>{v}</Typography.Text> },
    { title: 'تاریخ', dataIndex: 'created_at' },
    {
      title: 'عملیات',
      key: 'actions',
      render: (_, r) => (
        <Space>
          {r.link ? (
            <Button size="small" onClick={() => (window.location.href = r.link)}>باز کردن</Button>
          ) : null}
          {!r.is_read ? (
            <Button
              size="small"
              type="primary"
              onClick={async () => {
                try {
                  await markNotificationRead(r.id)
                  message.success('خوانده شد')
                  qc.invalidateQueries({ queryKey: ['notifications'] })
                  qc.invalidateQueries({ queryKey: ['headerStats'] })
                } catch (e) {
                  message.error('خطا در ثبت')
                }
              }}
            >
              خوانده شد
            </Button>
          ) : (
            <Typography.Text type="secondary">خوانده‌شده</Typography.Text>
          )}
        </Space>
      ),
    },
  ]

  return (
    <Card
      title="اعلان‌ها"
      extra={
        <Space>
          <span>فقط خوانده‌نشده</span>
          <Switch checked={unreadOnly} onChange={setUnreadOnly} />
          <Button onClick={() => q.refetch()} loading={q.isFetching}>رفرش</Button>
        </Space>
      }
    >
      <Table
        rowKey="id"
        loading={q.isLoading}
        dataSource={rows}
        columns={columns}
        pagination={{ pageSize: 20 }}
      />
    </Card>
  )
}
