import React, { useEffect, useMemo, useState } from 'react'
import {
  Alert,
  Button,
  Card,
  Checkbox,
  Col,
  Divider,
  Drawer,
  Form,
  Input,
  InputNumber,
  Row,
  Space,
  Table,
  Tabs,
  Select,
  Tag,
  Typography,
  Upload,
  message,
} from 'antd'
import { DownloadOutlined, UploadOutlined } from '@ant-design/icons'

import JalaliDatePicker from '../components/JalaliDatePicker.jsx'

import { commissionsApi } from '../api/commissions'
import { listMarketers } from '../api/marketers2'
import { downloadBlob } from '../utils/fileAccess'
import { errorToText } from '../utils/errorText'
import { useTableView } from '../hooks/useTableView'
import TableViewBar from '../components/TableViewBar'

function isImageMime(m) {
  return (m || '').toLowerCase().startsWith('image/')
}

export default function CommissionCenter() {
  const [me] = useState(() => {
  try {
    const v2 = JSON.parse(localStorage.getItem('sama_app_v2') || 'null')
    if (v2?.state?.user) return v2.state.user
    return JSON.parse(localStorage.getItem('sama_user') || 'null')
  } catch {
    return null
  }
})
  const isAdmin = me?.user_type === 'admin'
  const isMarketer = me?.user_type === 'marketer'

  const statementsTableView = useTableView('table.commissions.statements.v1', { pageSize: 20, dense: false })

  const [marketers, setMarketers] = useState([])

  const [vatRates, setVatRates] = useState([])
  const [commRates, setCommRates] = useState([])

  const [linesDraft, setLinesDraft] = useState([])
  const [linesLoading, setLinesLoading] = useState(false)
  const [newLineTitle, setNewLineTitle] = useState('')

  const [reportLoading, setReportLoading] = useState(false)
  const [report, setReport] = useState(null)

  const reportMarketerTotal = useMemo(() => {
    const items = report?.items || []
    return items.reduce((sum, it) => sum + (Number(it.marketer_share_rial) || 0), 0)
  }, [report])

  const [includeCreated, setIncludeCreated] = useState(false)
  const [filters, setFilters] = useState(() => ({
    marketer_ids: me?.marketer_id ? [me.marketer_id] : [],
    from_date_j: '',
    to_date_j: '',
  }))

  const [editDrawer, setEditDrawer] = useState({ open: false, row: null })

  const [statements, setStatements] = useState([])
  const [stmtForm] = Form.useForm()

  const [vatForm] = Form.useForm()
  const [rateForm] = Form.useForm()

  const canSelectMarketer = !isMarketer

  const ALL_MARKETERS_VALUE = '__ALL__'

  useEffect(() => {
    ;(async () => {
      try {
        const ms = await listMarketers()
        setMarketers(ms || [])
      } catch {
        // ignore
      }
    })()
  }, [])

  const loadLines = async () => {
    try {
      setLinesLoading(true)
      const rows = await commissionsApi.listInsuranceLines()
      setLinesDraft(rows || [])
    } catch (e) {
      message.error(errorToText(e))
    } finally {
      setLinesLoading(false)
    }
  }

  useEffect(() => {
    if (isAdmin) loadLines()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isAdmin])

  const marketerOptions = useMemo(() => {
    const opts = (marketers || []).map((m) => ({ value: m.id, label: m.full_name || m.code || `#${m.id}` }))
    return [{ value: ALL_MARKETERS_VALUE, label: 'همه بازاریاب‌ها' }, ...opts]
  }, [marketers])

  async function loadSettings() {
    if (!isAdmin) return
    try {
      const [v, r] = await Promise.all([
        commissionsApi.listVatRates(),
        commissionsApi.listCommissionRates(),
      ])
      setVatRates(v || [])
      setCommRates(r || [])
    } catch (e) {
      message.error(errorToText(e))
    }
  }

  async function loadStatements() {
    try {
      const rows = await commissionsApi.listStatements(
        isAdmin ? { marketer_id: (filters.marketer_ids?.[0] && filters.marketer_ids[0] !== ALL_MARKETERS_VALUE) ? filters.marketer_ids[0] : undefined } : {}
      )
      setStatements(rows || [])
    } catch (e) {
      message.error(errorToText(e))
    }
  }

  useEffect(() => {
    loadSettings()
    loadStatements()
  }, [])

  async function runReport() {
    if (!filters.marketer_ids || filters.marketer_ids.length === 0) {
      message.warning('حداقل یک بازاریاب را انتخاب کنید')
      return
    }
    if (!filters.from_date_j || !filters.to_date_j) {
      message.warning('بازه تاریخ را وارد کنید (YYYY/MM/DD)')
      return
    }
    setReportLoading(true)
    try {
      const mids = (filters.marketer_ids || []).includes(ALL_MARKETERS_VALUE)
  ? (marketers || []).map((m) => m.id)
  : (filters.marketer_ids || [])
const parts = []
for (const mid of mids) {
  const r = await commissionsApi.getReport({
    marketer_id: mid,
    from_date_j: filters.from_date_j,
    to_date_j: filters.to_date_j,
    include_created: includeCreated,
  })
  parts.push(r)
}
const merged = {
  marketer_id: null,
  from_date_j: filters.from_date_j,
  to_date_j: filters.to_date_j,
  total_commission_rial: parts.reduce((a, p) => a + (p?.total_commission_rial || 0), 0),
  items: parts.flatMap((p) => (p?.items || [])),
}
setReport(merged)
    } catch (e) {
      message.error(errorToText(e))
    } finally {
      setReportLoading(false)
    }
  }

  const reportColumns = useMemo(() => {
  const fmt = (v) => (v ?? 0).toLocaleString('fa-IR')
  return [
    { title: 'ردیف', width: 70, render: (_v, _row, idx) => idx + 1 },
    {
      title: 'شماره بیمه‌نامه',
      dataIndex: 'policy_number',
      width: 160,
      render: (v, row) => v || row.policy_id,
    },
    { title: 'رشته', dataIndex: 'insurance_line', width: 160 },
    { title: 'نام بیمه‌گذار', dataIndex: 'policyholder_name', width: 180 },
    {
      title: 'بازاریاب',
      dataIndex: 'marketer_id',
      width: 160,
      render: (v) => {
        const m = (marketers || []).find((x) => x.id === v)
        return m?.full_name || m?.code || (v ? `#${v}` : 'فاقد بازاریاب')
      },
    },
    {
      title: 'شناسه',
      width: 170,
      render: (_v, row) => (
        <Space size={6} wrap={false}>
          <Typography.Text
            style={{ maxWidth: 120, display: 'inline-block', whiteSpace: 'nowrap' }}
            ellipsis={{ tooltip: row.system_payment_id ? String(row.system_payment_id) : '-' }}
          >
            {row.system_payment_id || '-'}
          </Typography.Text>
          {row.source === 'END' ? (
            <Tag color="purple">الحاقیه</Tag>
          ) : (
            <Tag color="blue">سیستمی</Tag>
          )}
          {row.endorsement_type ? <Tag color="geekblue">{row.endorsement_type}</Tag> : null}
        </Space>
      ),
    },
    { title: 'تاریخ سررسید', dataIndex: 'due_date_j', width: 120 },
    { title: 'تاریخ پرداخت', dataIndex: 'paid_date_j', width: 120, render: (v) => v || '-' },
    {
      title: 'حق بیمه خالص A (ریال)',
      dataIndex: 'paid_amount_rial',
      width: 190,
      render: (v) => <Typography.Text>{fmt(v)}</Typography.Text>,
    },
    { title: 'درصد کارمزد', dataIndex: 'commission_rate_percent', width: 120 },
    {
      title: 'کارمزد محاسبه‌شده (ریال)',
      dataIndex: 'computed_commission_rial',
      width: 200,
      render: (v) => <Typography.Text>{fmt(v)}</Typography.Text>,
    },
    { title: 'درصد سهم بازاریاب', dataIndex: 'marketer_share_percent', width: 140 },
    {
      title: 'کارمزد خالص بازاریاب (ریال)',
      dataIndex: 'marketer_share_rial',
      width: 170,
      render: (v) => <Typography.Text>{fmt(v)}</Typography.Text>,
    },
        {
      title: 'وضعیت',
      dataIndex: 'in_statement',
      width: 120,
      render: (v) => (v ? <Tag color="blue">ساخته‌شده</Tag> : <Tag color="green">جدید</Tag>),
    },
  ]
}, [marketers])

  const stmtColumns = useMemo(() => {
    return [
      { title: 'ID', dataIndex: 'id', width: 70 },
      {
        title: 'بازاریاب',
        dataIndex: 'marketer_id',
        width: 180,
        render: (v) => {
          const m = marketers.find((x) => x.id === v)
          return m?.full_name || m?.code || `#${v}`
        },
      },
      { title: 'از', dataIndex: 'from_date_j', width: 110 },
      { title: 'تا', dataIndex: 'to_date_j', width: 110 },
      {
        title: 'جمع کارمزد',
        dataIndex: 'total_commission_rial',
        width: 140,
        render: (v) => (v || 0).toLocaleString('fa-IR'),
      },
      {
        title: 'خروجی',
        width: 220,
        render: (_, row) => (
          <Space>
            <Button
              size="small"
              icon={<DownloadOutlined />}
              onClick={async () => {
                try {
                  const blob = await commissionsApi.downloadStatementBlob(row.id, 'xlsx')
                  downloadBlob(blob, `commission_statement_${row.id}.xlsx`)
                } catch (e) {
                  message.error(errorToText(e))
                }
              }}
            >
              Excel
            </Button>

            <Button
              size="small"
              onClick={async () => {
                try {
                  const blob = await commissionsApi.downloadStatementBlob(row.id, 'pdf')
                  downloadBlob(blob, `commission_statement_${row.id}.pdf`)
                } catch (e) {
                  message.error(errorToText(e))
                }
              }}
            >
              PDF
            </Button>
            {row.receipt_file_path ? (
              <Button
                size="small"
                onClick={async () => {
                  try {
                    const blob = await commissionsApi.downloadReceiptBlob(row.id)
                    downloadBlob(blob, `receipt_${row.id}`)
                  } catch (e) {
                    message.error(errorToText(e))
                  }
                }}
              >
                رسید
              </Button>
            ) : (
              <Tag color="default">بدون رسید</Tag>
            )}
          </Space>
        ),
      },
    ]
  }, [marketers])

  return (
    <div style={{ padding: 16 }}>
      <Typography.Title level={4} style={{ marginTop: 0 }}>
        کارمزد
      </Typography.Title>

      <Tabs
        items={[
          {
            key: 'report',
            label: 'گزارش و محاسبه',
            children: (
              <>
                <Card>
                  <Row gutter={12}>
                    <Col xs={24} md={8}>
                      <Form layout="vertical">
                        <Form.Item label="بازاریاب">
  <Select
    mode={canSelectMarketer ? 'multiple' : undefined}
    style={{ width: '100%' }}
    disabled={!canSelectMarketer}
    placeholder={canSelectMarketer ? 'انتخاب کنید...' : 'بازاریاب'}
    value={canSelectMarketer ? (filters.marketer_ids || []) : (filters.marketer_ids?.[0] || undefined)}
    onChange={(val) => {
      if (!canSelectMarketer) return
      const arr = Array.isArray(val) ? val : [val]
      if (arr.includes(ALL_MARKETERS_VALUE)) {
        setFilters((s) => ({ ...s, marketer_ids: [ALL_MARKETERS_VALUE] }))
      } else {
        setFilters((s) => ({ ...s, marketer_ids: arr.map((x) => Number(x)).filter(Boolean) }))
      }
    }}
    options={marketerOptions}
  />
  {!isAdmin && isMarketer ? (
    <Typography.Text type="secondary" style={{ fontSize: 12 }}>
      فقط کارمزد خودتان نمایش داده می‌شود
    </Typography.Text>
  ) : null}
</Form.Item>
                      </Form>
                    </Col>
                    <Col xs={24} md={8}>
                      <Form layout="vertical">
                        <Form.Item label="از تاریخ">
                          <JalaliDatePicker
                            value={filters.from_date_j}
                            onChange={(v) => setFilters((s) => ({ ...s, from_date_j: v }))}
                          />
                        </Form.Item>
                      </Form>
                    </Col>
                    <Col xs={24} md={8}>
                      <Form layout="vertical">
                        <Form.Item label="تا تاریخ">
                          <JalaliDatePicker
                            value={filters.to_date_j}
                            onChange={(v) => setFilters((s) => ({ ...s, to_date_j: v }))}
                          />
                        </Form.Item>
                      </Form>
                    </Col>
                  </Row>

                  <Space>
                    <Checkbox checked={includeCreated} onChange={(e) => setIncludeCreated(e.target.checked)}>
                      نمایش همه رکوردها (ساخته‌شده + جدید)
                    </Checkbox>
                    <Button type="primary" loading={reportLoading} onClick={runReport}>
                      محاسبه/به‌روزرسانی
                    </Button>
                    {isAdmin ? (
                      <Button
                        onClick={async () => {
                          try {
                            if ((!filters.marketer_ids || filters.marketer_ids.length === 0) || !filters.from_date_j || !filters.to_date_j) {
                              message.warning('بازه و بازاریاب را وارد کنید')
                              return
                            }
                            const selected = (filters.marketer_ids || []).includes(ALL_MARKETERS_VALUE)
                              ? (marketers || []).map((m) => m.id)
                              : (filters.marketer_ids || [])
                            if (!selected || selected.length === 0) {
                              message.warning('حداقل یک بازاریاب را انتخاب کنید')
                              return
                            }
                            // ساخت فایل جداگانه برای هر بازاریاب
                            for (const mid of selected) {
                              await commissionsApi.createStatement({
                                marketer_id: mid,
                                from_date_j: filters.from_date_j,
                                to_date_j: filters.to_date_j,
                              })
                            }
                            message.success('فایل کارمزد ذخیره شد')
                            await loadStatements()
                          } catch (e) {
                            message.error(errorToText(e))
                          }
                        }}
                      >
                        ساخت فایل کارمزد
                      </Button>
                    ) : null}
                  </Space>

                  {report ? (
                    <>
                      <Divider />
                      <Space>
                        <Typography.Text strong>جمع کارمزد:</Typography.Text>
                        <Tag color="green">{(reportMarketerTotal || 0).toLocaleString('fa-IR')} ریال</Tag>
                      </Space>
                    </>
                  ) : null}
                </Card>

                <div style={{ marginTop: 12 }}>
                  <Table
                    rowKey="id"
                    size="small"
                    bordered
                    loading={reportLoading}
                    columns={reportColumns}
                    rowClassName={(row) => {
                      if (row?.is_manual) return 'row-danger'
                      if (row?.source === 'END' && (row?.paid_amount_rial ?? 0) < 0) return 'row-danger'
                      if (row?.source === 'END') return 'row-endorsement'
                      if (row?.in_statement) return 'row-created'
                      return 'row-new'
                    }}
                    dataSource={report?.items || []}
                    pagination={{ pageSize: 20 }}
                    onRow={(row) => ({
                      onDoubleClick: () => {
                        if (!isAdmin) return
                        setEditDrawer({ open: true, row })
                      },
                    })}
                  />
                  {isAdmin ? (
                    <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                      برای تغییر دستی کارمزد، روی ردیف دوبار کلیک کنید.
                    </Typography.Text>
                  ) : null}
                </div>

                <Drawer
                  open={editDrawer.open}
                  onClose={() => setEditDrawer({ open: false, row: null })}
                  title={`ویرایش کارمزد #${editDrawer.row?.id || ''}`}
                  width={420}
                >
                  {editDrawer.row ? (
                    <Form
                      layout="vertical"
                      initialValues={{
                        final_commission_rial: editDrawer.row.final_commission_rial,
                        note: editDrawer.row.note,
                      }}
                      onFinish={async (vals) => {
                        try {
                          const updated = await commissionsApi.updateCommission(editDrawer.row.id, vals)
                          message.success('ذخیره شد')
                          setEditDrawer({ open: false, row: null })
                          // refresh report
                          await runReport()
                        } catch (e) {
                          message.error(errorToText(e))
                        }
                      }}
                    >
                      <Form.Item label="کارمزد نهایی (ریال)" name="final_commission_rial" rules={[{ required: true }]}>
                        <InputNumber style={{ width: '100%' }} />
                      </Form.Item>
                      <Form.Item label="توضیح" name="note">
                        <Input.TextArea rows={3} />
                      </Form.Item>
                      <Button type="primary" htmlType="submit" block>
                        ذخیره
                      </Button>
                    </Form>
                  ) : null}
                </Drawer>
              </>
            ),
          },
          ...(isAdmin
            ? [
                {
                  key: 'lines_rates',
                  label: 'رشته‌ها و نرخ کارمزد',
                  children: (
                    <Card>
                      <Space direction="vertical" size={12} style={{ width: '100%' }}>
                        <Alert
                          type="info"
                          showIcon
                          message="ثبت نهایی"
                          description="تغییرات رشته‌ها و نرخ‌های کارمزد ابتدا پیش‌نویس است و فقط با «ثبت نهایی» در سیستم اعمال می‌شود."
                        />

                        <Space wrap>
                          <Input
                            placeholder="نام رشته جدید"
                            style={{ width: 260 }}
                            value={newLineTitle}
                            onChange={(e) => setNewLineTitle(e.target.value)}
                          />
                          <Button
                            type="primary"
                            onClick={() => {
                              const t = (newLineTitle || '').trim()
                              if (!t) return
                              if ((linesDraft || []).some((x) => (x.title || '').trim() === t)) {
                                message.info('این رشته قبلاً وجود دارد')
                                return
                              }
                              setLinesDraft((arr) => [...(arr || []), { id: null, title: t, is_active: true, sort_order: 0, rates: [] }])
                              setNewLineTitle('')
                            }}
                          >
                            افزودن رشته
                          </Button>
                          <Button
                            type="primary"
                            loading={linesLoading}
                            onClick={async () => {
                              try {
                                setLinesLoading(true)
                                const payload = {
                                  lines: (linesDraft || []).map((x, idx) => ({
                                    id: x.id || null,
                                    title: (x.title || '').trim(),
                                    is_active: x.is_active !== false,
                                    sort_order: Number.isFinite(Number(x.sort_order)) ? Number(x.sort_order) : idx,
                                    rates: (x.rates || []).map((r) => ({
                                      effective_from_j: r.effective_from_j,
                                      rate_percent: Number(r.rate_percent || 0),
                                    })),
                                  })),
                                }
                                const saved = await commissionsApi.saveInsuranceLinesBatch(payload)
                                setLinesDraft(saved || [])
                                message.success('ثبت نهایی انجام شد')
                              } catch (e) {
                                message.error(errorToText(e))
                              } finally {
                                setLinesLoading(false)
                              }
                            }}
                          >
                            ثبت نهایی
                          </Button>
                          <Button onClick={loadLines} disabled={linesLoading}>
                            بازخوانی
                          </Button>
                        </Space>

                        <Table
                          rowKey={(r) => String(r.id || r.title)}
                          loading={linesLoading}
                          dataSource={linesDraft || []}
                          pagination={false}
                          columns={[
                            {
                              title: 'رشته',
                              dataIndex: 'title',
                              render: (v, rec) => (
                                <Input
                                  value={v}
                                  onChange={(e) => {
                                    const nv = e.target.value
                                    setLinesDraft((arr) => (arr || []).map((x) => (x === rec ? { ...x, title: nv } : x)))
                                  }}
                                />
                              ),
                            },
                            {
                              title: 'فعال',
                              dataIndex: 'is_active',
                              width: 90,
                              render: (v, rec) => (
                                <Checkbox
                                  checked={v !== false}
                                  onChange={(e) => {
                                    const ck = e.target.checked
                                    setLinesDraft((arr) => (arr || []).map((x) => (x === rec ? { ...x, is_active: ck } : x)))
                                  }}
                                />
                              ),
                            },
                            {
                              title: 'حذف',
                              width: 90,
                              render: (_, rec) => (
                                <Button danger size="small" onClick={() => setLinesDraft((arr) => (arr || []).filter((x) => x !== rec))}>
                                  حذف
                                </Button>
                              ),
                            },
                          ]}
                          expandable={{
                            expandedRowRender: (rec) => (
                              <div style={{ padding: 8 }}>
                                <Space direction="vertical" size={8} style={{ width: '100%' }}>
                                  <Typography.Text type="secondary">نرخ‌های کارمزد زمان‌دار</Typography.Text>

                                  <Button
                                    onClick={() => {
                                      setLinesDraft((arr) =>
                                        (arr || []).map((x) =>
                                          x === rec ? { ...x, rates: [...(x.rates || []), { effective_from_j: '', rate_percent: '' }] } : x
                                        )
                                      )
                                    }}
                                  >
                                    افزودن نرخ
                                  </Button>

                                  <Table
                                    size="small"
                                    rowKey={(r) => r.id || `${r.effective_from_j}`}
                                    dataSource={rec.rates || []}
                                    pagination={false}
                                    columns={[
                                      {
                                        title: 'از تاریخ',
                                        dataIndex: 'effective_from_j',
                                        render: (v, r, idx) => (
                                          <JalaliDatePicker
                                            value={v}
                                            onChange={(nv) => {
                                              setLinesDraft((arr) =>
                                                (arr || []).map((x) =>
                                                  x === rec
                                                    ? { ...x, rates: (x.rates || []).map((rr, j) => (j === idx ? { ...rr, effective_from_j: nv } : rr)) }
                                                    : x
                                                )
                                              )
                                            }}
                                          />
                                        ),
                                      },
                                      {
                                        title: 'درصد',
                                        dataIndex: 'rate_percent',
                                        width: 140,
                                        render: (v, r, idx) => (
                                          <Input
                                            value={String(v ?? '')}
                                            onChange={(e) => {
                                              const nv = e.target.value
                                              setLinesDraft((arr) =>
                                                (arr || []).map((x) =>
                                                  x === rec
                                                    ? { ...x, rates: (x.rates || []).map((rr, j) => (j === idx ? { ...rr, rate_percent: nv } : rr)) }
                                                    : x
                                                )
                                              )
                                            }}
                                          />
                                        ),
                                      },
                                      {
                                        title: 'حذف',
                                        width: 90,
                                        render: (_, r, idx) => (
                                          <Button
                                            danger
                                            size="small"
                                            onClick={() => {
                                              setLinesDraft((arr) =>
                                                (arr || []).map((x) =>
                                                  x === rec ? { ...x, rates: (x.rates || []).filter((_, j) => j !== idx) } : x
                                                )
                                              )
                                            }}
                                          >
                                            حذف
                                          </Button>
                                        ),
                                      },
                                    ]}
                                  />
                                </Space>
                              </div>
                            ),
                          }}
                        />
                      </Space>
                    </Card>
                  ),
                },
              ]
            : []),
          {
            key: 'statements',
            label: 'فایل‌های کارمزد',
            children: (
              <>
                <Card>
                  <Row gutter={12}>
                    {isAdmin ? (
                      <Col xs={24} md={10}>
                        <Form layout="vertical">
                          <Form.Item label="فیلتر بازاریاب">
                            <select
                              style={{ width: '100%', padding: 8, borderRadius: 8 }}
                              value={filters.marketer_id || ''}
                              onChange={(e) =>
                                setFilters((s) => ({ ...s, marketer_id: Number(e.target.value) || null }))
                              }
                            >
                              <option value="">همه</option>
                              {marketerOptions.map((o) => (
                                <option key={o.value} value={o.value}>
                                  {o.label}
                                </option>
                              ))}
                            </select>
                          </Form.Item>
                        </Form>
                      </Col>
                    ) : null}
                    <Col xs={24} md={14}>
                      <Space>
                        <Button onClick={loadStatements}>به‌روزرسانی</Button>
                      </Space>
                    </Col>
                  </Row>
                </Card>

                <div style={{ marginTop: 12 }}>
                  <div style={{ padding: '0 0 8px 0' }}>
                    <TableViewBar view={statementsTableView.view} onChange={statementsTableView.save} />
                  </div>
                  <Table
                    rowKey="id"
                    size={statementsTableView.view.dense ? 'small' : 'middle'}
                    bordered
                    columns={stmtColumns}
                    dataSource={statements}
                    pagination={{
                      pageSize: statementsTableView.view.pageSize || 20,
                      showSizeChanger: true,
                      pageSizeOptions: [10, 20, 50, 100],
                      onShowSizeChange: (_c, ps) => statementsTableView.save({ pageSize: ps }),
                    }}
                    expandable={
                      isAdmin
                        ? {
                            expandedRowRender: (row) => (
                              <Space direction="vertical" style={{ width: '100%' }}>
                                <Typography.Text strong>آپلود رسید پرداخت</Typography.Text>
                                <Upload
                                  maxCount={1}
                                  beforeUpload={() => false}
                                  onChange={async ({ file }) => {
                                    try {
                                      await commissionsApi.uploadReceipt(row.id, file)
                                      message.success('رسید آپلود شد')
                                      await loadStatements()
                                    } catch (e) {
                                      message.error(errorToText(e))
                                    }
                                  }}
                                >
                                  <Button icon={<UploadOutlined />}>انتخاب فایل رسید</Button>
                                </Upload>
                              </Space>
                            ),
                          }
                        : undefined
                    }
                  />
                </div>
              </>
            ),
          },
          null,
        ].filter(Boolean)}
      />

      <Typography.Paragraph type="secondary" style={{ marginTop: 8, fontSize: 12 }}>
        فرمول محاسبه: D = (A / (1 + B/100)) × (C/100) — فقط برای شناسه‌های سیستمیِ تسویه‌شده.
      </Typography.Paragraph>
    </div>
  )
}
