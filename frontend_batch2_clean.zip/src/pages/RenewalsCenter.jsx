import React, { useMemo, useState } from 'react'
import { Button, Card, Drawer, Dropdown, Descriptions, Form, Input, Modal, Select, Space, Table, Tag, Typography, message, Grid } from 'antd'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { MoreOutlined, RightOutlined } from '@ant-design/icons'
import JalaliDatePicker from '../components/JalaliDatePicker.jsx'
import SmartFiltersBar from '../components/SmartFiltersBar.jsx'
import { useDebouncedValue, useSessionState } from '../utils/useSessionState.js'
import { fetchRenewals, getRenewal, upsertRenewal, listRenewalFollowups, createRenewalFollowup } from '../api/renewals.js'
import { listSmsTemplates } from '../api/smsTemplates.js'
import { http } from '../api/http.js'
import { makeGsColumnFilter, uniq } from '../utils/gsFilters.jsx'
import { createRequest } from '../api/requests2.js'
import { useTableView } from '../hooks/useTableView'
import TableViewBar from '../components/TableViewBar'

function fmtRial(n) {
  try {
    return new Intl.NumberFormat('en-US').format(n ?? 0)
  } catch {
    return String(n ?? '')
  }
}

function StatusTag({ st }) {
  if (st === 'renewed') return <Tag color="green">تمدید شده</Tag>
  if (st === 'renewed_elsewhere') return <Tag color="geekblue">تمدید در جای دیگر</Tag>
  if (st === 'stopped') return <Tag color="volcano">متوقف</Tag>
  return <Tag color="orange">در انتظار</Tag>
}



function CreditGauge({ score }) {
  const s = Number(score ?? 0)

  let color = '#cf1322' // red
  let label = 'پرریسک'
  if (s >= 80) { color = '#389e0d'; label = 'عالی' }        // green
  else if (s >= 60) { color = '#d4b106'; label = 'خوب' }    // yellow
  else if (s >= 40) { color = '#d46b08'; label = 'متوسط' }  // orange

  const icon = s >= 80 ? '🧭' : s >= 60 ? '🧭' : s >= 40 ? '🧭' : '🧭'
  // رنگ را با یک دایره رنگی کنار عقربه نشان می‌دهیم
  const dot = s >= 80 ? '🟢' : s >= 60 ? '🟡' : s >= 40 ? '🟠' : '🔴'

  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      <span>{dot}{icon}</span>
      <span style={{ fontWeight: 800, color }}>{s}</span>
      <span style={{ opacity: 0.7, fontSize: 12 }}>{label}</span>
    </span>
  )
}

export default function RenewalsCenter() {
  const qc = useQueryClient()
  const screens = Grid.useBreakpoint()
  const isMobile = !!screens.xs && !screens.sm

  const currentUser = useMemo(() => {
    try {
      const raw = localStorage.getItem('sama_user')
      return raw ? JSON.parse(raw) : null
    } catch {
      return null
    }
  }, [])

  // ---------- policy overview drawer
  const [polDrawerOpen, setPolDrawerOpen] = useState(false)
  const [polDrawerLoading, setPolDrawerLoading] = useState(false)
  const [polDetail, setPolDetail] = useState(null)

  async function openPolicyDrawer(row) {
    if (!row?.policy_id) return
    setPolDrawerOpen(true)
    setPolDrawerLoading(true)
    try {
      const res = await http.get(`/policies/${row.policy_id}`)
      setPolDetail(res.data)
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.message || 'خطا'
      message.error(typeof msg === 'string' ? msg : JSON.stringify(msg))
    } finally {
      setPolDrawerLoading(false)
    }
  }

  const [state, setState] = useSessionState('renewals:v1', {
    global_q: '',
    q: '',
    status: '',
    insurance_line: '',
    sortField: 'end_date_j',
    sortOrder: 'ascend',
    pageSize: 25,
    page: 1,
  })

  const tableView = useTableView('table.renewals.v1', { pageSize: state.pageSize || 25, dense: false })

  const dq = useDebouncedValue(state.q, 300)
  const dGlobal = useDebouncedValue(state.global_q, 300)

  const { data, isFetching } = useQuery({
    queryKey: ['renewals', { q: dq, status: state.status, insurance_line: state.insurance_line, sortField: state.sortField, sortOrder: state.sortOrder, page: state.page, pageSize: state.pageSize }],
    queryFn: () => fetchRenewals({
      q: undefined,
      status: state.status || undefined,
      insurance_line: state.insurance_line || undefined,
      sort_by: state.sortField,
      sort_dir: state.sortOrder === 'descend' ? 'desc' : 'asc',
      page: state.page,
      page_size: tableView.view.pageSize || state.pageSize,
    }),
    keepPreviousData: true,
  })

  const rows = Array.isArray(data) ? data : (data?.items || [])

  const lineOptions = useMemo(() => {
    const vals = Array.from(new Set((rows || []).map((r) => r?.insurance_line).filter(Boolean)))
    vals.sort((a, b) => String(a).localeCompare(String(b), 'fa'))
    return [{ value: '', label: 'همه' }, ...vals.map((v) => ({ value: v, label: v }))]
  }, [rows])

  const viewRows = rows

  const marketerValues = useMemo(() => uniq(rows.map((r) => r.marketer)), [rows])
  const policyNumberValues = React.useMemo(() => uniq((rows || []).map((r) => r.policy_number)), [rows])
  const policyholderValues = React.useMemo(() => uniq((rows || []).map((r) => r.policyholder_name)), [rows])
  const endValues = React.useMemo(() => uniq((rows || []).map((r) => r.end_date_j)), [rows])
  const statusValues = React.useMemo(() => uniq((rows || []).map((r) => r.status)), [rows])

  // ---------- followups modal
  const [fuOpen, setFuOpen] = useState(false)
  const [fuPolicy, setFuPolicy] = useState(null)
  const [fuList, setFuList] = useState([])
  const [templates, setTemplates] = useState([])
  const [fuLoading, setFuLoading] = useState(false)
  const [fuForm] = Form.useForm()

  async function openFollowups(row) {
    setFuPolicy(row)
    setFuOpen(true)
    fuForm.resetFields()
    fuForm.setFieldsValue({ channel: 'call', result: '', note: '', next_followup_date_j: '', template_id: undefined, sms_text: '' })
    setFuLoading(true)
    try {
      const [f, t] = await Promise.all([
        listRenewalFollowups(row.policy_id),
        templates.length ? Promise.resolve(templates) : listSmsTemplates(),
      ])
      setFuList(f || [])
      setTemplates(t || [])
    } finally {
      setFuLoading(false)
    }
  }

  async function saveFollowup() {
    const v = await fuForm.validateFields()
    const payload = {
      channel: v.channel,
      result: v.result || null,
      note: v.note || null,
      next_followup_date_j: v.next_followup_date_j || null,
      sms_text: v.sms_text || null,
    }
    setFuLoading(true)
    try {
      await createRenewalFollowup(fuPolicy.policy_id, payload)
      message.success('پیگیری ثبت شد')
      const f = await listRenewalFollowups(fuPolicy.policy_id)
      setFuList(f || [])
      fuForm.resetFields()
      fuForm.setFieldsValue({ channel: 'call' })
      qc.invalidateQueries({ queryKey: ['renewals'] })
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.message || 'خطا'
      message.error(typeof msg === 'string' ? msg : JSON.stringify(msg))
    } finally {
      setFuLoading(false)
    }
  }

  // ---------- manual status
  const [stOpen, setStOpen] = useState(false)
  const [stPolicy, setStPolicy] = useState(null)
  const [stForm] = Form.useForm()

  async function openStatus(row) {
    setStPolicy(row)
    setStOpen(true)
    const r = await getRenewal(row.policy_id)
    stForm.setFieldsValue({
      status: r.status || 'pending',
      reason_code: r.reason_code || '',
      reason_text: r.reason_text || '',
    })
  }

  async function saveStatus() {
    const v = await stForm.validateFields()
    if ((v.status === 'renewed_elsewhere' || v.status === 'stopped') && !v.reason_text?.trim()) {
      message.error('برای این وضعیت، درج دلیل الزامی است')
      return
    }
    try {
      await upsertRenewal(stPolicy.policy_id, {
        status: v.status,
        reason_code: v.reason_code || null,
        reason_text: v.reason_text || null,
      })
      message.success('وضعیت تمدید ذخیره شد')
      setStOpen(false)
      qc.invalidateQueries({ queryKey: ['renewals'] })
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.message || 'خطا'
      message.error(typeof msg === 'string' ? msg : JSON.stringify(msg))
    }
  }

  const columns = useMemo(() => [
    {
      title: '',
      key: 'open_policy',
      width: 46,
      fixed: 'right',
      render: (_, r) => (
        <Button size="small" shape="circle" icon={<RightOutlined />} onClick={() => openPolicyDrawer(r)} />
      ),
    },
    { title: 'شماره بیمه‌نامه', dataIndex: 'policy_number', key: 'policy_number', width: 170, ellipsis: true, sorter: true,
      ...makeGsColumnFilter({ key: 'policy_number', getValues: () => policyNumberValues }),
    },

    {
      title: 'اعتبار',
      dataIndex: 'credit_score',
      key: 'credit_score',
      width: 140,
      sorter: true,
      render: (v) => <CreditGauge score={v} />,
    },
    {
      title: 'بازاریاب',
      dataIndex: 'marketer',
      key: 'marketer',
      width: 150,
      ellipsis: true,
      sorter: true,
      ...makeGsColumnFilter({ key: 'marketer', getValues: () => marketerValues }),
    },
    { title: 'بیمه‌گذار', dataIndex: 'policyholder_name', key: 'policyholder_name', width: 200, ellipsis: true, sorter: true,
      ...makeGsColumnFilter({ key: 'policyholder_name', getValues: () => policyholderValues }),
    },
    { title: 'موبایل', dataIndex: 'mobile', key: 'mobile', width: 130 },
    { title: 'مورد بیمه', dataIndex: 'insured_item', key: 'insured_item', width: 180, ellipsis: true },
    { title: 'تاریخ انقضاء', dataIndex: 'end_date_j', key: 'end_date_j', width: 120, sorter: true,
      ...makeGsColumnFilter({ key: 'end_date_j', getValues: () => endValues }),
    },
    { title: 'روز مانده', dataIndex: 'days_to_end', key: 'days_to_end', width: 110, render: (v) => <Tag color={v <= 3 ? 'red' : (v <= 7 ? 'orange' : 'blue')}>{v}</Tag> },
    { title: 'وضعیت', dataIndex: 'status', key: 'status', width: 160, sorter: true,
      ...makeGsColumnFilter({ key: 'status', getValues: () => statusValues }),
      render: (v) => <StatusTag st={v} /> },
    { title: 'دلیل', dataIndex: 'reason_text', key: 'reason_text', ellipsis: true },
    {
      title: 'عملیات',
      key: 'actions',
      width: 220,
      render: (_, row) => {
        const isMarketer = currentUser?.user_type === 'marketer'
        const items = [
          { key: 'followups', label: 'ثبت/مشاهده پیگیری', onClick: () => openFollowups(row) },
        ]
        if (!isMarketer) {
          items.push({ key: 'status', label: 'ثبت تمدید دستی', onClick: () => openStatus(row) })
        } else {
          items.push({
            key: 'refer',
            label: 'ارجاع به کارتابل استعلام/صدور',
            onClick: async () => {
              try {
                await createRequest({
                  title: `استعلام/صدور تمدید — بیمه‌نامه ${row.policy_number}`,
                  request_type: 'renewal_quote_issue',
                  description: `درخواست از بازاریاب: ${row.marketer || ''}\nبیمه‌گذار: ${row.policyholder_name || ''}\nتاریخ انقضاء: ${row.end_date_j || ''}\nمورد بیمه: ${row.insured_item || ''}`,
                  policy_id: row.policy_id,
                })
                message.success('به کارتابل ارجاع شد')
              } catch (e) {
                message.error(e?.response?.data?.detail || 'خطا در ارجاع')
              }
            },
          })
        }
        return (
          <Dropdown menu={{ items }} trigger={['click']}>
            <Button size="small" icon={<MoreOutlined />}>{isMarketer ? 'درخواست تمدید' : 'عملیات'}</Button>
          </Dropdown>
        )
      },
    },
  ], [templates, currentUser])

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card size="small"><Typography.Title level={5} style={{ margin: 0 }}>تمدید</Typography.Title></Card>

      <Card size="small">
        <Space wrap style={{ width: '100%', justifyContent: 'space-between' }}>
          <Space wrap>
            <Select
              value={state.status || undefined}
              onChange={(v) => setState((s) => ({ ...s, status: v || '', page: 1 }))}
              allowClear
              placeholder="فیلتر وضعیت"
              style={{ width: 180 }}
              options={[
                { value: 'pending', label: 'در انتظار' },
                { value: 'renewed', label: 'تمدید شده' },
                { value: 'renewed_elsewhere', label: 'تمدید در جای دیگر' },
                { value: 'stopped', label: 'متوقف' },
              ]}
            />

            <Select
              value={state.insurance_line}
              onChange={(v) => setState((s) => ({ ...s, insurance_line: v || '', page: 1 }))}
              placeholder="فیلتر رشته"
              style={{ width: 200 }}
              options={lineOptions}
            />
          </Space>
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>
            با وارد شدن بیمه‌نامه جدید که «شماره بیمه‌نامه سال قبل» آن با شماره یکی از بیمه‌نامه‌های ثبت‌شده برابر باشد، تمدید قبلی به‌صورت خودکار ثبت می‌شود.
          </Typography.Text>
        </Space>
      </Card>

      <Card size="small" bodyStyle={{ padding: 0 }} extra={<TableViewBar view={tableView.view} onChange={tableView.save} />}>
        <Table
          rowKey={(r) => String(r.policy_id)}
          size={tableView.view.dense ? 'small' : 'middle'}
          loading={isFetching}
          columns={columns}
          dataSource={viewRows}
          tableLayout="fixed"
          onChange={(pagination, _filters, sorter) => {
            const s = Array.isArray(sorter) ? sorter[0] : sorter
            if (s?.field) {
              setState((st) => ({ ...st, sortField: String(s.field), sortOrder: s.order || 'ascend' }))
            }
            if (pagination?.pageSize && pagination.pageSize !== state.pageSize) {
              setState((st) => ({ ...st, pageSize: pagination.pageSize, page: 1 }))
              tableView.save({ pageSize: pagination.pageSize })
            }
          }}
          pagination={{ current: state.page, pageSize: tableView.view.pageSize || state.pageSize, total: data?.total || 0, showSizeChanger: true, pageSizeOptions: [10,25,50,100], onChange: (page, pageSize) => { setState((st) => ({ ...st, page, pageSize })) ; tableView.save({ pageSize }) } }}
        />
      </Card>

      <Modal
        open={fuOpen}
        onCancel={() => setFuOpen(false)}
        onOk={saveFollowup}
        confirmLoading={fuLoading}
        okText="ثبت پیگیری"
        title={fuPolicy ? `پیگیری تمدید — ${fuPolicy.policy_number}` : 'پیگیری تمدید'}
        width={720}
      >
        <Space direction="vertical" size={12} style={{ width: '100%' }}>
          <Form form={fuForm} layout="vertical">
            <Space wrap style={{ width: '100%' }}>
              <Form.Item name="channel" label="کانال" initialValue="call" rules={[{ required: true }]} style={{ minWidth: 160 }}>
                <Select
                  options={[
                    { value: 'call', label: 'تماس' },
                    { value: 'sms', label: 'پیامک' },
                  ]}
                />
              </Form.Item>
              <Form.Item name="next_followup_date_j" label="پیگیری بعدی" style={{ minWidth: 200 }}>
                <JalaliDatePicker placeholder="اختیاری" style={{ width: '100%' }} />
              </Form.Item>
            </Space>

            <Form.Item shouldUpdate={(p, c) => p.channel !== c.channel} noStyle>
              {({ getFieldValue }) =>
                getFieldValue('channel') === 'sms' ? (
                  <>
                    <Form.Item name="template_id" label="قالب پیامک">
                      <Select
                        allowClear
                        showSearch
                        placeholder="اختیاری"
                        options={(templates || []).map((t) => ({ value: String(t.id), label: t.name }))}
                        onChange={(val) => {
                          const tpl = (templates || []).find((t) => String(t.id) === String(val))
                          if (tpl) fuForm.setFieldsValue({ sms_text: tpl.content })
                        }}
                      />
                    </Form.Item>

                    <Form.Item name="sms_text" label="متن پیامک">
                      <Input.TextArea rows={3} placeholder="متن پیامک" />
                    </Form.Item>
                  </>
                ) : null
              }
            </Form.Item>

            <Form.Item name="result" label="نتیجه">
              <Input placeholder="مثلاً: پاسخ داد / در انتظار / شماره خاموش" />
            </Form.Item>

            <Form.Item name="note" label="توضیحات">
              <Input.TextArea rows={2} />
            </Form.Item>
          </Form>

          <Card size="small" title="سوابق" bodyStyle={{ padding: 0 }}>
            <Table
              size="small"
              rowKey={(r) => String(r.id)}
              pagination={false}
              dataSource={fuList}
              columns={[
                { title: 'تاریخ', dataIndex: 'followup_date_j', width: 120 },
                { title: 'کانال', dataIndex: 'channel', width: 90, render: (v) => (v === 'sms' ? 'پیامک' : 'تماس') },
                { title: 'نتیجه', dataIndex: 'result', width: 160, ellipsis: true },
                { title: 'توضیحات', dataIndex: 'note', ellipsis: true },
                { title: 'بعدی', dataIndex: 'next_followup_date_j', width: 120 },
                { title: 'ثبت توسط', dataIndex: 'created_by_name', width: 140, render: (v) => v || '-' },
              ]}
            />
          </Card>
        </Space>
      </Modal>

      <Modal
        open={stOpen}
        onCancel={() => setStOpen(false)}
        onOk={saveStatus}
        okText="ذخیره"
        title={stPolicy ? `ثبت تمدید دستی — ${stPolicy.policy_number}` : 'ثبت تمدید دستی'}
        width={560}
      >
        <Form form={stForm} layout="vertical">
          <Form.Item name="status" label="وضعیت" rules={[{ required: true }]}
          >
            <Select
              options={[
                { value: 'pending', label: 'در انتظار پیگیری' },
                { value: 'renewed', label: 'تمدید شده' },
                { value: 'renewed_elsewhere', label: 'تمدید در جای دیگر' },
                { value: 'stopped', label: 'متوقف' },
              ]}
            />
          </Form.Item>

          <Form.Item name="reason_code" label="کد دلیل" extra="برای گزارشات آینده (اختیاری)">
            <Input placeholder="مثلاً: SOLD / OTHER_COMPANY / NO_NEED" />
          </Form.Item>
          <Form.Item name="reason_text" label="دلیل" extra="برای «تمدید در جای دیگر» و «متوقف»، درج دلیل الزامی است.">
            <Input.TextArea rows={3} placeholder="مثلاً: خودرو فروخته شد / بیمه را از شرکت X تمدید کرد" />
          </Form.Item>
        </Form>
      </Modal>

      <Drawer
        open={polDrawerOpen}
        onClose={() => setPolDrawerOpen(false)}
        title={polDetail ? `نمای کلی بیمه‌نامه — ${polDetail.policy_number}` : 'نمای کلی بیمه‌نامه'}
        placement={isMobile ? 'bottom' : 'right'}
        height={isMobile ? '75vh' : undefined}
        width={isMobile ? undefined : 520}
      >
        {polDrawerLoading ? (
          <div style={{ padding: 12 }}>در حال دریافت…</div>
        ) : polDetail ? (
          <Descriptions column={1} size="small" bordered>
            <Descriptions.Item label="شماره بیمه‌نامه">{polDetail.policy_number}</Descriptions.Item>
            <Descriptions.Item label="رشته">{polDetail.insurance_line}</Descriptions.Item>
            <Descriptions.Item label="بیمه‌گذار">{polDetail.policyholder_name}</Descriptions.Item>
            <Descriptions.Item label="مورد بیمه">{polDetail.insured_item}</Descriptions.Item>
            <Descriptions.Item label="کدملی">{polDetail.national_id}</Descriptions.Item>
            <Descriptions.Item label="موبایل">{polDetail.mobile}</Descriptions.Item>
            <Descriptions.Item label="تاریخ صدور">{polDetail.issue_date_j}</Descriptions.Item>
            <Descriptions.Item label="شروع">{polDetail.start_date_j}</Descriptions.Item>
            <Descriptions.Item label="تاریخ انقضاء">{polDetail.end_date_j}</Descriptions.Item>
            <Descriptions.Item label="کل حق بیمه">{fmtRial(polDetail.total_premium_rial)}</Descriptions.Item>
          </Descriptions>
        ) : (
          <div style={{ padding: 12 }}>—</div>
        )}
      </Drawer>
    </Space>
  )
}
