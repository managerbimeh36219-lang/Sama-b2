import React, { useMemo, useState } from 'react'
import { Card, Table, Typography, Grid, Drawer, Descriptions, Space, Button } from 'antd'
import { usePageState } from '../hooks/usePageState'
import { useTableView } from '../hooks/useTableView'
import TableViewBar from '../components/TableViewBar'

const { useBreakpoint } = Grid

export default function PlaceholderTable({ title, columns, storageKey }){
  const bp = useBreakpoint()
  const isMobile = !bp.md
  const key = storageKey || title

  const { state, setState, reset } = usePageState(key, {
    page: 1,
    pageSize: 20,
    sorter: null,
  })

  // Save View (DB per-user): pageSize + dense
  const tableView = useTableView(`table.${key}.v1`, { pageSize: state.pageSize || 20, dense: false })

  const [open, setOpen] = useState(false)
  const [active, setActive] = useState(null)

  const tablePagination = useMemo(() => ({
    current: state.page,
    pageSize: tableView.view.pageSize || state.pageSize,
    showSizeChanger: true,
    pageSizeOptions: [10, 20, 50, 100],
    onChange: (page, pageSize) => {
      setState(s => ({ ...s, page, pageSize }))
      tableView.save({ pageSize })
    },
  }), [state.page, state.pageSize, tableView.view.pageSize])

  const onChange = (_pagination, _filters, sorter) => {
    const s = sorter?.order ? { field: sorter.field, order: sorter.order } : null
    setState(prev => ({ ...prev, sorter: s }))
  }

  return (
    <Card
      title={title}
      extra={
        <Space>
          <TableViewBar view={tableView.view} onChange={tableView.save} />
          <Button size="small" onClick={reset}>ریست فیلتر/صفحه</Button>
        </Space>
      }
    >
      <div className="antd-table-wrap">
        <Table
          columns={columns}
          dataSource={[]}
          rowKey={(r) => r.id || Math.random()}
          pagination={tablePagination}
          size={tableView.view.dense ? 'small' : 'middle'}
          scroll={isMobile ? undefined : { x: 'max-content' }}
          onChange={onChange}
          onRow={(record) => ({
            onClick: () => {
              if (!isMobile) return
              setActive(record)
              setOpen(true)
            }
          })}
          locale={{ emptyText: <Typography.Text type="secondary">نسخه UI فاز B — داده‌ها از API در مرحله بعد وصل می‌شود</Typography.Text> }}
        />
      </div>

      <Drawer
        open={open}
        onClose={() => setOpen(false)}
        title="جزئیات"
        placement="bottom"
        height="70vh"
      >
        {active ? (
          <Descriptions bordered column={1} size="small">
            {columns.map((c) => (
              <Descriptions.Item key={c.dataIndex || c.key || c.title} label={c.title}>
                {String(active[c.dataIndex] ?? '-')}
              </Descriptions.Item>
            ))}
          </Descriptions>
        ) : (
          <Typography.Text type="secondary">رکوردی انتخاب نشده است.</Typography.Text>
        )}
      </Drawer>
    </Card>
  )
}
