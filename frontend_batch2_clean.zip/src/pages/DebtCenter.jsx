import React, { useMemo, useState } from 'react'
import { Button, Card, Drawer, Form, Input, Select, Space, Table, Tag, Tabs, Typography, message, Grid } from 'antd'
import { useQuery, useQueryClient } from '@tanstack/react-query'

import { makeGsColumnFilter, uniq } from '../utils/gsFilters.jsx'
import { useDebouncedValue, useSessionState } from '../utils/useSessionState.js'
import { fetchDebts } from '../api/debts.js'
import { addTransaction, listTransactions, listFollowups, createFollowup } from '../api/installments.js'
import JalaliDatePicker from '../components/JalaliDatePicker.jsx'
import { useTableView } from '../hooks/useTableView'
import TableViewBar from '../components/TableViewBar'

function fmtRial(n) {
  try {
    return new Intl.NumberFormat('fa-IR').format(n ?? 0)
  } catch {
    return String(n ?? '')
  }
}

function RiskTag({ daysLate, remain }) {
  if (!remain || remain <= 0) return <Tag color="green">تسویه</Tag>
  if (daysLate >= 60) return <Tag color="red">پرریسک</Tag>
  if (daysLate >= 30) return <Tag color="volcano">معوق</Tag>
  if (daysLate > 0) return <Tag color="orange">دارای تأخیر</Tag>
  return <Tag color="blue">در انتظار</Tag>
}

export default function DebtCenter() {
  const qc = useQueryClient()
  const screens = Grid.useBreakpoint()
  const isMobile = !!screens.xs && !screens.sm

  const [state, setState] = useSessionState('debts:v1', {
    q: '',
    only_overdue: true,
    min_days_late: undefined,
    sort_by: 'days_late',
    sort_dir: 'desc',
    pageSize: 25,
  })

  const tableView = useTableView('table.debts.v1', { pageSize: state.pageSize || 25, dense: false })
  const dq = useDebouncedValue(state.q, 300)

  const { data, isFetching } = useQuery({
    queryKey: ['debts', state.only_overdue, state.min_days_late, state.sort_by, state.sort_dir, dq],
    queryFn: () => fetchDebts({
      q: dq || undefined,
      only_overdue: state.only_overdue || undefined,
      min_days_late: state.min_days_late ?? undefined,
      sort_by: state.sort_by,
      sort_dir: state.sort_dir,
    }),
    keepPreviousData: true,
  })

  const rows = Array.isArray(data) ? data : []

  // Drawer
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState(null)
  const [tx, setTx] = useState([])
  const [fu, setFu] = useState([])
  const [loadingDrawer, setLoadingDrawer] = useState(false)

  const [payForm] = Form.useForm()
  const [fuForm] = Form.useForm()

  async function openDrawer(row) {
    setActive(row)
    setOpen(true)
    setLoadingDrawer(true)
    try {
      const [t, f] = await Promise.all([
        listTransactions(row.payment_item_id),
        listFollowups(row.payment_item_id),
      ])
      setTx(t || [])
      setFu(f || [])
      payForm.resetFields()
      fuForm.resetFields()
      fuForm.setFieldsValue({ channel: 'call' })
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.message || 'خطا'
      message.error(typeof msg === 'string' ? msg : JSON.stringify(msg))
    } finally {
      setLoadingDrawer(false)
    }
  }

  async function submitPayment() {
    const v = await payForm.validateFields()
    try {
      await addTransaction(active.payment_item_id, {
        paid_date_j: v.paid_date_j,
        method: v.method,
        description: v.description,
        amount_rial: Number(String(v.amount_rial).replaceAll(',', '')),
      })
      message.success('پرداخت ثبت شد')
      const t = await listTransactions(active.payment_item_id)
      setTx(t || [])
      qc.invalidateQueries({ queryKey: ['debts'] })
      qc.invalidateQueries({ queryKey: ['installments'] })
      payForm.resetFields()
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.message || 'خطا'
      message.error(typeof msg === 'string' ? msg : JSON.stringify(msg))
    }
  }

  async function submitFollowup() {
    const v = await fuForm.validateFields()
    try {
      await createFollowup(active.payment_item_id, {
        channel: v.channel,
        result: v.result || null,
        note: v.note || null,
        next_followup_date_j: v.next_followup_date_j || null,
        sms_text: v.sms_text || null,
      })
      message.success('پیگیری ثبت شد')
      const f = await listFollowups(active.payment_item_id)
      setFu(f || [])
      qc.invalidateQueries({ queryKey: ['debts'] })
      fuForm.resetFields()
      fuForm.setFieldsValue({ channel: 'call' })
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.message || 'خطا'
      message.error(typeof msg === 'string' ? msg : JSON.stringify(msg))
    }
  }

  const marketerValues = useMemo(() => uniq((rows || []).map((r) => r.marketer_name || r.marketer).filter(Boolean)), [rows])
  const policyNumberValues = useMemo(() => uniq((rows || []).map((r)=>r.policy_number)), [rows])
  const policyholderValues = useMemo(() => uniq((rows || []).map((r)=>r.policyholder_name)), [rows])
  const dueValues = useMemo(() => uniq((rows || []).map((r)=>r.due_date_j)), [rows])
  const remainValues = useMemo(() => uniq((rows || []).map((r)=>r.remain_rial)), [rows])
  const lateValues = useMemo(() => uniq((rows || []).map((r)=>r.days_late)), [rows])

  const columns = useMemo(() => ([
    { title: 'بیمه‌گذار', dataIndex: 'policyholder_name', key: 'policyholder_name', width: 200, ellipsis: true, sorter: true,
      ...makeGsColumnFilter({ key: 'policyholder_name', getValues: () => policyholderValues }),
    },
    { title: 'بازاریاب', dataIndex: 'marketer_name', key: 'marketer_name', width: 140, ellipsis: true, sorter: true, render: (v, r) => v || r.marketer || '—', ...makeGsColumnFilter({ key: 'marketer_name', getValues: () => marketerValues }) },
    { title: 'شماره بیمه‌نامه', dataIndex: 'policy_number', key: 'policy_number', width: 170, ellipsis: true, sorter: true,
      ...makeGsColumnFilter({ key: 'policy_number', getValues: () => policyNumberValues }),
    },
    { title: 'رشته', dataIndex: 'insurance_line', key: 'insurance_line', width: 140, ellipsis: true },
    { title: 'شناسه بدهی', dataIndex: 'secondary_debt_id', key: 'secondary_debt_id', width: 200, ellipsis: true, render: (v) => v || '—' },
    { title: 'سررسید', dataIndex: 'due_date_j', key: 'due_date_j', width: 115, sorter: true,
      ...makeGsColumnFilter({ key: 'due_date_j', getValues: () => dueValues }),
    },
    { title: 'مانده', dataIndex: 'remain_rial', key: 'remain_rial', width: 150, sorter: true, render: (v) => fmtRial(v),
      ...makeGsColumnFilter({ key: 'remain_rial', getValues: () => remainValues, renderValue: (v)=>fmtRial(v) }),
    },
    { title: 'روزهای تأخیر', dataIndex: 'days_late', key: 'days_late', width: 120, sorter: true, render: (v, r) => r.remain_rial > 0 ? v : 0,
      ...makeGsColumnFilter({ key: 'days_late', getValues: () => lateValues }),
    },
    { title: 'وضعیت', key: 'status', width: 110, render: (_, r) => <RiskTag daysLate={r.days_late} remain={r.remain_rial} /> },
    {
      title: 'اقدام',
      key: 'act',
      fixed: 'left',
      width: 120,
      render: (_, r) => <Button type="primary" size="small" onClick={() => openDrawer(r)}>اقدام سریع</Button>,
    },
  ]), [])

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card className="sama-card" styles={{ body: { padding: 16 } }}>
        <Space direction="vertical" size={12} style={{ width: '100%' }}>
          <Space style={{ width: '100%', justifyContent: 'space-between' }} wrap>
            <Typography.Title level={4} style={{ margin: 0, fontWeight: 900 }}>
              مرکز بدهی
            </Typography.Title>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              بدهی = اقساط ثانویه (بدون شناسه سیستمی) که هنوز پرداخت نشده‌اند.
            </Typography.Text>
          </Space>

          <Space wrap style={{ width: '100%' }}>
            <Input
              value={state.q}
              onChange={(e) => setState((s) => ({ ...s, q: e.target.value }))}
              placeholder="جستجو (نام/شماره/موبایل/کدملی)"
              allowClear
              style={{ minWidth: 280 }}
            />
            <Select
              value={state.only_overdue ? '1' : '0'}
              onChange={(v) => setState((s) => ({ ...s, only_overdue: v === '1' }))}
              style={{ width: 170 }}
              options={[
                { value: '1', label: 'فقط بدهی باز' },
                { value: '0', label: 'همه' },
              ]}
            />
            <Select
              value={state.min_days_late ?? undefined}
              onChange={(v) => setState((s) => ({ ...s, min_days_late: v }))}
              allowClear
              placeholder="حداقل تأخیر"
              style={{ width: 170 }}
              options={[
                { value: 10, label: '۱۰ روز' },
                { value: 30, label: '۳۰ روز' },
                { value: 60, label: '۶۰ روز' },
              ]}
            />
          </Space>
        </Space>
      </Card>

      <Card className="sama-card" styles={{ body: { padding: 0 } }} extra={<TableViewBar view={tableView.view} onChange={tableView.save} />}>
        <Table
          size={tableView.view.dense ? 'small' : 'middle'}
          rowKey="payment_item_id"
          loading={isFetching}
          columns={columns}
          dataSource={rows}
          tableLayout="fixed"
          pagination={{
            pageSize: tableView.view.pageSize || state.pageSize,
            showSizeChanger: true,
            pageSizeOptions: [10, 25, 50, 100],
            onShowSizeChange: (_, ps) => {
              setState((s) => ({ ...s, pageSize: ps }))
              tableView.save({ pageSize: ps })
            },
          }}
          onChange={(_, __, sorter) => {
            const s = Array.isArray(sorter) ? sorter[0] : sorter
            if (!s?.field || !s?.order) return
            setState((st) => ({ ...st, sort_by: String(s.field), sort_dir: s.order === 'ascend' ? 'asc' : 'desc' }))
          }}
        />
      </Card>

      <Drawer
        open={open}
        onClose={() => setOpen(false)}
        title={active ? `اقدام سریع — ${active.policy_number}` : 'اقدام سریع'}
        placement={isMobile ? 'bottom' : 'right'}
        height={isMobile ? '78vh' : undefined}
        width={isMobile ? undefined : 720}
        destroyOnClose
      >
        {!active ? null : (
          <Space direction="vertical" size={12} style={{ width: '100%' }}>
            <Card size="small" className="sama-card">
              <Space direction="vertical" size={6} style={{ width: '100%' }}>
                <Space wrap style={{ width: '100%', justifyContent: 'space-between' }}>
                  <Typography.Text style={{ fontWeight: 800 }}>{active.policyholder_name}</Typography.Text>
                  <RiskTag daysLate={active.days_late} remain={active.remain_rial} />
                </Space>
                <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                  مورد بیمه: {active.insured_item || '—'} • موبایل: {active.mobile || '—'}
                </Typography.Text>
                <Typography.Text>
                  مانده: <b>{fmtRial(active.remain_rial)}</b> ریال • سررسید: <b>{active.due_date_j}</b> • شناسه بدهی: <b>{active.secondary_debt_id || '—'}</b>
                </Typography.Text>
              </Space>
            </Card>

            <Tabs
              items={[
                {
                  key: 'tx',
                  label: 'سوابق پرداخت',
                  children: (
                    <Table
                      size="small"
                      rowKey="id"
                      loading={loadingDrawer}
                      dataSource={tx}
                      pagination={false}
                      columns={[
                        { title: 'تاریخ', dataIndex: 'paid_date_j', key: 'paid_date_j', width: 120 },
                        { title: 'نحوه پرداخت', dataIndex: 'method', key: 'method', width: 140 },
                        { title: 'مبلغ', dataIndex: 'amount_rial', key: 'amount_rial', width: 160, render: (v) => fmtRial(v) },
                        { title: 'شرح', dataIndex: 'description', key: 'description', ellipsis: true },
                      ]}
                      tableLayout="fixed"
                    />
                  ),
                },
                {
                  key: 'pay',
                  label: 'ثبت پرداخت',
                  children: (
                    <Form form={payForm} layout="vertical">
                      <Space wrap style={{ width: '100%' }}>
                        <Form.Item name="paid_date_j" label="تاریخ پرداخت" rules={[{ required: true, message: 'الزامی' }]} style={{ width: 220 }}>
                          <JalaliDatePicker />
                        </Form.Item>
                        <Form.Item name="method" label="نحوه پرداخت" rules={[{ required: true, message: 'الزامی' }]} style={{ width: 220 }}>
                          <Select
                            options={[
                              { value: 'pos', label: 'POS' },
                              { value: 'gateway', label: 'درگاه اینترنتی' },
                              { value: 'agent_account', label: 'واریز به حساب نماینده' },
                              { value: 'cash', label: 'نقدی' },
                              { value: 'cheque', label: 'چک' },
                              { value: 'transfer', label: 'کارت‌به‌کارت/انتقال' },
                            ]}
                          />
                        </Form.Item>
                        <Form.Item name="amount_rial" label="مبلغ (ریال)" rules={[{ required: true, message: 'الزامی' }]} style={{ width: 220 }}>
                          <Input inputMode="numeric" />
                        </Form.Item>
                      </Space>
                      <Form.Item name="description" label="شرح" rules={[{ required: true, message: 'الزامی' }]}>
                        <Input.TextArea rows={3} />
                      </Form.Item>
                      <Button type="primary" onClick={submitPayment} block>
                        ثبت پرداخت
                      </Button>
                    </Form>
                  ),
                },
                {
                  key: 'fu',
                  label: 'پیگیری',
                  children: (
                    <Space direction="vertical" size={12} style={{ width: '100%' }}>
                      <Form form={fuForm} layout="vertical">
                        <Space wrap style={{ width: '100%' }}>
                          <Form.Item name="channel" label="کانال" rules={[{ required: true, message: 'الزامی' }]} style={{ width: 200 }}>
                            <Select options={[{ value: 'call', label: 'تماس' }, { value: 'sms', label: 'پیامک' }]} />
                          </Form.Item>
                          <Form.Item name="next_followup_date_j" label="تاریخ پیگیری بعدی" style={{ width: 220 }}>
                            <JalaliDatePicker allowClear />
                          </Form.Item>
                        </Space>
                        <Form.Item name="result" label="نتیجه">
                          <Input />
                        </Form.Item>
                        <Form.Item name="note" label="یادداشت">
                          <Input.TextArea rows={2} />
                        </Form.Item>
                        <Form.Item name="sms_text" label="متن پیامک (در صورت نیاز)">
                          <Input.TextArea rows={2} />
                        </Form.Item>
                        <Button onClick={submitFollowup} type="primary" block>
                          ثبت پیگیری
                        </Button>
                      </Form>

                      <Table
                        size="small"
                        rowKey="id"
                        dataSource={fu}
                        pagination={{ pageSize: 5 }}
                        columns={[
                          { title: 'تاریخ', dataIndex: 'followup_date_j', key: 'followup_date_j', width: 120 },
                          { title: 'کانال', dataIndex: 'channel', key: 'channel', width: 90, render: (v) => v === 'sms' ? <Tag color="geekblue">پیامک</Tag> : <Tag color="purple">تماس</Tag> },
                          { title: 'نتیجه', dataIndex: 'result', key: 'result', width: 160, ellipsis: true },
                          { title: 'پیگیری بعدی', dataIndex: 'next_followup_date_j', key: 'next_followup_date_j', width: 140 },
                          { title: 'یادداشت', dataIndex: 'note', key: 'note', ellipsis: true },
                        ]}
                        tableLayout="fixed"
                      />
                    </Space>
                  ),
                },
              ]}
            />
          </Space>
        )}
      </Drawer>
    </Space>
  )
}
