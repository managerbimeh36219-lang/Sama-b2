import React, { useMemo, useState } from 'react'
import {
  Alert,
  Button,
  Card,
  Drawer,
  Descriptions,
  Divider,
  Dropdown,
  Form,
  Input,
  Modal,
  Select,
  Space,
  Table,
  Tabs,
  Tag,
  Typography,
  Upload,
  Grid,
  message,
} from 'antd'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useUserSetting } from '../hooks/useUserSetting.js'
import { MoreOutlined, RightOutlined } from '@ant-design/icons'

import {
  addTransaction,
  createFollowup,
  deleteTransaction,
  fetchInstallments,
  listFollowups,
  listTransactions,
  uploadTransactionAttachment,
  updateTransaction,
} from '../api/installments.js'
import { http } from '../api/http.js'
import { listSmsTemplates } from '../api/smsTemplates.js'
import { sendSms as sendRealSms, smsStatus as getSmsStatus } from '../api/sms.js'
import { useDebouncedValue, useSessionState } from '../utils/useSessionState.js'
import SmartFiltersBar from '../components/SmartFiltersBar.jsx'
import SmartTable from '../components/SmartTable.jsx'
import { useMobileRecordDrawer } from '../hooks/useMobileRecordDrawer'
import MobileRecordDrawer from '../components/MobileRecordDrawer'
import { makeGsColumnFilter, uniq } from '../utils/gsFilters.jsx'
import JalaliDatePicker from '../components/JalaliDatePicker.jsx'
import { commissionsApi } from '../api/commissions.js'
import { useTableView } from '../hooks/useTableView'
import TableViewBar from '../components/TableViewBar'

function fmtRial(n) {
  try {
    return new Intl.NumberFormat('fa-IR').format(n ?? 0)
  } catch {
    return String(n ?? '')
  }
}

const paymentMethods = [
  'POS',
  'درگاه اینترنتی',
  'واریز به حساب نماینده',
  'نقدی',
  'چک',
  'سایر',
]

function statusTag(row) {
  if (row.status === 'paid') return <Tag color="green">تسویه</Tag>
  if (row.status === 'partial') return <Tag color="blue">نیمه‌پرداخت</Tag>
  if (row.is_overdue) return <Tag color="red">معوق</Tag>
  return <Tag color="orange">بدهکار</Tag>
}

function buildSms(template, row) {
  const safe = (v) => (v ?? '')
  const paymentId = safe(row.system_payment_id || row.secondary_debt_id || '')
  const amount = safe(row.amount_rial)
  const due = safe(row.due_date_j)
  const policyDue = safe(row.policy_end_date_j || row.end_date_j || '')
  const insured = safe(row.insured_item || row.insurance_line || '')
  const name = safe(row.policyholder_name)
  const polNo = safe(row.policy_number)

  // Persian placeholders (preferred)
  let out = (template || '')
    .replaceAll('{{نام_بیمه_گذار}}', name)
    .replaceAll('{{شماره_بیمه_نامه}}', polNo)
    .replaceAll('{{مورد_بیمه}}', insured)
    .replaceAll('{{شناسه_پرداخت}}', paymentId)
    .replaceAll('{{تاریخ_سررسید}}', due)
    .replaceAll('{{تاریخ_سررسید_بیمه_نامه}}', policyDue)
    .replaceAll('{{مبلغ}}', amount)

  // Backward compatible placeholders
  out = out
    .replaceAll('{name}', name)
    .replaceAll('{policy_number}', polNo)
    .replaceAll('{due_date}', due)
    .replaceAll('{policy_due_date}', policyDue)
    .replaceAll('{amount}', amount)

  return out
}

export default function InstallmentsCenter() {
  const screens = Grid.useBreakpoint()
  const isMobile = !!screens.xs && !screens.md
  const qc = useQueryClient()

  // State persists across navigation
  const [state, setState] = useSessionState('installments:antd:v1', {
    global_q: '',
    tab: 'all',
    q: '',
    due_from: '',
    due_to: '',
    is_system: 'all',
    insurance_line: '',
    sortField: 'due_date_j',
    sortOrder: 'ascend',
    page: 1,
    pageSize: 25,
  })

  const tableView = useTableView('table.installments.v1', { pageSize: state.pageSize || 25, dense: false })

  const insuranceLinesQ = useQuery({
    queryKey: ['insurance_lines'],
    queryFn: () => commissionsApi.listInsuranceLines(),
  })

  const viewSetting = useUserSetting('view.installments')
  const view = useMemo(() => {
    try {
      return viewSetting.data?.value ? JSON.parse(viewSetting.data.value) : null
    } catch {
      return null
    }
  }, [viewSetting.data])

  const dq = useDebouncedValue(state.q, 350)
  const dGlobal = useDebouncedValue(state.global_q, 350)
  const dFrom = useDebouncedValue(state.due_from, 350)
  const dTo = useDebouncedValue(state.due_to, 350)
  const dIsSystem = useDebouncedValue(state.is_system, 350)
  const dLine = useDebouncedValue(state.insurance_line, 350)

  const { data, isFetching, error } = useQuery({
    queryKey: [
      'installments',
      {
        tab: state.tab,
        q: undefined,
        due_from: dFrom,
        due_to: dTo,
        is_system: dIsSystem,
        insurance_line: dLine,
        sortField: state.sortField,
        sortOrder: state.sortOrder,
        page: state.page,
        pageSize: state.pageSize,
      },
    ],
    queryFn: async () => {
      const sort_dir = state.sortOrder === 'ascend' ? 'asc' : 'desc'
      return await fetchInstallments({
        status: state.tab,
        q: undefined,
        due_from: dFrom || undefined,
        due_to: dTo || undefined,
        is_system: dIsSystem,
        insurance_line: dLine || undefined,
        sort_by: state.sortField,
        sort_dir,
        page: state.page,
        page_size: tableView.view.pageSize || state.pageSize,
      })
    },
    keepPreviousData: true,
  })

  const rows = (data?.items || []).map((r) => ({ ...r, key: r.payment_item_id, id: r.payment_item_id }))
  const viewRows = rows

  const lineValues = React.useMemo(() => uniq((rows || []).map((r) => r.insurance_line)), [rows])
  const marketerValues = React.useMemo(() => uniq((rows || []).map((r) => r.marketer)), [rows])
  const policyNumberValues = React.useMemo(() => uniq((rows || []).map((r) => r.policy_number)), [rows])
  const policyholderValues = React.useMemo(() => uniq((rows || []).map((r) => r.policyholder_name)), [rows])
  const mobileValues = React.useMemo(() => uniq((rows || []).map((r) => r.mobile)), [rows])
  const dueValues = React.useMemo(() => uniq((rows || []).map((r) => r.due_date_j)), [rows])
  const amountValues = React.useMemo(() => uniq((rows || []).map((r) => r.amount_rial)), [rows])
  const paidValues = React.useMemo(() => uniq((rows || []).map((r) => r.paid_amount_rial)), [rows])
  const statusValues = React.useMemo(() => uniq((rows || []).map((r) => r.status)), [rows])

  const hasSecondaryByPolicy = useMemo(() => {
    const m = {}
    for (const r of rows) {
      if (!r.is_system) m[r.policy_number] = true
    }
    return m
  }, [rows])

  // ------------------------- Payments modal
  const [payOpen, setPayOpen] = useState(false)
  const [payRow, setPayRow] = useState(null)
  const [txList, setTxList] = useState([])
  const [txLoading, setTxLoading] = useState(false)
  const [txEditId, setTxEditId] = useState(null)
  const [txFile, setTxFile] = useState(null)
  const [payForm] = Form.useForm()

  async function openPay(row) {
    setPayRow(row)
    setPayOpen(true)
    setTxEditId(null)
    payForm.resetFields()
    payForm.setFieldsValue({
      paid_date_j: '',
      method: undefined,
      amount_rial: String(Math.max(0, (row.amount_rial || 0) - (row.paid_amount_rial || 0))),
      description: '',
      payer: 'policyholder',
    })
    setTxFile(null)

    setTxLoading(true)
    try {
      const list = await listTransactions(row.payment_item_id)
      setTxList(list || [])
    } finally {
      setTxLoading(false)
    }
  }

  async function saveTransaction() {
    if (!payRow?.payment_item_id) { message.error('شناسه قسط نامعتبر است'); return }
    const v = await payForm.validateFields()
    const payload = {
      paid_date_j: v.paid_date_j,
      method: v.method,
      amount_rial: Number(v.amount_rial),
      description: v.description,
    }

    setTxLoading(true)
    try {
      if (txEditId) {
        await updateTransaction(txEditId, payload)
        if (txFile) {
          await uploadTransactionAttachment(txEditId, txFile)
        }
        message.success('پرداخت ویرایش شد')
      } else {
        const created = await addTransaction(payRow.payment_item_id, payload)
        if (txFile && created?.id) {
          await uploadTransactionAttachment(created.id, txFile)
        }
        message.success('پرداخت ثبت شد')
      }
      const list = await listTransactions(payRow.payment_item_id)
      setTxList(list || [])
      setTxEditId(null)
      payForm.resetFields()
      setTxFile(null)
      // refresh list
      qc.invalidateQueries({ queryKey: ['installments'] })
      qc.invalidateQueries({ queryKey: ['policies'] })
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.message || 'خطا'
      message.error(typeof msg === 'string' ? msg : JSON.stringify(msg))
    } finally {
      setTxLoading(false)
    }
  }

  // ------------------------- Followups drawer
  const [fuOpen, setFuOpen] = useState(false)
  const [fuRow, setFuRow] = useState(null)
  const [fuList, setFuList] = useState([])
  const [templates, setTemplates] = useState([])
  const [fuLoading, setFuLoading] = useState(false)
  const [fuForm] = Form.useForm()

  // ------------------------- Policy drawer (overview)
  const [polOpen, setPolOpen] = useState(false)
  const [polLoading, setPolLoading] = useState(false)
  const [polData, setPolData] = useState(null)

  async function openPolicyDrawer(row) {
    if (!row?.policy_id) return
    setPolOpen(true)
    setPolLoading(true)
    try {
      const res = await http.get(`/policies/${row.policy_id}`)
      setPolData(res.data)
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.message || 'خطا'
      message.error(typeof msg === 'string' ? msg : JSON.stringify(msg))
    } finally {
      setPolLoading(false)
    }
  }

  async function openFollowups(row) {
    setFuRow(row)
    setFuOpen(true)
    fuForm.resetFields()
    fuForm.setFieldsValue({
      channel: 'call',
      followup_date_j: '',
      result: '',
      note: '',
      next_followup_date_j: '',
      template_id: undefined,
      sms_text: '',
    })
    setFuLoading(true)
    try {
      const [f, t] = await Promise.all([
        listFollowups(row.payment_item_id),
        templates.length ? Promise.resolve(templates) : listSmsTemplates(),
      ])
      setFuList(f || [])
      setTemplates(t || [])
    } finally {
      setFuLoading(false)
    }
  }

  async function saveFollowup() {
    const v = await fuForm.validateFields()
    const payload = {
      channel: v.channel,
      result: v.result,
      note: v.note,
      next_followup_date_j: v.next_followup_date_j,
      sms_template_id: v.template_id || null,
      sms_text: v.sms_text || null,
    }
    setFuLoading(true)
    try {
      await createFollowup(fuRow.payment_item_id, payload)
      message.success('پیگیری ثبت شد')
      const f = await listFollowups(fuRow.payment_item_id)
      setFuList(f || [])
      fuForm.resetFields()
      fuForm.setFieldsValue({ channel: 'call' })
      qc.invalidateQueries({ queryKey: ['installments'] })
    } catch (e) {
      const msg = e?.response?.data?.detail || e?.message || 'خطا'
      message.error(typeof msg === 'string' ? msg : JSON.stringify(msg))
    } finally {
      setFuLoading(false)
    }
  }

  const columns = [
    {
      title: '',
      key: 'open_policy',
      width: 46,
      fixed: 'right',
      render: (_, r) => (
        <Button
          size="small"
          shape="circle"
          icon={<RightOutlined />}
          onClick={() => openPolicyDrawer(r)}
        />
      ),
    },
    {
      title: 'شماره بیمه‌نامه',
      dataIndex: 'policy_number',
      key: 'policy_number',
      width: 160,
      ellipsis: true,
      sorter: true,
      ...makeGsColumnFilter({ key: 'policy_number', getValues: () => policyNumberValues }),
    },
    {
      title: 'بازاریاب',
      dataIndex: 'marketer',
      key: 'marketer',
      width: 150,
      ellipsis: true,
      sorter: true,
      ...makeGsColumnFilter({ key: 'marketer', getValues: () => marketerValues }),
    },
    {
      title: 'بیمه‌گذار',
      dataIndex: 'policyholder_name',
      key: 'policyholder_name',
      width: 190,
      ellipsis: true,
      sorter: true,
      ...makeGsColumnFilter({ key: 'policyholder_name', getValues: () => policyholderValues }),
    },
    {
      title: 'موبایل',
      dataIndex: 'mobile',
      key: 'mobile',
      width: 130,
      ellipsis: true,
      sorter: true,
      ...makeGsColumnFilter({ key: 'mobile', getValues: () => mobileValues }),
    },
    {
      title: 'سررسید',
      dataIndex: 'due_date_j',
      key: 'due_date_j',
      width: 120,
      sorter: true,
      ...makeGsColumnFilter({ key: 'due_date_j', getValues: () => dueValues }),
    },
    {
      title: 'مبلغ',
      dataIndex: 'amount_rial',
      key: 'amount_rial',
      width: 140,
      align: 'left',
      sorter: true,
      render: (v) => fmtRial(v),
      ...makeGsColumnFilter({ key: 'amount_rial', getValues: () => amountValues, renderValue: (v)=>fmtRial(v) }),
    },
    {
      title: 'پرداخت‌شده',
      dataIndex: 'paid_amount_rial',
      key: 'paid_amount_rial',
      width: 150,
      align: 'left',
      sorter: true,
      render: (v) => fmtRial(v),
    },
    {
      title: 'شناسه',
      key: 'id_show',
      width: 190,
      ellipsis: true,
      render: (_, r) => r.system_payment_id || r.secondary_debt_id || '',
    },
    {
      title: 'وضعیت',
      key: 'status',
      width: 110,
      sorter: true,
      ...makeGsColumnFilter({ key: 'status', getValues: () => statusValues }),
      render: (_, r) => statusTag(r),
    },
    {
      title: 'عملیات',
      key: 'actions',
      fixed: 'left',
      width: 210,
      render: (_, r) => {
        const currentUser = (() => { try { return JSON.parse(localStorage.getItem('sama_user') || 'null') } catch { return null } })()
        const isMarketer = currentUser?.user_type === 'marketer'
        const items = []
        if (r.is_system && r.system_payment_id) {
          items.push({
            key: 'pay_online',
            label: 'پرداخت اینترنتی',
            onClick: () => {
              const url = `https://epay.iraninsurance.ir/payment/controlCode/${r.system_payment_id}`
              window.open(url, '_blank', 'noopener,noreferrer')
            },
          })
        }
        items.push({
          key: 'pay_manual',
          label: 'ثبت پرداخت',
          onClick: () => openPay(r),
        })
        if (!isMarketer) {
          items.push({
            key: 'followup',
            label: 'پیگیری',
            onClick: () => openFollowups(r),
          })
        }

        return (
          <Dropdown menu={{ items }} trigger={['click']}>
            <Button size="small" icon={<MoreOutlined />}>عملیات</Button>
          </Dropdown>
        )
      },
    },
  ]

  const mobileDrawer = useMobileRecordDrawer({ title: 'جزئیات قسط', columns })

  const errText = error?.response?.data?.detail || error?.message

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      {errText && (
        <Alert
          type="error"
          showIcon
          message={typeof errText === 'string' ? errText : JSON.stringify(errText)}
        />
      )}

      <Card className="sama-card" styles={{ body: { padding: 12 } }}><Typography.Title level={5} style={{ margin: 0 }}>مدیریت اقساط</Typography.Title></Card>

      <Card className="sama-card" styles={{ body: { padding: 16 } }}>
        <Space direction="vertical" size={12} style={{ width: '100%' }}>

          <Tabs
            activeKey={state.tab}
            onChange={(k) => setState((s) => ({ ...s, tab: k, page: 1 }))}
            items={[
              { key: 'all', label: 'همه' },
              { key: 'unpaid', label: 'بدهکار' },
              { key: 'overdue', label: 'معوق' },
              { key: 'due_soon', label: 'نزدیک‌به‌سررسید' },
            ]}
          />

          <Space wrap style={{ width: '100%' }}>
            <Input
              value={state.due_from}
              onChange={(e) => setState((s) => ({ ...s, due_from: e.target.value, page: 1 }))}
              placeholder="از سررسید (1403/01/01)"
              style={{ width: 190 }}
            />
            <Input
              value={state.due_to}
              onChange={(e) => setState((s) => ({ ...s, due_to: e.target.value, page: 1 }))}
              placeholder="تا سررسید (1403/12/29)"
              style={{ width: 190 }}
            />
            <Select
              value={state.is_system}
              onChange={(v) => setState((s) => ({ ...s, is_system: v, page: 1 }))}
              style={{ width: 180 }}
              options={[
                { value: 'all', label: 'همه اقساط' },
                { value: 'true', label: 'فقط سیستمی' },
                { value: 'false', label: 'فقط ثانویه' },
              ]}
            />
            <Select
              value={state.insurance_line || undefined}
              onChange={(v) => setState((s) => ({ ...s, insurance_line: v || '', page: 1 }))}
              placeholder="رشته"
              allowClear
              style={{ width: 200 }}
              options={
                (insuranceLinesQ.data || []).map((x) => ({ value: x.title || x, label: x.title || x }))
              }
            />
          </Space>
        </Space>
      </Card>

      <Card className="sama-card" styles={{ body: { padding: 0 } }} extra={<TableViewBar view={tableView.view} onChange={tableView.save} />}>
        <Table
          size={tableView.view.dense ? 'small' : 'middle'}
          rowKey="payment_item_id"
          columns={columns}
          dataSource={viewRows}
          loading={isFetching}
          view={view || {}}
          onSaveView={async (v) => {
            await viewSetting.save(JSON.stringify(v || {}))
          }}
          onResetView={async () => {
            await viewSetting.save(null)
          }}
          pagination={{
            current: state.page,
            pageSize: tableView.view.pageSize || state.pageSize,
            total: data?.total || 0,
            showSizeChanger: true,
            pageSizeOptions: [10, 25, 50, 100],
            onChange: (page, pageSize) => {
              setState((s) => ({ ...s, page, pageSize }))
              tableView.save({ pageSize })
            },
          }}
          tableLayout="fixed"
          onRow={
            isMobile
              ? (record) => ({
                  onClick: () => mobileDrawer.open(record),
                  style: { cursor: 'pointer' },
                })
              : undefined
          }
          rowClassName={(r) =>
            hasSecondaryByPolicy[r.policy_number] && r.is_system ? 'row-system-on-secondary' : ''
          }
          onChange={(_, __, sorter) => {
            const s = Array.isArray(sorter) ? sorter[0] : sorter
            if (!s?.field || !s?.order) return
            setState((st) => ({ ...st, sortField: s.field, sortOrder: s.order }))
          }}
        />
      </Card>

      {isMobile ? <MobileRecordDrawer controller={mobileDrawer} /> : null}

      {/* Payments Modal */}
      <Modal
        title="ثبت/ویرایش پرداخت"
        open={payOpen}
        onCancel={() => setPayOpen(false)}
        onOk={saveTransaction}
        okText={txEditId ? 'ذخیره ویرایش' : 'ثبت پرداخت'}
        confirmLoading={txLoading}
        destroyOnClose
      >
        {payRow && (
          <Space direction="vertical" size={10} style={{ width: '100%' }}>
            <Typography.Text type="secondary">
              بیمه‌نامه: {payRow.policy_number} — سررسید: {payRow.due_date_j}
            </Typography.Text>

            <Divider style={{ margin: '8px 0' }} />

            <Typography.Text style={{ fontWeight: 700 }}>پرداخت‌های ثبت‌شده</Typography.Text>
            <Table
              size="small"
              rowKey="id"
              loading={txLoading}
              dataSource={txList || []}
              pagination={false}
              columns={[
                { title: 'تاریخ', dataIndex: 'paid_date_j', key: 'paid_date_j', width: 110 },
                { title: 'روش', dataIndex: 'method', key: 'method', width: 160, ellipsis: true },
                {
                  title: 'مبلغ',
                  dataIndex: 'amount_rial',
                  key: 'amount_rial',
                  width: 120,
                  render: fmtRial,
                },
                { title: 'شرح', dataIndex: 'description', key: 'description', ellipsis: true },
                {
                  title: 'ثبت توسط',
                  dataIndex: 'created_by_name',
                  key: 'created_by_name',
                  width: 160,
                  render: (v) => v || '-'
                },
                {
                  title: 'عملیات',
                  key: 'act',
                  width: 160,
                  render: (_, r) => (
                    <Space>
                      <Button size="small" onClick={() => {
                        setTxEditId(r.id)
                        payForm.setFieldsValue({
                          paid_date_j: r.paid_date_j,
                          method: r.method,
                          amount_rial: String(r.amount_rial || ''),
                          description: r.description,
                          payer: 'policyholder',
                        })
                      }}>ویرایش</Button>
                      <Button size="small" danger onClick={async () => {
                        try {
                          await deleteTransaction(r.id)
                          message.success('حذف شد')
                          const list = await listTransactions(payRow.payment_item_id)
                          setTxList(list || [])
                          qc.invalidateQueries({ queryKey: ['installments'] })
                          qc.invalidateQueries({ queryKey: ['policies'] })
                        } catch (e) {
                          message.error(e?.response?.data?.detail || 'خطا در حذف')
                        }
                      }}>حذف</Button>
                    </Space>
                  ),
                },
              ]}
              tableLayout="fixed"
            />

            <Divider style={{ margin: '12px 0' }} />

            <Typography.Text style={{ fontWeight: 700 }}>
              {txEditId ? 'ویرایش پرداخت' : 'ثبت پرداخت جدید'}
            </Typography.Text>

            <Form form={payForm} layout="vertical">
              <Space wrap style={{ width: '100%' }}>
                <Form.Item
                  label="تاریخ پرداخت (شمسی)"
                  name="paid_date_j"
                  rules={[{ required: true, message: 'تاریخ الزامی است' }]}
                >
                  <JalaliDatePicker style={{ width: 180 }} />
                </Form.Item>
                <Form.Item
                  label="نحوه پرداخت"
                  name="method"
                  rules={[{ required: true, message: 'نحوه پرداخت الزامی است' }]}
                >
                  <Select
                    placeholder="انتخاب کنید"
                    style={{ width: 200 }}
                    options={paymentMethods.map((x) => ({ value: x, label: x }))}
                  />
                </Form.Item>
                <Form.Item
                  label="پرداخت‌کننده"
                  name="payer"
                  rules={[{ required: true, message: 'الزامی' }]}
                >
                  <Select
                    style={{ width: 220 }}
                    options={[
                      { value: 'policyholder', label: 'بیمه‌گذار پرداخت کرده' },
                      { value: 'agency', label: 'از طرف نمایندگی پرداخت شده' },
                    ]}
                  />
                </Form.Item>

                <Form.Item
                  label="مبلغ (ریال)"
                  name="amount_rial"
                  rules={[
                    { required: true, message: 'مبلغ الزامی است' },
                    {
                      validator: (_, v) =>
                        Number(v) > 0 ? Promise.resolve() : Promise.reject(new Error('مبلغ باید بیشتر از صفر باشد')),
                    },
                  ]}
                >
                  <Input style={{ width: 180 }} />
                </Form.Item>
              </Space>
              <Form.Item
                label="شرح"
                name="description"
                rules={[{ required: true, message: 'شرح الزامی است' }]}
              >
                <Input.TextArea rows={3} placeholder="مثلاً پرداخت از طریق POS" />
              </Form.Item>

              <Form.Item label="آپلود رسید (اختیاری)">
                <Upload
                  maxCount={1}
                  beforeUpload={(file) => {
                    setTxFile(file)
                    return false
                  }}
                  onRemove={() => setTxFile(null)}
                  fileList={txFile ? [txFile] : []}
                >
                  <Button>انتخاب فایل</Button>
                </Upload>
              </Form.Item>
            </Form>
          </Space>
        )}
      </Modal>

      {/* Followups Drawer */}
      <Modal
        title="پیگیری"
        open={fuOpen}
        onCancel={() => setFuOpen(false)}
        width={520}
        destroyOnClose
      >
        {fuRow && (
          <Space direction="vertical" size={12} style={{ width: '100%' }}>
            <Typography.Text type="secondary">
              بیمه‌نامه: {fuRow.policy_number} — سررسید: {fuRow.due_date_j}
            </Typography.Text>

            <Card size="small" className="sama-card">
              <Typography.Text style={{ fontWeight: 700 }}>سوابق پیگیری</Typography.Text>
              <Table
                size="small"
                rowKey="id"
                loading={fuLoading}
                dataSource={fuList || []}
                pagination={false}
                columns={[
                  { title: 'کانال', dataIndex: 'channel', key: 'channel', width: 80 },
                  { title: 'تاریخ', dataIndex: 'followup_date_j', key: 'followup_date_j', width: 110 },
                  { title: 'نتیجه', dataIndex: 'result', key: 'result', width: 120, ellipsis: true },
                  { title: 'یادداشت', dataIndex: 'note', key: 'note', ellipsis: true },
                  { title: 'پیگیری بعدی', dataIndex: 'next_followup_date_j', key: 'next_followup_date_j', width: 115 },
                  { title: 'ثبت توسط', dataIndex: 'created_by_name', key: 'created_by_name', width: 140, render: (v) => v || '-' },
                ]}
                tableLayout="fixed"
              />
            </Card>

            <Card size="small" className="sama-card">
              <Typography.Text style={{ fontWeight: 700 }}>ثبت پیگیری جدید</Typography.Text>
              <Form form={fuForm} layout="vertical" onValuesChange={(changed, values) => {
                if (changed.template_id) {
                  const tpl = (templates || []).find((t) => String(t.id) === String(values.template_id))
                  fuForm.setFieldsValue({ sms_text: buildSms(tpl?.content || '', fuRow) })
                }
              }}>
                <Space wrap>
                  <Form.Item
                    label="نوع"
                    name="channel"
                    rules={[{ required: true, message: 'الزامی' }]}
                  >
                    <Select
                      style={{ width: 160 }}
                      options={[
                        { value: 'call', label: 'تماس' },
                        { value: 'sms', label: 'پیامک' },
                      ]}
                    />
                  </Form.Item>
                </Space>

                <Form.Item
                  label="نتیجه"
                  name="result"
                  rules={[{ required: true, message: 'الزامی' }]}
                >
                  <Input placeholder="مثلاً پاسخ نداد / پرداخت شد / قول پرداخت" />
                </Form.Item>

                <Form.Item label="یادداشت" name="note">
                  <Input.TextArea rows={2} />
                </Form.Item>

                <Form.Item label="تاریخ پیگیری بعدی" name="next_followup_date_j">
                  <JalaliDatePicker style={{ width: 180 }} />
                </Form.Item>

                <Form.Item shouldUpdate={(p, c) => p.channel !== c.channel} noStyle>
                  {({ getFieldValue }) =>
                    getFieldValue('channel') === 'sms' ? (
                      <>
                        <Form.Item label="قالب پیامک" name="template_id">
                          <Select
                            allowClear
                            placeholder="انتخاب قالب"
                            options={(templates || []).map((t) => ({ value: String(t.id), label: t.name }))}
                          />
                        </Form.Item>
                        <Form.Item label="متن پیامک" name="sms_text">
                          <Input.TextArea rows={3} />
                        </Form.Item>
                        <Space>
                          <Button
                            onClick={async () => {
                              const text = fuForm.getFieldValue('sms_text') || ''
                              await navigator.clipboard.writeText(text)
                              message.success('کپی شد')
                            }}
                          >
                            کپی متن پیامک
                          </Button>
                          <Button
                            type="primary"
                            onClick={async () => {
                              const body = (fuForm.getFieldValue('sms_text') || '').trim()
                              if (!body) return message.error('متن پیامک خالی است')
                              const to = (fuRow?.mobile || '').trim()
                              if (!to) return message.error('شماره موبایل بیمه‌گذار موجود نیست')

                              try {
                                const st = await getSmsStatus()
                                if (!st?.enabled) {
                                  message.warning('پنل پیامکی هنوز تنظیم نشده است. پیامک با وضعیت «ناموفق» ثبت می‌شود.')
                                }
                                await sendRealSms({
                                  to_number: to,
                                  body,
                                  related_type: 'payment_item',
                                  related_id: fuRow?.payment_item_id,
                                  stage: 'manual',
                                })
                                message.success('ارسال ثبت شد')
                                qc.invalidateQueries({ queryKey: ['sms-outbox'] })
                              } catch (e) {
                                message.error(e?.response?.data?.detail || 'خطا در ارسال')
                              }
                            }}
                          >
                            ارسال پیامک
                          </Button>
                        </Space>
                      </>
                    ) : null
                  }
                </Form.Item>

                <Divider style={{ margin: '12px 0' }} />
                <Button type="primary" onClick={saveFollowup} loading={fuLoading} block>
                  ثبت پیگیری
                </Button>
              </Form>
            </Card>
          </Space>
        )}
      </Modal>

      <Drawer
        open={polOpen}
        onClose={() => setPolOpen(false)}
        title={polData ? `نمای کلی بیمه‌نامه — ${polData.policy_number}` : 'نمای کلی بیمه‌نامه'}
        width={520}
        placement="right"
      >
        {polLoading ? (
          <div style={{ padding: 12 }}>در حال دریافت…</div>
        ) : polData ? (
          <Descriptions column={1} size="small" bordered>
            <Descriptions.Item label="شماره بیمه‌نامه">{polData.policy_number}</Descriptions.Item>
            <Descriptions.Item label="رشته">{polData.insurance_line}</Descriptions.Item>
            <Descriptions.Item label="بیمه‌گذار">{polData.policyholder_name}</Descriptions.Item>
            <Descriptions.Item label="مورد بیمه">{polData.insured_item}</Descriptions.Item>
            <Descriptions.Item label="کدملی">{polData.national_id}</Descriptions.Item>
            <Descriptions.Item label="موبایل">{polData.mobile}</Descriptions.Item>
            <Descriptions.Item label="تاریخ صدور">{polData.issue_date_j}</Descriptions.Item>
            <Descriptions.Item label="شروع">{polData.start_date_j}</Descriptions.Item>
            <Descriptions.Item label="سررسید بیمه‌نامه">{polData.end_date_j}</Descriptions.Item>
            <Descriptions.Item label="کل حق بیمه">{fmtRial(polData.total_premium_rial)}</Descriptions.Item>
            {polData.discount_amount_rial ? (
              <Descriptions.Item label="تخفیف">{fmtRial(polData.discount_amount_rial)}</Descriptions.Item>
            ) : null}
          </Descriptions>
        ) : (
          <div style={{ padding: 12 }}>—</div>
        )}
      </Drawer>
    </Space>
  )
}
