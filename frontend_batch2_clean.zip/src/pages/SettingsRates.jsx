import React, { useEffect, useMemo, useState } from 'react'
import { Card, Space, Typography, Table, Button, Divider, App as AntdApp } from 'antd'
import { getVatRates, saveVatRates, getSessionTimeout, setSessionTimeout } from '../api/settings'
import JalaliDatePicker from '../components/JalaliDatePicker.jsx'

const { Title, Text } = Typography

export default function SettingsRates() {
  const { message } = AntdApp.useApp()
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [timeoutMin, setTimeoutMin] = useState(60)
  const [vatRows, setVatRows] = useState([])

  const columns = useMemo(() => ([
    {
      title: 'از تاریخ (شمسی)',
      dataIndex: 'effective_from_j',
      width: 170,
      render: (v, row, idx) => (
        <JalaliDatePicker
          value={v}
          onChange={(val) => {
            const next = [...vatRows]
            next[idx] = { ...next[idx], effective_from_j: val }
            setVatRows(next)
          }}
        />
      ),
    },
    {
      title: 'نرخ %',
      dataIndex: 'rate_percent',
      width: 140,
      render: (v, row, idx) => (
        <input
          style={{ width: '100%', padding: 8, borderRadius: 8, border: '1px solid #d9d9d9' }}
          value={String(v ?? '')}
          placeholder="مثلاً 10"
          onChange={(e) => {
            const next = [...vatRows]
            const n = Number(String(e.target.value || '').replace(/[^0-9.]/g, ''))
            next[idx] = { ...next[idx], rate_percent: Number.isFinite(n) ? n : 0 }
            setVatRows(next)
          }}
        />
      ),
    },
    {
      title: '',
      dataIndex: 'actions',
      width: 120,
      render: (_, __, idx) => (
        <Button danger onClick={() => setVatRows(vatRows.filter((_, i) => i !== idx))}>حذف</Button>
      ),
    },
  ]), [vatRows])

  const load = async () => {
    setLoading(true)
    try {
      const [t, v] = await Promise.all([getSessionTimeout(), getVatRates()])
      // backend returns { session_timeout_minutes }
      setTimeoutMin(Number(t?.session_timeout_minutes ?? 60))
      setVatRows((v?.items || []).map((x) => ({
        key: x.effective_from_j,
        effective_from_j: x.effective_from_j,
        rate_percent: Number(x.rate_percent ?? 0),
      })))
    } catch (e) {
      message.error('خطا در دریافت تنظیمات')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const saveAll = async () => {
    // basic validation
    for (const r of vatRows) {
      if (!r.effective_from_j) {
        message.error('تاریخ ارزش افزوده را کامل کنید')
        return
      }
    }

    setSaving(true)
    try {
      await Promise.all([
        setSessionTimeout(timeoutMin),
        saveVatRates((vatRows || []).map((r) => ({
          effective_from_j: r.effective_from_j,
          rate_percent: Number(r.rate_percent ?? 0),
        }))),
      ])
      message.success('ذخیره شد')
      await load()
    } catch (e) {
      message.error('ذخیره انجام نشد')
    } finally {
      setSaving(false)
    }
  }

  return (
    <Space direction="vertical" style={{ width: '100%' }} size={16}>
      <Title level={3} style={{ margin: 0 }}>نرخ‌ها و زمان نشست</Title>

      <Card loading={loading} style={{ borderRadius: 16 }}>
        <Space direction="vertical" style={{ width: '100%' }} size={12}>
          <Text type="secondary">مدت عدم فعالیت (دقیقه)</Text>
          <input
            type="number"
            min={5}
            max={24 * 60}
            value={timeoutMin}
            onChange={(e) => setTimeoutMin(Number(e.target.value || 60))}
            style={{ width: 140, padding: 8, borderRadius: 8, border: '1px solid #d9d9d9' }}
          />

          <Divider />

          <Space align="center" style={{ width: '100%', justifyContent: 'space-between' }}>
            <div>
              <Text>نرخ‌های ارزش افزوده (تاریخ‌دار)</Text>
              <div><Text type="secondary">با اضافه کردن تاریخ‌های جدید، از همان تاریخ به بعد اعمال می‌شود.</Text></div>
            </div>
            <Button onClick={() => setVatRows([...vatRows, { key: String(Date.now()), effective_from_j: '', rate_percent: 0 }])}>افزودن ردیف</Button>
          </Space>

          <Table
            size="small"
            rowKey="key"
            columns={columns}
            dataSource={vatRows}
            pagination={false}
          />

          <Space style={{ width: '100%', justifyContent: 'flex-end' }}>
            <Button onClick={load}>بازخوانی</Button>
            <Button type="primary" loading={saving} onClick={saveAll}>ذخیره</Button>
          </Space>
        </Space>
      </Card>
    </Space>
  )
}
