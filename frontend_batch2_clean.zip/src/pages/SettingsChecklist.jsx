import React, { useMemo, useState } from 'react'
import { Button, Card, Divider, Form, Input, Popconfirm, Select, Space, Switch, Table, Tag, Typography, message } from 'antd'
import { PlusOutlined, EditOutlined, DeleteOutlined, ArrowUpOutlined, ArrowDownOutlined } from '@ant-design/icons'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import FormDrawer from '../components/FormDrawer'
import { listInsuranceLines } from '../api/insuranceLines'
import {
  listDocumentRequirements,
  createDocumentRequirement,
  updateDocumentRequirement,
  deleteDocumentRequirement,
} from '../api/documents'

// در B11 رشته‌ها کاملاً دینامیک هستند و از تنظیمات «تعریف رشته‌های بیمه» می‌آیند.

export default function SettingsChecklist() {
  const qc = useQueryClient()
  const [line, setLine] = useState('')
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form] = Form.useForm()

  const linesQ = useQuery({
    queryKey: ['insuranceLines', 'all'],
    queryFn: () => listInsuranceLines({ include_inactive: true }),
  })

  const lineOptions = useMemo(() => {
    const data = Array.isArray(linesQ.data) ? linesQ.data : []
    return [
      { value: '', label: 'همه' },
      ...data
        .slice()
        .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0))
        .map((x) => ({ value: x.title, label: x.title })),
    ]
  }, [linesQ.data])

  const reqQ = useQuery({
    queryKey: ['docRequirements', line],
    queryFn: () => listDocumentRequirements(line ? { insurance_line: line } : {}),
  })

  const createMut = useMutation({
    mutationFn: (payload) => createDocumentRequirement(payload),
    onSuccess: () => {
      message.success('ثبت شد')
      setOpen(false)
      setEditing(null)
      form.resetFields()
      qc.invalidateQueries({ queryKey: ['docRequirements'] })
    },
    onError: (e) => message.error(e?.response?.data?.detail || 'خطا در ثبت'),
  })

  const updateMut = useMutation({
    mutationFn: ({ id, payload }) => updateDocumentRequirement(id, payload),
    onSuccess: () => {
      message.success('ذخیره شد')
      setOpen(false)
      setEditing(null)
      form.resetFields()
      qc.invalidateQueries({ queryKey: ['docRequirements'] })
    },
    onError: (e) => message.error(e?.response?.data?.detail || 'خطا در ذخیره'),
  })

  const deleteMut = useMutation({
    mutationFn: (id) => deleteDocumentRequirement(id),
    onSuccess: () => {
      message.success('حذف شد')
      qc.invalidateQueries({ queryKey: ['docRequirements'] })
    },
    onError: (e) => message.error(e?.response?.data?.detail || 'خطا در حذف'),
  })

  const rows = reqQ.data || []

  const moveSort = async (row, dir) => {
    const sameLine = rows.filter((r) => (r.insurance_line || '') === (row.insurance_line || ''))
    const idx = sameLine.findIndex((x) => x.id === row.id)
    if (idx < 0) return
    const swapWith = dir === 'up' ? sameLine[idx - 1] : sameLine[idx + 1]
    if (!swapWith) return
    // swap sort_order
    const a = row.sort_order ?? 0
    const b = swapWith.sort_order ?? 0
    await updateMut.mutateAsync({ id: row.id, payload: { sort_order: b } })
    await updateMut.mutateAsync({ id: swapWith.id, payload: { sort_order: a } })
  }

  const columns = useMemo(
    () => [
      { title: 'رشته', dataIndex: 'insurance_line', width: 140, render: (v) => v || '-' },
      { title: 'عنوان', dataIndex: 'title', ellipsis: true },
      {
        title: 'اجباری',
        dataIndex: 'is_required',
        width: 90,
        render: (v) => (v ? <Tag color="red">اجباری</Tag> : <Tag>اختیاری</Tag>),
      },
      {
        title: 'منبع',
        dataIndex: 'source',
        width: 140,
        render: (v) => (v === 'agent' ? <Tag color="blue">نمایندگی</Tag> : <Tag color="geekblue">بیمه‌گذار</Tag>),
      },
      { title: 'ترتیب', dataIndex: 'sort_order', width: 80 },
      {
        title: 'مرتب‌سازی',
        key: 'move',
        width: 110,
        render: (_v, row) => (
          <Space>
            <Button size="small" icon={<ArrowUpOutlined />} onClick={() => moveSort(row, 'up')} />
            <Button size="small" icon={<ArrowDownOutlined />} onClick={() => moveSort(row, 'down')} />
          </Space>
        ),
      },
      {
        title: 'عملیات',
        key: 'actions',
        width: 160,
        render: (_v, row) => (
          <Space>
            <Button
              size="small"
              icon={<EditOutlined />}
              onClick={() => {
                setEditing(row)
                setOpen(true)
                form.setFieldsValue({
                  insurance_line: row.insurance_line || '',
                  title: row.title,
                  is_required: !!row.is_required,
                  source: row.source || 'agent',
                  sort_order: row.sort_order ?? 0,
                })
              }}
            >
              ویرایش
            </Button>
            <Popconfirm title="حذف شود؟" okText="حذف" cancelText="انصراف" onConfirm={() => deleteMut.mutate(row.id)}>
              <Button size="small" danger icon={<DeleteOutlined />} loading={deleteMut.isPending}>
                حذف
              </Button>
            </Popconfirm>
          </Space>
        ),
      },
    ],
    [deleteMut.isPending, form, rows]
  )

  const onSubmit = (vals) => {
    const payload = {
      // بک‌اند insurance_line را اجباری می‌خواهد.
      insurance_line: vals.insurance_line,
      title: vals.title,
      is_required: !!vals.is_required,
      source: vals.source,
      sort_order: Number(vals.sort_order || 0),
    }
    if (editing?.id) return updateMut.mutate({ id: editing.id, payload })
    return createMut.mutate(payload)
  }

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card className="sama-card" styles={{ body: { padding: 12 } }}>
        <Space style={{ width: '100%', justifyContent: 'space-between' }} align="start">
          <div>
            <Typography.Title level={5} style={{ margin: 0, fontWeight: 900 }}>
              چک‌لیست مستندات
            </Typography.Title>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              تعریف و مدیریت اقلام مستندات هر رشته (اجباری/اختیاری + منبع + ترتیب).
            </Typography.Text>
          </div>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            onClick={() => {
              setEditing(null)
              setOpen(true)
              form.resetFields()
              form.setFieldsValue({ insurance_line: line || '', source: 'agent', is_required: true, sort_order: 0 })
            }}
          >
            افزودن آیتم
          </Button>
        </Space>

        <Divider style={{ margin: '12px 0' }} />

        <Space wrap>
          <Typography.Text type="secondary">فیلتر رشته:</Typography.Text>
          <Select
            loading={linesQ.isLoading}
            value={line}
            style={{ width: 240 }}
            options={lineOptions}
            onChange={(v) => setLine(v)}
          />
        </Space>

        <Table
          style={{ marginTop: 12 }}
          size="small"
          rowKey="id"
          loading={reqQ.isLoading}
          dataSource={rows}
          columns={columns}
          pagination={{ pageSize: 30 }}
          tableLayout="fixed"
        />
      </Card>

      <FormDrawer
        open={open}
        title={editing ? 'ویرایش آیتم' : 'افزودن آیتم'}
        onClose={() => {
          setOpen(false)
          setEditing(null)
        }}
        onSubmit={() => form.submit()}
        submitting={createMut.isPending || updateMut.isPending}
        submitText="ذخیره"
      >
        <Form form={form} layout="vertical" onFinish={onSubmit}>
          <Form.Item
            name="insurance_line"
            label="رشته"
            rules={[{ required: true, message: 'انتخاب رشته الزامی است' }]}
          >
            <Select loading={linesQ.isLoading} options={lineOptions.filter((x) => x.value !== '')} />
          </Form.Item>
          <Form.Item name="title" label="عنوان" rules={[{ required: true, message: 'عنوان الزامی است' }]}>
            <Input />
          </Form.Item>
          <Form.Item name="source" label="منبع" rules={[{ required: true }]}>
            <Select options={[{ value: 'agent', label: 'نمایندگی' }, { value: 'insured', label: 'بیمه‌گذار' }]} />
          </Form.Item>
          <Form.Item name="is_required" label="اجباری؟" valuePropName="checked">
            <Switch checkedChildren="اجباری" unCheckedChildren="اختیاری" />
          </Form.Item>
          <Form.Item name="sort_order" label="ترتیب" tooltip="عدد کمتر یعنی بالاتر">
            <Input type="number" />
          </Form.Item>
        </Form>
      </FormDrawer>
    </Space>
  )
}
