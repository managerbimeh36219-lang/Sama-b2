import React, { useEffect, useMemo, useState } from 'react'
import {
  Button,
  Card,
  Descriptions,
  Drawer,
  Form,
  Input,
  List,
  Modal,
  Space,
  Table,
  Tag,
  Typography,
  Upload,
  Progress,
  message,
  Divider,
} from 'antd'
import { UploadOutlined, DownloadOutlined, ReloadOutlined } from '@ant-design/icons'
import JalaliDatePicker from '../components/JalaliDatePicker'
// Clock moved to header (AppLayout)
import { customerDashboard, customerPolicies, customerPolicyDetails, customerReceipts, submitCustomerReceipt, requestPolicyRenewal, downloadPolicyFile, downloadCustomerReceipt, setCustomerPassword } from '../api/customer'
import { formatRial } from '../utils/format'

const { Title, Text } = Typography

function daysTag(days) {
  if (days == null) return <Text type="secondary">—</Text>

  const windowDays = 30
  const clamped = Math.max(-windowDays, Math.min(windowDays, days))
  const percent = days < 0 ? 100 : Math.round(((windowDays - clamped) / windowDays) * 100)
  const status = days < 0 ? 'exception' : days <= 15 ? 'active' : 'normal'

  const tag =
    days < 0
      ? <Tag color="red">{Math.abs(days)} روز از انقضا گذشته</Tag>
      : days <= 15
        ? <Tag color="gold">{days} روز تا انقضا</Tag>
        : <Tag color="green">{days} روز تا انقضا</Tag>

  return (
    <Space size={8}>
      <Progress type="circle" percent={percent} size={24} status={status} showInfo={false} />
      {tag}
    </Space>
  )
}

function downloadAxiosBlob(res, defaultName) {
  try {
    const blob = res?.data
    const cd = res?.headers?.['content-disposition'] || res?.headers?.['Content-Disposition']
    let filename = defaultName
    if (cd) {
      const m = /filename\*=UTF-8''([^;]+)|filename="?([^"]+)"?/i.exec(cd)
      filename = decodeURIComponent(m?.[1] || m?.[2] || defaultName)
    }
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    a.remove()
    window.URL.revokeObjectURL(url)
  } catch (e) {
    console.error(e)
    message.error('دانلود فایل ناموفق بود')
  }
}

export default function CustomerPortal() {
  const [loading, setLoading] = useState(false)
  const [policies, setPolicies] = useState([])
  const [dashboard, setDashboard] = useState(null)

  const [selectedPolicy, setSelectedPolicy] = useState(null)
  const [details, setDetails] = useState(null)
  const [drawerOpen, setDrawerOpen] = useState(false)

  // receipts indexed by payment_item_id -> latest receipt
  const [receiptMap, setReceiptMap] = useState({})

  // receipt modal
  const [receiptOpen, setReceiptOpen] = useState(false)
  const [receiptItem, setReceiptItem] = useState(null)
  const [receiptForm] = Form.useForm()
  const [receiptFileList, setReceiptFileList] = useState([])

  // renewal request modal
  const [renewalOpen, setRenewalOpen] = useState(false)
  const [renewalPolicy, setRenewalPolicy] = useState(null)
  const [renewalDesc, setRenewalDesc] = useState('')
  const [renewalFiles, setRenewalFiles] = useState([])
  const [renewalRequestedIds, setRenewalRequestedIds] = useState(new Set())

  const [passwordOpen, setPasswordOpen] = useState(false)
  const [password1, setPassword1] = useState('')
  const [password2, setPassword2] = useState('')

  async function loadAll() {
    setLoading(true)
    try {
      const [d, p, r] = await Promise.all([
        customerDashboard().catch(() => null),
        customerPolicies(),
        customerReceipts().catch(() => []),
      ])
      setDashboard(d)
      setPolicies(p || [])
      const map = {}
      ;(r || []).forEach((x) => {
        // فقط آخرین رسید هر قسط را نگه داریم
        if (!x?.payment_item_id) return
        const prev = map[x.payment_item_id]
        if (!prev || (x.id > prev.id)) map[x.payment_item_id] = x
      })
      setReceiptMap(map)
    } catch (e) {
      console.error(e)
      message.error('خطا در بارگذاری اطلاعات')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    loadAll()
  }, [])

  const policyColumns = useMemo(() => ([
    { title: 'شماره بیمه‌نامه', dataIndex: 'policy_number', key: 'policy_number' },
    { title: 'رشته', dataIndex: 'insurance_line', key: 'insurance_line' },
    { title: 'تاریخ پایان', dataIndex: 'end_date_j', key: 'end_date_j' },
    {
      title: 'روزشمار انقضا',
      dataIndex: 'days_to_expiry',
      key: 'days_to_expiry',
      render: (v) => daysTag(v),
    },
    {
      title: 'وضعیت',
      key: 'status',
      render: (_, row) => {
        if (row.is_active === false) return <Tag color="green">تمدید شده</Tag>
        const st = row.renewal_status
        if (st === 'pending') return <Tag color="blue">در انتظار بررسی</Tag>
        if (st === 'approved') return <Tag color="green">تایید شده</Tag>
        if (st === 'rejected') return <Tag color="red">رد شده</Tag>
        return <Tag>—</Tag>
      },
    },
    {
      title: 'عملیات',
      key: 'actions',
      render: (_, row) => (
        <Space>
          <Button size="small" onClick={() => openDetails(row)}>
            مشاهده
          </Button>
          <Button
            size="small"
            icon={<DownloadOutlined />}
            onClick={() => onDownloadPolicy(row)}
          >
            دانلود بیمه‌نامه
          </Button>
          <Button
            size="small"
            type={row.can_request_renewal ? 'primary' : 'default'}
            disabled={!row.can_request_renewal}
            onClick={() => openRenewal(row)}
          >
            درخواست تمدید
          </Button>
          {renewalRequestedIds.has(row.id) && <Tag color="gold">ثبت شد</Tag>}
        </Space>
      ),
    },
  ]), [renewalRequestedIds])

  async function openDetails(row) {
    setSelectedPolicy(row)
    setDrawerOpen(true)
    setDetails(null)
    try {
      const d = await customerPolicyDetails(row.id)
      setDetails(d)
    } catch (e) {
      console.error(e)
      message.error('خطا در دریافت جزئیات بیمه‌نامه')
    }
  }

  async function onDownloadPolicy(row) {
    try {
      const res = await downloadPolicyFile(row.id)
      downloadAxiosBlob(res, `policy_${row.policy_number}.pdf`)
    } catch (e) {
      const msg = e?.response?.data?.detail || 'دانلود فایل ناموفق بود'
      message.error(msg)
    }
  }

  function openRenewal(row) {
    setRenewalPolicy(row)
    setRenewalDesc('')
    setRenewalFiles([])
    setRenewalOpen(true)
  }

  async function submitRenewal() {
    if (!renewalPolicy) return
    const fd = new FormData()
    if (renewalDesc) fd.append('description', renewalDesc)
    renewalFiles.forEach((f) => fd.append('files', f.originFileObj))
    try {
      await requestPolicyRenewal(renewalPolicy.id, fd)
      message.success('درخواست تمدید ثبت شد و به کارتابل ارسال گردید')
      setRenewalRequestedIds((prev) => new Set([...prev, renewalPolicy.id]))
      setRenewalOpen(false)
    } catch (e) {
      const msg = e?.response?.data?.detail || 'ثبت درخواست ناموفق بود'
      message.error(msg)
    }
  }

  async function submitPassword() {
    if (!password1 || password1.length < 6) {
      message.error('رمز باید حداقل ۶ کاراکتر باشد')
      return
    }
    if (password1 !== password2) {
      message.error('رمز و تکرار رمز یکسان نیست')
      return
    }
    try {
      await setCustomerPassword(password1)
      message.success('رمز با موفقیت ثبت شد')
      setPasswordOpen(false)
    } catch (e) {
      message.error(e?.response?.data?.detail || 'ثبت رمز ناموفق بود')
    }
  }

  const installments = details?.installments || []

  const installmentColumns = useMemo(() => ([
    { title: 'سررسید', dataIndex: 'due_date_j', key: 'due_date_j' },
    {
      title: 'مبلغ',
      key: 'amount',
      render: (_, row) => (
        <div>
          <div>{formatRial(row.amount_rial)}</div>
          {row.remaining_rial != null && row.remaining_rial !== row.amount_rial && (
            <Text type="secondary" style={{ fontSize: 12 }}>
              باقیمانده: {formatRial(row.remaining_rial)}
            </Text>
          )}
        </div>
      ),
    },
    {
      title: 'شناسه پرداخت',
      dataIndex: 'system_payment_id',
      key: 'system_payment_id',
      render: (v) => v ? <span style={{ direction: 'ltr' }}>{v}</span> : <Text type="secondary">—</Text>,
    },
    {
      title: 'وضعیت',
      key: 'status',
      render: (_, row) => {
        const remaining = row.remaining_rial ?? row.amount_rial
        if (remaining <= 0) return <Tag color="green">تسویه</Tag>
        return <Tag color="red">تسویه نشده</Tag>
      },
    },
    {
      title: 'رسید',
      key: 'receipt',
      render: (_, row) => {
        const r = receiptMap[row.id]
        return r ? (
          <Tag color={r.status === 'approved' ? 'green' : r.status === 'rejected' ? 'red' : 'gold'}>
            {r.status === 'approved' ? 'تایید شده' : r.status === 'rejected' ? 'رد شده' : 'در انتظار بررسی'}
          </Tag>
        ) : <Text type="secondary">—</Text>
      },
    },
    {
      title: 'عملیات',
      key: 'actions',
      render: (_, row) => {
        const remaining = row.remaining_rial ?? row.amount_rial
        const canPayOnline = !!row.system_payment_id && remaining > 0
        const hasReceipt = !!receiptMap[row.id]
        return (
          <Space>
            <Button size="small" onClick={() => openReceipt(row)}>
              {hasReceipt ? 'ویرایش رسید' : 'آپلود رسید'}
            </Button>
            {canPayOnline && (
              <Button size="small" type="primary" onClick={() => onPayOnline(row)}>
                پرداخت اینترنتی
              </Button>
            )}
          </Space>
        )
      },
    },
  ]), [receiptMap])

  function onPayOnline(row) {
    if (!row?.system_payment_id) return
    const url = `https://epay.iraninsurance.ir/payment/controlCode/${row.system_payment_id}`
    window.open(url, '_blank', 'noopener,noreferrer')
  }

  // backward-compat for UI
  const payOnline = onPayOnline

  function openReceipt(item) {
    setReceiptItem(item)
    const r = receiptMap[item.id]
    receiptForm.setFieldsValue({
      paid_date_j: r?.paid_date_j || '',
      description: r?.description || '',
    })
    setReceiptFileList([])
    setReceiptOpen(true)
  }

  async function submitReceipt() {
    try {
      const vals = await receiptForm.validateFields()
      if (!receiptItem) return
      const existing = receiptMap[receiptItem.id]
      if (!receiptFileList.length && !existing?.attachment_id) {
        message.error('فایل رسید را انتخاب کنید')
        return
      }

      const fd = new FormData()
      fd.append('paid_date_j', vals.paid_date_j)
      if (vals.description) fd.append('description', vals.description)
      // Backend expects field name: file
      if (receiptFileList.length) fd.append('file', receiptFileList[0].originFileObj)

      await submitCustomerReceipt(receiptItem.id, fd)
      message.success('رسید ثبت/ویرایش شد')
      setReceiptOpen(false)

      // refresh receipts map
      const r = await customerReceipts().catch(() => [])
      const map = {}
      ;(r || []).forEach((x) => {
        if (!x?.payment_item_id) return
        const prev = map[x.payment_item_id]
        if (!prev || (x.id > prev.id)) map[x.payment_item_id] = x
      })
      setReceiptMap(map)
    } catch (e) {
      if (e?.errorFields) return
      const msg = e?.response?.data?.detail || 'ثبت رسید ناموفق بود'
      message.error(msg)
    }
  }

  async function previewExistingReceipt() {
    try {
      if (!receiptItem) return
      const r = receiptMap[receiptItem.id]
      if (!r?.attachment_id) return
      const res = await downloadCustomerReceipt(r.attachment_id)
      const blob = res?.data
      const url = URL.createObjectURL(blob)
      window.open(url, '_blank', 'noopener,noreferrer')
      setTimeout(() => URL.revokeObjectURL(url), 5000)
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در نمایش فایل')
    }
  }

  return (
    <div style={{ padding: 16 }}>
      <Space style={{ width: '100%', justifyContent: 'space-between' }} wrap>
        <Title level={4} style={{ margin: 0 }}>پنل مشتری</Title>
        <Space>
          <Button onClick={() => { setPassword1(''); setPassword2(''); setPasswordOpen(true); }}>تعیین رمز</Button>
          <Button icon={<ReloadOutlined />} onClick={loadAll} loading={loading}>به‌روزرسانی</Button>
        </Space>
      </Space>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 12 }}>
        <Card title="اقساط نزدیک به سررسید" variant="outlined">
          <List
            size="small"
            dataSource={dashboard?.upcoming_installments || []}
            locale={{ emptyText: <Text type="secondary">موردی نیست</Text> }}
            renderItem={(it) => (
              <List.Item>
                <div style={{ width: '100%', display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center' }}>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <span>{it.policy_number} — {it.due_date_j}</span>
                    <Text type="secondary">شناسه پرداخت: {it.system_payment_id || '—'}</Text>
                    {receiptMap[it.id]?.status ? (
                      <>
                        <Tag style={{ width: 'fit-content' }} color={receiptMap[it.id].status === 'approved' ? 'green' : receiptMap[it.id].status === 'rejected' ? 'red' : 'orange'}>
                          {receiptMap[it.id].status === 'approved' ? 'رسید تایید شد' : receiptMap[it.id].status === 'rejected' ? 'رسید رد شد' : 'رسید در انتظار تایید'}
                        </Tag>
                        {receiptMap[it.id].status === 'rejected' && receiptMap[it.id].review_note ? (
                          <Text type="danger" style={{ fontSize: 12 }}>پیام بررسی: {receiptMap[it.id].review_note}</Text>
                        ) : null}
                      </>
                    ) : (
                      <Tag style={{ width: 'fit-content' }}>وضعیت رسید: —</Tag>
                    )}
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span>{formatRial(it.remaining_rial)}</span>
                    <Button size="small" onClick={() => openReceipt(it)}>آپلود رسید</Button>
                    <Button size="small" type="primary" disabled={!it.system_payment_id} onClick={() => payOnline(it)}>
                      پرداخت اینترنتی
                    </Button>
                  </div>
                </div>
              </List.Item>
            )}
          />
        </Card>
        <Card title="بیمه‌نامه‌های نزدیک تمدید" variant="outlined">
          <List
            size="small"
            dataSource={(dashboard?.upcoming_renewals || []).slice(0, 10)}
            locale={{ emptyText: <Text type="secondary">موردی نیست</Text> }}
            renderItem={(it) => (
              <List.Item>
                <div style={{ width: '100%', display: 'flex', justifyContent: 'space-between', gap: 8, alignItems: 'center' }}>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <span>{it.policy_number} — پایان: {it.end_date_j}</span>
                    <Text type="secondary">رشته: {it.insurance_line}</Text>
                    {it.renewal_status ? (
                      <div style={{ marginTop: 4 }}>
                        <Tag color={it.renewal_status === 'renewed' ? 'green' : (it.renewal_status === 'requested' ? 'gold' : 'default')}>
                          {it.renewal_status === 'renewed' ? 'تمدید شد' : (it.renewal_status === 'requested' ? 'درخواست ثبت شد' : it.renewal_status)}
                        </Tag>
                        {it.renewed_policy_number ? <Text type="secondary">شماره جدید: {it.renewed_policy_number}</Text> : null}
                      </div>
                    ) : null}
                  </div>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
                    <span>{daysTag(it.days_to_expiry)}</span>
                    <Button
                      size="small"
                      type="primary"
                      disabled={!it.can_request_renewal}
                      onClick={() => openRenewal({ id: it.policy_id, policy_number: it.policy_number, end_date_j: it.end_date_j, days_to_expiry: it.days_to_expiry, can_request_renewal: it.can_request_renewal })}
                    >
                      درخواست تمدید
                    </Button>
                  </div>
                </div>
              </List.Item>
            )}
          />
        </Card>
      </div>

      <Card title="بیمه‌نامه‌ها" style={{ marginTop: 12 }} variant="outlined">
        <Table
          rowKey="id"
          loading={loading}
          dataSource={policies}
          columns={policyColumns}
          pagination={{ pageSize: 10 }}
          onRow={(row) => ({
            onDoubleClick: () => openDetails(row),
          })}
        />
      </Card>

      <Drawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        width={920}
        title={selectedPolicy ? `بیمه‌نامه ${selectedPolicy.policy_number}` : 'جزئیات'}
      >
        {!details ? (
          <Text type="secondary">در حال دریافت اطلاعات...</Text>
        ) : (
          <>
            <Descriptions bordered size="small" column={2}>
              <Descriptions.Item label="شماره بیمه‌نامه">{details.policy.policy_number}</Descriptions.Item>
              <Descriptions.Item label="رشته">{details.policy.insurance_line}</Descriptions.Item>
              <Descriptions.Item label="بیمه‌گذار">{details.policy.policyholder_name}</Descriptions.Item>
              <Descriptions.Item label="مورد بیمه">{details.policy.subject || '-'}</Descriptions.Item>
              <Descriptions.Item label="شروع">{details.policy.start_date_j}</Descriptions.Item>
              <Descriptions.Item label="پایان">{details.policy.end_date_j}</Descriptions.Item>
            </Descriptions>

            <Divider />

            <Title level={5} style={{ marginTop: 0 }}>اقساط</Title>
            <Table
              rowKey="id"
              dataSource={installments}
              columns={installmentColumns}
              pagination={{ pageSize: 10 }}
              size="small"
            />
          </>
        )}
      </Drawer>

      <Modal
        open={receiptOpen}
        onCancel={() => setReceiptOpen(false)}
        onOk={submitReceipt}
        okText="ثبت"
        cancelText="انصراف"
        title={receiptItem ? `رسید قسط ${receiptItem.due_date_j}` : 'رسید'}
        destroyOnClose
      >
        <Form form={receiptForm} layout="vertical">
          <Form.Item
            name="paid_date_j"
            label="تاریخ پرداخت"
            rules={[
              { required: true, message: 'تاریخ پرداخت را وارد کنید' },
              { pattern: /^\d{4}\/\d{2}\/\d{2}$/, message: 'فرمت تاریخ: YYYY/MM/DD' },
            ]}
          >
            <JalaliDatePicker placeholder="YYYY/MM/DD" />
          </Form.Item>

          <Form.Item name="description" label="توضیحات (اختیاری)">
            <Input.TextArea rows={3} />
          </Form.Item>

          {receiptItem && receiptMap[receiptItem.id]?.attachment_id ? (
            <div style={{ marginBottom: 10 }}>
              <Text type="secondary" style={{ fontSize: 12 }}>
                فایل قبلی: {receiptMap[receiptItem.id]?.attachment_name || `receipt_${receiptMap[receiptItem.id]?.attachment_id}`}
              </Text>
              <div style={{ marginTop: 6 }}>
                <Button size="small" onClick={previewExistingReceipt}>نمایش فایل</Button>
              </div>
            </div>
          ) : null}

          <Form.Item label="فایل رسید" required={!(receiptItem && receiptMap[receiptItem.id]?.attachment_id)}>
            <Upload
              beforeUpload={() => false}
              fileList={receiptFileList}
              onChange={({ fileList }) => setReceiptFileList(fileList.slice(-1))}
              maxCount={1}
            >
              <Button icon={<UploadOutlined />}>انتخاب فایل</Button>
            </Upload>
          </Form.Item>

          <Text type="secondary" style={{ fontSize: 12 }}>
            مبلغ نیازی نیست. رسید برای بررسی و تایید دفتر ارسال می‌شود.
          </Text>
        </Form>
      </Modal>

      <Modal
        open={renewalOpen}
        onCancel={() => setRenewalOpen(false)}
        onOk={submitRenewal}
        okText="ثبت درخواست"
        cancelText="انصراف"
        title={renewalPolicy ? `درخواست تمدید — ${renewalPolicy.policy_number}` : 'درخواست تمدید'}
        destroyOnClose
      >
        <Form layout="vertical">
          <Form.Item label="توضیحات (اختیاری)">
            <Input.TextArea value={renewalDesc} onChange={(e) => setRenewalDesc(e.target.value)} rows={3} />
          </Form.Item>
          <Form.Item label="آپلود مدارک ضروری">
            <Upload
              beforeUpload={() => false}
              multiple
              fileList={renewalFiles}
              onChange={({ fileList }) => setRenewalFiles(fileList)}
            >
              <Button icon={<UploadOutlined />}>انتخاب فایل‌ها</Button>
            </Upload>
            <Text type="secondary" style={{ fontSize: 12 }}>
              مدارکی که برای تمدید لازم است را بارگذاری کنید (مثلاً عکس، PDF، ...).
            </Text>
          </Form.Item>
        </Form>
      </Modal>

      <Modal
        open={passwordOpen}
        onCancel={() => setPasswordOpen(false)}
        onOk={submitPassword}
        okText="ذخیره"
        cancelText="انصراف"
        title="تعیین رمز ورود"
        destroyOnClose
      >
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <Input.Password value={password1} onChange={(e) => setPassword1(e.target.value)} placeholder="رمز جدید" />
          <Input.Password value={password2} onChange={(e) => setPassword2(e.target.value)} placeholder="تکرار رمز" />
          <Text type="secondary" style={{ fontSize: 12 }}>حداقل ۶ کاراکتر</Text>
        </div>
      </Modal>
    </div>
  )
}
