import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Button, Card, Divider, Input, Space, Typography, message } from 'antd'
import { getUiPublic } from '../api/settings'
import { loginOtp, loginPassword, requestOtp, me } from '../api/auth'
import { useNavigate } from 'react-router-dom'
import { useAppStore } from '../store/appStore'

function OtpBoxes({ value, onChange, disabled }) {
  const refs = useRef([])
  const digits = Array.from({ length: 6 }).map((_, i) => (value || '')[i] || '')

  return (
    // مهم: برای اینکه از چپ به راست پر شود (LTR)
    <Space style={{ width: '100%', justifyContent: 'space-between', direction: 'ltr' }}>
      {digits.map((d, i) => (
        <Input
          key={i}
          ref={(el) => (refs.current[i] = el)}
          inputMode="numeric"
          value={d}
          disabled={disabled}
          style={{ width: 44, textAlign: 'center', fontWeight: 800, direction: 'ltr', unicodeBidi: 'plaintext' }}
          maxLength={1}
          onChange={(e) => {
            const ch = (e.target.value || '').replace(/\D/g, '').slice(0, 1)
            const joined = digits.map((x, idx) => (idx === i ? ch : x)).join('')
            onChange(joined.replace(/\D/g, '').slice(0, 6))
            if (ch && refs.current[i + 1]) refs.current[i + 1].focus()
          }}
          onKeyDown={(e) => {
            if (e.key === 'Backspace' && !d && refs.current[i - 1]) refs.current[i - 1].focus()
          }}
          onPaste={(e) => {
            const txt = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6)
            if (!txt) return
            e.preventDefault()
            onChange(txt)
            const last = Math.min(5, txt.length - 1)
            if (refs.current[last]) refs.current[last].focus()
          }}
        />
      ))}
    </Space>
  )
}

export default function Login(){
  const nav = useNavigate()
  const { setUser, setUi } = useAppStore()

  const [messageApi, contextHolder] = message.useMessage()

  const [ui, setUiLocal] = useState(null)
  const [mobile, setMobile] = useState('')
  const [otp, setOtp] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  // حالت پیش‌فرض: ورود با رمز
  const [mode, setMode] = useState('password') // 'password' | 'otp'

  // تایمر ارسال مجدد OTP
  const [otpCooldown, setOtpCooldown] = useState(0)
  const cooldownRef = useRef(null)

  const mobileRef = useRef(null)

  // اتو-ورود با رمز (برای سرعت)
  const autoLoginRef = useRef(null)

  useEffect(() => {
    (async () => {
      try {
        const res = await getUiPublic()
        setUiLocal(res)
        setUi(res)
        if (res?.favicon_url) {
          const link = document.querySelector("link[rel~='icon']") || document.createElement('link')
          link.rel = 'icon'
          link.href = res.favicon_url
          document.head.appendChild(link)
        }
      } catch {}
    })()
  }, [])

  const saveToken = (res) => {
    const token = res?.token || res?.access_token
    if (!token) return false

    // برای سازگاری کامل با همه نسخه‌ها
    localStorage.setItem('sama_token', token)
    localStorage.setItem('token', token)
    localStorage.setItem('access_token', token)
    return true
  }

  const afterLogin = async () => {
    const u = await me()
    setUser(u)
    nav('/dashboard', { replace:true })
  }

  const onRequestOtp = async (e) => {
    e?.preventDefault?.()
    if (otpCooldown > 0) return
    if (!isMobileValid) {
      messageApi.error('شماره موبایل باید ۱۱ رقم و با 09 شروع شود')
      return
    }
    setLoading(true)
    try {
      await requestOtp(mobile)
      messageApi.success('کد یکبارمصرف ارسال شد')

      // شروع تایمر ارسال مجدد (پیش‌فرض 60 ثانیه)
      setOtpCooldown(60)
      if (cooldownRef.current) clearInterval(cooldownRef.current)
      cooldownRef.current = setInterval(() => {
        setOtpCooldown((s) => {
          if (s <= 1) {
            clearInterval(cooldownRef.current)
            cooldownRef.current = null
            return 0
          }
          return s - 1
        })
      }, 1000)
    } catch (e) {
      messageApi.error(e?.response?.data?.detail || 'خطا در ارسال کد')
    } finally {
      setLoading(false)
    }
  }

  const onLoginOtp = async (e) => {
    e?.preventDefault?.()
    if (!isMobileValid) {
      messageApi.error('شماره موبایل باید ۱۱ رقم و با 09 شروع شود')
      return
    }
    if (!otp || otp.length !== 6) {
      messageApi.error('کد یکبارمصرف باید ۶ رقم باشد')
      return
    }
    setLoading(true)
    try {
      const res = await loginOtp(mobile, otp)

      if (!saveToken(res)) {
        messageApi.error('توکن از سرور دریافت نشد')
        return
      }

      await afterLogin()
    } catch (e) {
      messageApi.error(e?.response?.data?.detail || 'ورود ناموفق')
    } finally {
      setLoading(false)
    }
  }

  const onLoginPassword = async (e) => {
    e?.preventDefault?.()
    if (!isMobileValid) {
      messageApi.error('شماره موبایل باید ۱۱ رقم و با 09 شروع شود')
      return
    }
    if (!password) {
      messageApi.error('رمز را وارد کنید')
      return
    }
    setLoading(true)
    try {
      const res = await loginPassword(mobile, password)

      if (!saveToken(res)) {
        messageApi.error('توکن از سرور دریافت نشد')
        return
      }

      await afterLogin()
    } catch (e) {
      messageApi.error(e?.response?.data?.detail || 'ورود ناموفق')
    } finally {
      setLoading(false)
    }
  }

  const isMobileValid = useMemo(() => /^09\d{9}$/.test(mobile), [mobile])

  // اتو ورود با رمز: وقتی موبایل معتبر و رمز وارد شد، با کمی تأخیر تلاش کن
  useEffect(() => {
    if (mode !== 'password') return
    if (!isMobileValid) return
    if (!password || password.length < 4) return
    if (loading) return

    if (autoLoginRef.current) clearTimeout(autoLoginRef.current)
    autoLoginRef.current = setTimeout(() => {
      // اتو-ورود بدون کلیک
      onLoginPassword()
    }, 700)

    return () => {
      if (autoLoginRef.current) {
        clearTimeout(autoLoginRef.current)
        autoLoginRef.current = null
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [password, mobile, mode])

  // اتو-ورود OTP: با ورود ۶ رقم، خودکار لاگین کن
  useEffect(() => {
    if (mode !== 'otp') return
    if (!isMobileValid) return
    if (loading) return
    if ((otp || '').length === 6) {
      onLoginOtp()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [otp, mobile, mode])

  useEffect(() => {
    return () => {
      if (cooldownRef.current) clearInterval(cooldownRef.current)
      if (autoLoginRef.current) clearTimeout(autoLoginRef.current)
    }
  }, [])

  return (
    <div
      style={{
        minHeight:'100vh',
        display:'flex',
        alignItems:'center',
        justifyContent:'center',
        padding:16,
        background: ui?.login_background_url
          ? undefined
          : 'linear-gradient(135deg, #eef4ff 0%, #f8fbff 45%, #eef7f2 100%)',
        backgroundImage: ui?.login_background_url ? `url(${ui.login_background_url})` : undefined,
        backgroundSize:'cover',
        backgroundPosition:'center',
        backgroundRepeat:'no-repeat'
      }}
    >
      {contextHolder}

      <div style={{width:'100%', maxWidth:520}}>
        <div style={{textAlign:'center', marginBottom:16}}>
          {ui?.logo_url && <img src={ui.logo_url} alt="SAMA" style={{height:56, objectFit:'contain'}} />}
        </div>

        {/* طبق درخواست: کادر/پس‌زمینه لاگین حذف شود و فقط بکگراند صفحه کافیست */}
        <Card
          bordered={false}
          style={{
            background: 'rgba(255,255,255,0.82)',
            boxShadow: '0 20px 60px rgba(15, 23, 42, 0.12)',
            backdropFilter: 'blur(8px)',
            borderRadius: 20,
          }}
          styles={{ body:{ padding: 24 } }}
        >          <Typography.Title level={4} style={{marginTop:0}}>ورود به سامانه سما</Typography.Title>
          <Typography.Text type="secondary">
            {mode === 'password' ? 'ورود با شماره موبایل و رمز' : 'ورود با شماره موبایل و رمز یکبارمصرف (OTP)'}
          </Typography.Text>
          <Divider />

          <Space direction="vertical" style={{width:'100%'}}>
            {mode === 'password' ? (
              <Input
                ref={mobileRef}
                inputMode="numeric"
                value={mobile}
                onChange={(e) => {
                  const v = (e.target.value || '').replace(/\D/g, '').slice(0, 11)
                  setMobile(v)
                }}
                status={mobile && !isMobileValid ? 'error' : ''}
                placeholder="شماره موبایل (مثال: 0912xxxxxxx)"
                onPressEnter={() => onLoginPassword()}
              />
            ) : (
              <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                <Typography.Text>
                  شماره موبایل: <b style={{direction:'ltr', unicodeBidi:'plaintext'}}>{mobile || '—'}</b>
                </Typography.Text>
                <Button
                  type="link"
                  onClick={() => {
                    setMode('password')
                    setOtp('')
                    // برگرد به مرحله قبلی برای ویرایش موبایل
                    setTimeout(() => mobileRef.current?.focus?.(), 50)
                  }}
                >
                  ویرایش شماره موبایل
                </Button>
              </div>
            )}

            {mode === 'password' ? (
              <>
                <Input.Password
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="رمز"
                  onPressEnter={() => onLoginPassword()}
                />

                <Button htmlType="button" type="primary" onClick={onLoginPassword} loading={loading} block>
                  ورود
                </Button>

                <Button
                  type="link"
                  block
                  onClick={async () => {
                    // هنگام ورود به حالت OTP، خودکار پیامک ارسال شود
                    if (!isMobileValid) {
                      messageApi.error('اول شماره موبایل را وارد کنید (۱۱ رقم و با 09 شروع شود)')
                      setTimeout(() => mobileRef.current?.focus?.(), 50)
                      return
                    }
                    setMode('otp')
                    setPassword('')
                    setOtp('')
                    await onRequestOtp()
                  }}
                >
                  ورود با رمز یکبارمصرف
                </Button>
              </>
            ) : (
              <>
                <Button
                  htmlType="button"
                  onClick={onRequestOtp}
                  loading={loading}
                  disabled={otpCooldown > 0}
                  block
                >
                  {otpCooldown > 0 ? `ارسال مجدد کد (${otpCooldown}s)` : 'دریافت کد یکبارمصرف'}
                </Button>

                <OtpBoxes value={otp} onChange={setOtp} disabled={loading} />

                <Button htmlType="button" type="primary" onClick={onLoginOtp} loading={loading} block>
                  ورود
                </Button>

                <Button
                  type="link"
                  block
                  onClick={() => {
                    setMode('password')
                    setOtp('')
                  }}
                >
                  ورود با رمز
                </Button>
              </>
            )}
          </Space>
        </Card>
      </div>
    </div>
  )
}
