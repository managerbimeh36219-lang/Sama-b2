import React, { useEffect, useMemo, useState } from 'react'
import {
  Button,
  Card,
  Drawer,
  Form,
  Input,
  Select,
  Space,
  Table,
  Tag,
  Upload,
  message,
} from 'antd'
import { PlusOutlined, UploadOutlined, AudioOutlined } from '@ant-design/icons'

import JalaliDatePicker from '../components/JalaliDatePicker.jsx'
import {
  listTasks,
  createTask,
  updateTask,
  deleteTask,
  uploadTaskAttachment,
  listTaskAttachments,
  getTaskAttachmentUrl,
} from '../api/tasks'
import { listUsers } from '../api/users'
import { listMarketers } from '../api/marketers2'
import { errorToText } from '../utils/errorText'
import AuthenticatedImage from '../components/AuthenticatedImage.jsx'
import FilePreviewModal from '../components/FilePreviewModal.jsx'
import { fetchBlob, downloadBlob } from '../utils/fileAccess'

const STATUS_LABEL = {
  open: 'باز',
  done: 'انجام شد',
  canceled: 'لغو',
}

const PRIORITY_LABEL = {
  low: 'کم',
  normal: 'عادی',
  high: 'بالا',
}

function FormDrawer({ title, open, onClose, onSubmit, children }) {
  return (
    <Drawer
      title={title}
      open={open}
      onClose={onClose}
      width={760}
      destroyOnClose={false}
      extra={
        <Space>
          <Button onClick={onClose}>بستن</Button>
          <Button type="primary" onClick={onSubmit}>
            ذخیره
          </Button>
        </Space>
      }
    >
      {children}
    </Drawer>
  )
}

export default function TasksPage() {
  const [rows, setRows] = useState([])
  const [users, setUsers] = useState([])
  const [marketers, setMarketers] = useState([])
  const [loading, setLoading] = useState(false)

  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [attachments, setAttachments] = useState([])
  const [preview, setPreview] = useState({ open: false, url: '', title: '', mime: '' })
  const [form] = Form.useForm()

  async function refresh() {
    setLoading(true)
    try {
      const t = await listTasks()
      setRows(Array.isArray(t) ? t : [])

      try {
        const u = await listUsers()
        setUsers(Array.isArray(u) ? u : [])
      } catch (e) {
        setUsers([])
        message.warning(errorToText(e, 'دریافت لیست کاربران ممکن نشد'))
      }

      try {
        const m = await listMarketers()
        setMarketers(Array.isArray(m) ? m : [])
      } catch (e) {
        setMarketers([])
        message.warning(errorToText(e, 'دریافت لیست بازاریابان ممکن نشد'))
      }
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
  }, [])

  const userOptions = useMemo(
    () => users.map((u) => ({ value: u.id, label: `${u.full_name}${u.mobile ? ` (${u.mobile})` : ''}` })),
    [users]
  )
  const marketerOptions = useMemo(
    () => marketers.map((m) => ({ value: m.id, label: `${m.full_name}${m.code ? ` - ${m.code}` : ''}` })),
    [marketers]
  )

  function openCreate() {
    setEditing(null)
    setAttachments([])
    form.resetFields()
    form.setFieldsValue({ status: 'open', priority: 'normal' })
    setOpen(true)
  }

  async function openEdit(row) {
    setEditing(row)
    form.setFieldsValue(row)
    setOpen(true)
    try {
      const a = await listTaskAttachments(row.id)
      setAttachments(Array.isArray(a) ? a : [])
    } catch {
      setAttachments([])
    }
  }

  async function onSave() {
    const values = await form.validateFields()
    try {
      if (editing) {
        await updateTask(editing.id, values)
        message.success('ویرایش شد')
      } else {
        const created = await createTask(values)
        message.success('ثبت شد')
        setEditing(created)
      }
      await refresh()
      setOpen(false)
    } catch (e) {
      message.error(errorToText(e, 'خطا در ثبت'))
    }
  }

  async function onDelete(row) {
    try {
      await deleteTask(row.id)
      message.success('حذف شد')
      await refresh()
    } catch (e) {
      message.error(errorToText(e, 'خطا در حذف'))
    }
  }

  async function previewAttachment(item) {
    try {
      const url = getTaskAttachmentUrl(item.id)
      const blob = await fetchBlob(url)
      const blobUrl = URL.createObjectURL(blob)
      setPreview({
        open: true,
        url: blobUrl,
        title: item.file_name || 'پیوست',
        mime: blob.type || item.mime_type || '',
      })
    } catch (e) {
      message.error(errorToText(e, 'نمایش فایل ممکن نشد'))
    }
  }

  const columns = [
    { title: 'عنوان', dataIndex: 'title' },
    {
      title: 'وضعیت',
      dataIndex: 'status',
      width: 120,
      render: (v) => <Tag>{STATUS_LABEL[v] || v}</Tag>,
    },
    {
      title: 'اولویت',
      dataIndex: 'priority',
      width: 120,
      render: (v) => <Tag>{PRIORITY_LABEL[v] || v}</Tag>,
    },
    { title: 'سررسید', dataIndex: 'due_date_j', width: 120, render: (v) => v || '—' },
    { title: 'ساعت', dataIndex: 'due_time', width: 90, render: (v) => v || '—' },
    {
      title: 'عملیات',
      width: 170,
      render: (_, r) => (
        <Space>
          <Button size="small" onClick={() => openEdit(r)}>
            مشاهده/ویرایش
          </Button>
          <Button size="small" danger onClick={() => onDelete(r)}>
            حذف
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <Card
      title="وظایف"
      extra={
        <Space>
          <Button onClick={refresh}>بروزرسانی</Button>
          <Button type="primary" icon={<PlusOutlined />} onClick={openCreate}>
            وظیفه جدید
          </Button>
        </Space>
      }
    >
      <Table rowKey="id" loading={loading} columns={columns} dataSource={rows} />

      <FormDrawer
        title={editing ? 'ویرایش وظیفه' : 'ایجاد وظیفه'}
        open={open}
        onClose={() => setOpen(false)}
        onSubmit={onSave}
      >
        <Form layout="vertical" form={form} initialValues={{ status: 'open', priority: 'normal' }}>
          <Form.Item name="title" label="عنوان" rules={[{ required: true, message: 'عنوان لازم است' }]}>
            <Input placeholder="مثلا پیگیری قسط ..." />
          </Form.Item>

          <Form.Item name="description" label="توضیحات">
            <Input.TextArea rows={3} />
          </Form.Item>

          <Space style={{ width: '100%' }}>
            <Form.Item name="status" label="وضعیت" style={{ flex: 1 }}>
              <Select
                options={[
                  { value: 'open', label: 'باز' },
                  { value: 'done', label: 'انجام شد' },
                  { value: 'canceled', label: 'لغو' },
                ]}
              />
            </Form.Item>
            <Form.Item name="priority" label="اولویت" style={{ flex: 1 }}>
              <Select
                options={[
                  { value: 'low', label: 'کم' },
                  { value: 'normal', label: 'عادی' },
                  { value: 'high', label: 'بالا' },
                ]}
              />
            </Form.Item>
          </Space>

          <Form.Item name="assigned_user_id" label="ارجاع به کاربر">
            <Select allowClear showSearch options={userOptions} placeholder="اختیاری" />
          </Form.Item>

          <Form.Item name="assigned_marketer_id" label="ارجاع به بازاریاب">
            <Select allowClear showSearch options={marketerOptions} placeholder="اختیاری" />
          </Form.Item>

          <Space style={{ width: '100%' }}>
            <Form.Item name="due_date_j" label="تاریخ (شمسی)" style={{ flex: 1 }}>
              <JalaliDatePicker />
            </Form.Item>
            <Form.Item name="due_time" label="ساعت" style={{ width: 140 }}>
              <Input placeholder="HH:MM" />
            </Form.Item>
          </Space>

          <Form.Item name="reminder_minutes" label="یادآوری (دقیقه قبل)" tooltip="فعلا فقط ذخیره می‌شود">
            <Input placeholder="مثلا 30" />
          </Form.Item>

          <Card size="small" title="پیوست‌ها" style={{ marginTop: 8 }}>
            {!editing ? (
              <div style={{ opacity: 0.75 }}>بعد از ذخیره اولیه، امکان آپلود فعال می‌شود.</div>
            ) : (
              <Space direction="vertical" style={{ width: '100%' }}>
                <Upload
                  beforeUpload={async (file) => {
                    try {
                      await uploadTaskAttachment(editing.id, file, 'file')
                      message.success('آپلود شد')
                      setAttachments(await listTaskAttachments(editing.id))
                    } catch (e) {
                      message.error(errorToText(e, 'خطا در آپلود'))
                    }
                    return false
                  }}
                  showUploadList={false}
                >
                  <Button icon={<UploadOutlined />}>آپلود فایل</Button>
                </Upload>

                <Upload
                  accept="audio/*"
                  beforeUpload={async (file) => {
                    try {
                      await uploadTaskAttachment(editing.id, file, 'voice')
                      message.success('ویس آپلود شد')
                      setAttachments(await listTaskAttachments(editing.id))
                    } catch (e) {
                      message.error(errorToText(e, 'خطا در آپلود'))
                    }
                    return false
                  }}
                  showUploadList={false}
                >
                  <Button icon={<AudioOutlined />}>آپلود ویس</Button>
                </Upload>

                <Space direction="vertical" style={{ width: '100%' }}>
                  {attachments.map((item) => {
                    const isImage = (item.mime_type || '').startsWith('image/')
                    const isAudio = (item.mime_type || '').startsWith('audio/')
                    return (
                      <Card key={item.id} size="small">
                        <Space direction="vertical" style={{ width: '100%' }}>
                          <Space style={{ justifyContent: 'space-between', width: '100%' }}>
                            <div>{item.file_name || 'پیوست'}</div>
                            <Space>
                              <Button size="small" onClick={() => previewAttachment(item)}>
                                نمایش
                              </Button>
                              <Button
                                size="small"
                                onClick={async () => {
                                  try {
                                    const blob = await fetchBlob(getTaskAttachmentUrl(item.id))
                                    downloadBlob(blob, item.file_name || 'attachment')
                                  } catch (e) {
                                    message.error(errorToText(e, 'دانلود فایل ممکن نشد'))
                                  }
                                }}
                              >
                                دانلود
                              </Button>
                            </Space>
                          </Space>
                          {isImage ? <AuthenticatedImage src={getTaskAttachmentUrl(item.id)} alt={item.file_name || 'attachment'} /> : null}
                          {isAudio ? <audio controls style={{ width: '100%' }} src={getTaskAttachmentUrl(item.id)} /> : null}
                        </Space>
                      </Card>
                    )
                  })}
                </Space>
              </Space>
            )}
          </Card>
        </Form>
      </FormDrawer>

      <FilePreviewModal
        open={preview.open}
        url={preview.url}
        title={preview.title}
        mime={preview.mime}
        onClose={() => setPreview((p) => ({ ...p, open: false, url: '' }))}
      />
    </Card>
  )
}
