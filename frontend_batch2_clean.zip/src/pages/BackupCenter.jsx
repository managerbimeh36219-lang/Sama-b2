import React, { useEffect, useMemo, useState } from 'react'
import { Alert, Button, Card, Modal, Space, Table, Typography, message } from 'antd'
import { DownloadOutlined, RollbackOutlined, PlusOutlined } from '@ant-design/icons'
import { createBackup, getBackupDownloadUrl, listBackups, restoreBackup } from '../api/backup'
import { errorToText } from '../utils/errorText'
import { fetchBlob, downloadBlob } from '../utils/fileAccess'

function fmtSize(n) {
  const x = Number(n || 0)
  if (x < 1024) return `${x} B`
  if (x < 1024 * 1024) return `${(x / 1024).toFixed(1)} KB`
  if (x < 1024 * 1024 * 1024) return `${(x / 1024 / 1024).toFixed(1)} MB`
  return `${(x / 1024 / 1024 / 1024).toFixed(1)} GB`
}

function fmtJalali(dt) {
  if (!dt) return ''
  try {
    return new Date(dt).toLocaleString('fa-IR-u-ca-persian')
  } catch {
    return String(dt)
  }
}

export default function BackupCenter() {
  const me = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem('sama_user') || 'null')
    } catch {
      return null
    }
  }, [])

  const isMarketer = me?.user_type === 'marketer'
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [creating, setCreating] = useState(false)

  const refresh = async () => {
    setLoading(true)
    try {
      const data = await listBackups()
      setRows(data)
    } catch (e) {
      message.error(errorToText(e, 'خطا در دریافت لیست بکاپ‌ها'))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
  }, [])

  if (isMarketer) {
    return (
      <Alert
        type="warning"
        showIcon
        message="این بخش فقط برای مدیر قابل مشاهده است."
      />
    )
  }

  const columns = [
    { title: 'نام', dataIndex: 'name' },
    { title: 'تاریخ', dataIndex: 'created_at', width: 220, render: (v) => fmtJalali(v) },
    { title: 'حجم', dataIndex: 'size_bytes', width: 120, render: (v) => fmtSize(v) },
    {
      title: 'عملیات',
      width: 260,
      render: (_, r) => (
        <Space>
          <Button
            icon={<DownloadOutlined />}
            onClick={async () => {
              try {
                const url = getBackupDownloadUrl(r.name)
                const blob = await fetchBlob(url)
                downloadBlob(blob, r.name)
              } catch (e) {
                message.error(errorToText(e, 'خطا در دانلود بکاپ'))
              }
            }}
          >
            دانلود
          </Button>
          <Button
            danger
            icon={<RollbackOutlined />}
            onClick={() => {
              Modal.confirm({
                title: 'بازگردانی بکاپ',
                content: (
                  <div>
                    <Typography.Text>
                      این عملیات دیتابیس و فایل‌های آپلودی را به وضعیت زمان بکاپ برمی‌گرداند.
                    </Typography.Text>
                    <br />
                    <Typography.Text strong style={{ color: '#cf1322' }}>
                      قبل از ادامه مطمئن شوید کسی در حال ثبت اطلاعات نیست.
                    </Typography.Text>
                  </div>
                ),
                okText: 'بله، بازگردانی کن',
                cancelText: 'انصراف',
                okButtonProps: { danger: true },
                onOk: async () => {
                  try {
                    await restoreBackup(r.name)
                    message.success('بازگردانی انجام شد. لطفاً صفحه را رفرش کنید.')
                    await refresh()
                  } catch (e) {
                    message.error(errorToText(e, 'خطا در بازگردانی'))
                  }
                },
              })
            }}
          >
            بازگردانی
          </Button>
        </Space>
      ),
    },
  ]

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Alert
        type="info"
        showIcon
        message="بکاپ شامل دیتابیس + تمام فایل‌های آپلودی (uploads) است."
      />

      <Card>
        <Space>
          <Button
            type="primary"
            icon={<PlusOutlined />}
            loading={creating}
            onClick={async () => {
              setCreating(true)
              try {
                await createBackup()
                message.success('بکاپ ساخته شد')
                await refresh()
              } catch (e) {
                message.error(errorToText(e, 'خطا در ساخت بکاپ'))
              } finally {
                setCreating(false)
              }
            }}
          >
            ایجاد بکاپ جدید
          </Button>
          <Button onClick={refresh} loading={loading}>به‌روزرسانی</Button>
        </Space>
      </Card>

      <Card>
        <Table
          rowKey="name"
          dataSource={rows}
          columns={columns}
          loading={loading}
          pagination={{ pageSize: 10 }}
        />
      </Card>
    </Space>
  )
}
