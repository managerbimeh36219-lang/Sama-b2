import React, { useEffect, useMemo, useState } from 'react'
import { Button, Card, Divider, Input, Popconfirm, Select, Space, Tabs, Table, Tag, Typography, message, Switch } from 'antd'
import JalaliDatePicker from '../components/JalaliDatePicker.jsx'
import { normalizeDigits } from '../utils/normalizeDigits.js'
import { errorToText } from '../utils/errorText.js'
import { getVatRates, saveVatRates, getMarketerCommissionRules, saveMarketerCommissionRules } from '../api/settings.js'
import { commissionsApi } from '../api/commissions.js'
import { listMarketers } from '../api/marketers2.js'

const normJ = (v) => normalizeDigits(String(v ?? '')).trim()
const isJDate = (v) => /^\d{4}\/\d{2}\/\d{2}$/.test(normJ(v))

function VatEditor(){
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(false)
  const [date, setDate] = useState('')
  const [rate, setRate] = useState('')

  useEffect(() => {
    ;(async () => {
      try {
        setLoading(true)
        const res = await getVatRates()
        setItems(res?.items || [])
      } catch (e) {
        message.error(errorToText(e))
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  const upsert = () => {
    const d = normJ(date)
    const r = Number(normJ(rate))
    if (!isJDate(d)) return message.error('تاریخ شمسی نامعتبر است')
    if (!Number.isFinite(r)) return message.error('نرخ نامعتبر است')
    const exists = (items || []).some(x => x.effective_from_j === d)
    const next = exists
      ? (items || []).map(x => x.effective_from_j === d ? { ...x, rate_percent: r } : x)
      : [...(items || []), { effective_from_j: d, rate_percent: r }]
    next.sort((a,b) => (a.effective_from_j || '').localeCompare(b.effective_from_j || ''))
    setItems(next)
    setDate(''); setRate('')
  }

  const save = async () => {
    try {
      setLoading(true)
      await saveVatRates((items || []).map(x => ({ effective_from_j: normJ(x.effective_from_j), rate_percent: Number(x.rate_percent) })))
      message.success('ذخیره شد')
    } catch (e) {
      message.error(errorToText(e))
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="sama-card" styles={{ body: { padding: 12 } }}>
      <Typography.Text type="secondary">نرخ‌های ارزش افزوده تاریخ‌دار (شمسی)</Typography.Text>
      <Divider style={{ margin: '10px 0' }} />
      <Space wrap>
        <JalaliDatePicker value={date} onChange={(v) => setDate(normJ(v))} placeholder="از تاریخ" style={{ width: 180 }} />
        <Input value={rate} onChange={(e) => setRate(normJ(e.target.value))} placeholder="نرخ %" style={{ width: 120 }} />
        <Button type="primary" onClick={upsert}>افزودن/به‌روزرسانی</Button>
        <Button onClick={save} loading={loading}>ثبت نهایی</Button>
      </Space>
      <Divider style={{ margin: '12px 0' }} />
      <Table
        size="small"
        rowKey={(r) => r.effective_from_j}
        loading={loading}
        dataSource={items}
        pagination={false}
        columns={[
          { title: 'از تاریخ', dataIndex: 'effective_from_j', width: 140 },
          { title: 'نرخ (%)', dataIndex: 'rate_percent', width: 120 },
          {
            title: 'عملیات',
            width: 140,
            render: (_, row) => (
              <Space>
                <Button size="small" onClick={() => { setDate(row.effective_from_j); setRate(String(row.rate_percent)) }}>ویرایش</Button>
                <Popconfirm title="حذف شود؟" okText="بله" cancelText="خیر" onConfirm={() => setItems(items.filter(x => x.effective_from_j !== row.effective_from_j))}>
                  <Button size="small" danger>حذف</Button>
                </Popconfirm>
              </Space>
            )
          }
        ]}
      />
    </Card>
  )
}

function CommissionRatesEditor(){
  const [rates, setRates] = useState([]) // [{insurance_line, effective_from_j, rate_percent}]
  const [lines, setLines] = useState([]) // [{title}]
  const [loading, setLoading] = useState(false)
  const [line, setLine] = useState(undefined)
  const [date, setDate] = useState('')
  const [rate, setRate] = useState('')

  useEffect(() => {
    ;(async () => {
      try {
        setLoading(true)
        const [rs, ls] = await Promise.all([
          commissionsApi.listCommissionRates(),
          commissionsApi.listInsuranceLines(),
        ])
        setRates(rs?.items || rs || [])
        setLines(ls?.items || ls || [])
      } catch (e) {
        message.error(errorToText(e))
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  const lineOptions = useMemo(() => (lines || []).map(x => ({ value: x.title, label: x.title })), [lines])

  const upsert = async () => {
    const ln = (line || '').trim()
    const d = normJ(date)
    const r = Number(normJ(rate))
    if (!ln) return message.error('رشته را انتخاب کن')
    if (!isJDate(d)) return message.error('تاریخ شمسی نامعتبر است')
    if (!Number.isFinite(r)) return message.error('نرخ نامعتبر است')
    try {
      setLoading(true)
      await commissionsApi.upsertCommissionRate({ insurance_line: ln, effective_from_j: d, rate_percent: r })
      const rs = await commissionsApi.listCommissionRates()
      setRates(rs?.items || rs || [])
      setDate(''); setRate('')
      message.success('ثبت شد')
    } catch (e) {
      message.error(errorToText(e))
    } finally {
      setLoading(false)
    }
  }

  const rows = useMemo(() => {
    return (rates || []).slice().sort((a,b) => {
      const la = a.insurance_line || ''
      const lb = b.insurance_line || ''
      const da = a.effective_from_j || ''
      const db = b.effective_from_j || ''
      return la.localeCompare(lb) || da.localeCompare(db)
    })
  }, [rates])

  return (
    <Card className="sama-card" styles={{ body: { padding: 12 } }}>
      <Typography.Text type="secondary">نرخ کارمزد نمایندگی (به تفکیک رشته، تاریخ‌دار)</Typography.Text>
      <Divider style={{ margin: '10px 0' }} />
      <Space wrap>
        <Select
          value={line}
          onChange={setLine}
          placeholder="انتخاب رشته"
          style={{ width: 220 }}
          options={lineOptions}
          showSearch
          optionFilterProp="label"
        />
        <JalaliDatePicker value={date} onChange={(v) => setDate(normJ(v))} placeholder="از تاریخ" style={{ width: 180 }} />
        <Input value={rate} onChange={(e) => setRate(normJ(e.target.value))} placeholder="نرخ %" style={{ width: 120 }} />
        <Button type="primary" onClick={upsert} loading={loading}>ثبت</Button>
      </Space>
      <Divider style={{ margin: '12px 0' }} />
      <Table
        size="small"
        rowKey={(r) => `${r.insurance_line}__${r.effective_from_j}`}
        loading={loading}
        dataSource={rows}
        pagination={{ pageSize: 20 }}
        columns={[
          { title: 'رشته', dataIndex: 'insurance_line', width: 180 },
          { title: 'از تاریخ', dataIndex: 'effective_from_j', width: 140 },
          { title: 'نرخ (%)', dataIndex: 'rate_percent', width: 120 },
        ]}
      />
    </Card>
  )
}

function MarketerSplitEditor(){
  const [loading, setLoading] = useState(false)
  const [items, setItems] = useState([])
  const [marketers, setMarketers] = useState([])
  const [lines, setLines] = useState([])

  const [marketerId, setMarketerId] = useState(undefined)
  const [line, setLine] = useState(undefined)
  const [date, setDate] = useState('')
  const [share, setShare] = useState('')
  const [active, setActive] = useState(true)

  useEffect(() => {
    ;(async () => {
      try {
        setLoading(true)
        const [mr, rules, ls] = await Promise.all([
          listMarketers(),
          getMarketerCommissionRules(),
          commissionsApi.listInsuranceLines(),
        ])
        setMarketers(mr?.items || mr || [])
        setItems(rules?.items || [])
        setLines(ls?.items || ls || [])
      } catch (e) {
        message.error(errorToText(e))
      } finally {
        setLoading(false)
      }
    })()
  }, [])

  const marketerOptions = useMemo(() => (marketers || []).map(m => ({ value: m.id, label: `${m.full_name || m.name || ''}${m.code ? ` (${m.code})` : ''}`.trim() })), [marketers])
  const lineOptions = useMemo(() => (lines || []).map(x => ({ value: x.title, label: x.title })), [lines])

  const upsertLocal = () => {
    const mid = marketerId
    const ln = (line || '').trim()
    const d = normJ(date)
    const s = Number(normJ(share))
    if (!mid) return message.error('بازاریاب را انتخاب کن')
    if (!ln) return message.error('رشته را انتخاب کن')
    if (!isJDate(d)) return message.error('تاریخ شمسی نامعتبر است')
    if (!Number.isFinite(s)) return message.error('درصد نامعتبر است')

    const key = (x) => `${x.marketer_id}__${x.insurance_line}__${x.effective_from_j}`
    const rec = { marketer_id: mid, insurance_line: ln, effective_from_j: d, share_percent: s, is_active: !!active }
    const exists = (items || []).some(x => key(x) === key(rec))
    const next = exists
      ? (items || []).map(x => key(x) === key(rec) ? { ...x, share_percent: s, is_active: !!active } : x)
      : [...(items || []), rec]
    next.sort((a,b) => {
      const ma = String(a.marketer_id)
      const mb = String(b.marketer_id)
      return ma.localeCompare(mb) || (a.insurance_line || '').localeCompare(b.insurance_line || '') || (a.effective_from_j || '').localeCompare(b.effective_from_j || '')
    })
    setItems(next)
    setShare(''); setDate('');
    message.success('به پیش‌نویس اضافه شد')
  }

  const save = async () => {
    try {
      setLoading(true)
      const payload = (items || []).map(x => ({
        marketer_id: x.marketer_id,
        insurance_line: (x.insurance_line || '').trim(),
        share_percent: Number(x.share_percent),
        effective_from_j: normJ(x.effective_from_j),
        is_active: !!x.is_active,
      }))
      const res = await saveMarketerCommissionRules(payload)
      setItems(res?.items || payload)
      message.success('ذخیره شد')
    } catch (e) {
      message.error(errorToText(e))
    } finally {
      setLoading(false)
    }
  }

  const marketerById = useMemo(() => {
    const map = new Map()
    for (const m of marketers || []) map.set(m.id, m)
    return map
  }, [marketers])

  return (
    <Card className="sama-card" styles={{ body: { padding: 12 } }}>
      <Typography.Text type="secondary">سهم بازاریاب از کارمزد (برای هر رشته، تاریخ‌دار)</Typography.Text>
      <Divider style={{ margin: '10px 0' }} />

      <Space wrap>
        <Select
          value={marketerId}
          onChange={setMarketerId}
          placeholder="انتخاب بازاریاب"
          style={{ width: 260 }}
          options={marketerOptions}
          showSearch
          optionFilterProp="label"
        />
        <Select
          value={line}
          onChange={setLine}
          placeholder="انتخاب رشته"
          style={{ width: 220 }}
          options={lineOptions}
          showSearch
          optionFilterProp="label"
        />
        <JalaliDatePicker value={date} onChange={(v) => setDate(normJ(v))} placeholder="از تاریخ" style={{ width: 180 }} />
        <Input value={share} onChange={(e) => setShare(normJ(e.target.value))} placeholder="درصد سهم" style={{ width: 120 }} />
        <Space style={{ alignItems:'center' }}>
          <span style={{ opacity: .8 }}>فعال</span>
          <Switch checked={active} onChange={setActive} />
        </Space>
        <Button type="primary" onClick={upsertLocal}>افزودن/به‌روزرسانی پیش‌نویس</Button>
        <Button onClick={save} loading={loading}>ثبت نهایی</Button>
      </Space>

      <Divider style={{ margin: '12px 0' }} />
      <Table
        size="small"
        rowKey={(r) => `${r.marketer_id}__${r.insurance_line}__${r.effective_from_j}`}
        loading={loading}
        dataSource={items}
        pagination={{ pageSize: 20 }}
        columns={[
          {
            title: 'بازاریاب',
            dataIndex: 'marketer_id',
            render: (v) => {
              const m = marketerById.get(v)
              return m ? `${m.full_name || m.name || ''}${m.code ? ` (${m.code})` : ''}` : v
            },
          },
          { title: 'رشته', dataIndex: 'insurance_line', width: 160 },
          { title: 'از تاریخ', dataIndex: 'effective_from_j', width: 140 },
          { title: 'درصد', dataIndex: 'share_percent', width: 90 },
          {
            title: 'وضعیت',
            dataIndex: 'is_active',
            width: 110,
            render: (v) => v ? <Tag color="green">فعال</Tag> : <Tag color="default">غیرفعال</Tag>
          },
          {
            title: 'عملیات',
            width: 160,
            render: (_, row) => (
              <Space>
                <Button size="small" onClick={() => { setMarketerId(row.marketer_id); setLine(row.insurance_line); setDate(row.effective_from_j); setShare(String(row.share_percent)); setActive(!!row.is_active) }}>ویرایش</Button>
                <Popconfirm title="حذف شود؟" okText="بله" cancelText="خیر" onConfirm={() => setItems(items.filter(x => !(x.marketer_id===row.marketer_id && x.insurance_line===row.insurance_line && x.effective_from_j===row.effective_from_j)))}>
                  <Button size="small" danger>حذف</Button>
                </Popconfirm>
              </Space>
            )
          }
        ]}
      />
    </Card>
  )
}

export default function SettingsFinancial(){
  return (
    <div style={{ display:'grid', gap: 12 }}>
      <Typography.Title level={4} style={{ margin: 0 }}>تنظیمات مالی</Typography.Title>
      <Tabs
        items={[
          { key: 'vat', label: 'ارزش افزوده', children: <VatEditor /> },
          { key: 'commission_rates', label: 'نرخ کارمزد', children: <CommissionRatesEditor /> },
          { key: 'marketer_split', label: 'سهم بازاریاب', children: <MarketerSplitEditor /> },
        ]}
      />
    </div>
  )
}
