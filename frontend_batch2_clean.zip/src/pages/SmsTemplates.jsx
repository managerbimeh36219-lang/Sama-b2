import React, { useMemo, useState } from 'react'
import { Alert, Button, Card, Form, Input, Modal, Space, Table, Typography, message } from 'antd'
import { useQuery } from '@tanstack/react-query'

import {
  createSmsTemplate,
  deleteSmsTemplate,
  listSmsTemplates,
  updateSmsTemplate,
} from '../api/smsTemplates.js'

const VARS = [
  { label: 'نام بیمه‌گذار', v: '{{نام_بیمه_گذار}}' },
  { label: 'شماره بیمه‌نامه', v: '{{شماره_بیمه_نامه}}' },
  { label: 'مورد بیمه', v: '{{مورد_بیمه}}' },
  { label: 'شناسه پرداخت', v: '{{شناسه_پرداخت}}' },
  { label: 'تاریخ سررسید', v: '{{تاریخ_سررسید}}' },
  { label: 'تاریخ سررسید بیمه‌نامه', v: '{{تاریخ_سررسید_بیمه_نامه}}' },
  { label: 'مبلغ (ریال)', v: '{{مبلغ}}' },
]

export default function SmsTemplates() {
  const { data, isFetching, error, refetch } = useQuery({
    queryKey: ['smsTemplates'],
    queryFn: listSmsTemplates,
  })

  const rows = Array.isArray(data) ? data : []

  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form] = Form.useForm()

  const columns = useMemo(
    () => [
      {
        title: 'نام قالب',
        dataIndex: 'name',
        key: 'name',
        width: 220,
        ellipsis: true,
        sorter: (a, b) => (a.name || '').localeCompare(b.name || ''),
      },
      { title: 'متن', dataIndex: 'content', key: 'content', ellipsis: true },
      {
        title: 'عملیات',
        key: 'actions',
        width: 200,
        render: (_, r) => (
          <Space>
            <a
              onClick={() => {
                setEditing(r)
                setOpen(true)
                form.setFieldsValue({ key: r.key, name: r.name, content: r.content })
              }}
            >
              ویرایش
            </a>
            <a
              style={{ color: '#cf1322' }}
              onClick={() => {
                Modal.confirm({
                  title: 'حذف قالب پیامک',
                  content: 'آیا مطمئن هستید؟',
                  okText: 'حذف',
                  cancelText: 'انصراف',
                  okButtonProps: { danger: true },
                  onOk: async () => {
                    await deleteSmsTemplate(r.id)
                    message.success('حذف شد')
                    refetch()
                  },
                })
              }}
            >
              حذف
            </a>
          </Space>
        ),
      },
    ],
    [form, refetch]
  )

  const errText = error?.response?.data?.detail || error?.message

  async function onSave() {
    const v = await form.validateFields()
    const payload = { ...v }

    // key is required by backend; if user did not provide, generate a stable one
    if (!payload.key || !String(payload.key).trim()) {
      const ts = Date.now()
      payload.key = `custom_${ts}`
    }

    if (editing) {
      await updateSmsTemplate(editing.id, payload)
      message.success('ویرایش شد')
    } else {
      await createSmsTemplate(payload)
      message.success('ایجاد شد')
    }
    setOpen(false)
    setEditing(null)
    form.resetFields()
    refetch()
  }

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      {errText && (
        <Alert
          type="error"
          showIcon
          message={typeof errText === 'string' ? errText : JSON.stringify(errText)}
        />
      )}

      <Card className="sama-card" styles={{ body: { padding: 16 } }}>
        <Space style={{ width: '100%', justifyContent: 'space-between' }} wrap>
          <Typography.Title level={4} style={{ margin: 0, fontWeight: 800 }}>
            قالب‌های پیامک
          </Typography.Title>
          <Button
            type="primary"
            onClick={() => {
              setEditing(null)
              setOpen(true)
              form.resetFields()
            }}
          >
            قالب جدید
          </Button>
        </Space>

        <Typography.Text type="secondary">
          متغیرهای قابل استفاده: {VARS.map((x) => x.v).join('  ')}
        </Typography.Text>
      </Card>

      <Card className="sama-card" styles={{ body: { padding: 0 } }}>
        <Table
          size="small"
          rowKey="id"
          columns={columns}
          dataSource={rows}
          loading={isFetching}
          pagination={{ pageSize: 20 }}
          tableLayout="fixed"
        />
      </Card>

      <Modal
        title={editing ? 'ویرایش قالب' : 'قالب جدید'}
        open={open}
        onCancel={() => {
          setOpen(false)
          setEditing(null)
        }}
        okText={editing ? 'ذخیره' : 'ایجاد'}
        onOk={onSave}
        destroyOnClose
      >
        <Form form={form} layout="vertical">
          <Form.Item label="کلید قالب (اختیاری)" name="key">
            <Input placeholder="مثلاً: reminder_1" />
          </Form.Item>

          <Form.Item
            label="نام قالب"
            name="name"
            rules={[{ required: true, message: 'نام قالب الزامی است' }]}
          >
            <Input placeholder="مثلاً: یادآوری سررسید" />
          </Form.Item>

          <Card size="small" style={{ marginBottom: 12 }}>
            <Typography.Text type="secondary">
              برای درج متغیرها، روی هر مورد کلیک کنید:
            </Typography.Text>
            <div style={{ marginTop: 8, display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              {VARS.map((it) => (
                <Button
                  key={it.v}
                  size="small"
                  onClick={() => {
                    const cur = form.getFieldValue('content') || ''
                    form.setFieldsValue({ content: cur + it.v })
                  }}
                >
                  {it.label}
                </Button>
              ))}
            </div>
          </Card>

          <Form.Item
            label="متن پیامک"
            name="content"
            rules={[{ required: true, message: 'متن الزامی است' }]}
          >
            <Input.TextArea rows={5} />
          </Form.Item>
        </Form>
      </Modal>
    </Space>
  )
}
