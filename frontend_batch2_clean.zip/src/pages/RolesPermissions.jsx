import React, { useEffect, useMemo, useState } from 'react'
import { Button, Card, Checkbox, Divider, Form, Input, Modal, Select, Space, Typography, message } from 'antd'
import { createRole, getRolePerms, listPermissions, listRoles, setRolePerms, setUserRole, setUserPerms, getUserAccess, setUserAccess } from '../api/rbac'
import { listUsers } from '../api/users'

export default function RolesPermissions() {
  const [roles, setRoles] = useState([])
  const [perms, setPerms] = useState([])
  const [users, setUsers] = useState([])
  const [selectedUserId, setSelectedUserId] = useState(null)
  const [selectedUserRoleId, setSelectedUserRoleId] = useState(null)
  const [selectedUserPerms, setSelectedUserPerms] = useState([])
  const [selectedUserScope, setSelectedUserScope] = useState('')
  const [fieldRules, setFieldRules] = useState({
    'policy.mobile': { view: true, edit: false },
    'policy.national_id': { view: true, edit: false },
    'policy.total_premium': { view: true, edit: false },
    'payment.amount': { view: true, edit: false },
  })
  const [selectedRoleId, setSelectedRoleId] = useState(null)
  const [checked, setChecked] = useState([])
  const [loading, setLoading] = useState(false)

  const [createOpen, setCreateOpen] = useState(false)
  const [form] = Form.useForm()

  async function refresh() {
    setLoading(true)
    try {
      const [r, p, u] = await Promise.all([listRoles(), listPermissions(), listUsers()])
      setRoles(r)
      setPerms(p)
      setUsers(u)
      if (!selectedRoleId && r.length) setSelectedRoleId(r[0].id)
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در دریافت داده')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
  }, [])

  useEffect(() => {
    if (!selectedRoleId) return
    ;(async () => {
      try {
        const data = await getRolePerms(selectedRoleId)
        setChecked(data.permission_keys || [])
      } catch {
        setChecked([])
      }
    })()
  }, [selectedRoleId])

  useEffect(() => {
    if (!selectedUserId) return
    ;(async () => {
      try {
        const a = await getUserAccess(selectedUserId)
        setSelectedUserScope(a?.allowed_marketer_codes || '')
        const fr = a?.field_rules
        if (fr && Object.keys(fr).length) {
          setFieldRules((prev) => ({ ...prev, ...fr }))
        } else {
          // backward compat
          const fp = a?.field_perms || {}
          const conv = {}
          Object.keys(fp).forEach((k) => {
            conv[k] = { view: !!fp[k], edit: false }
          })
          setFieldRules((prev) => ({ ...prev, ...conv }))
        }
      } catch {
        // ignore
      }
    })()
  }, [selectedUserId])

  const roleOptions = useMemo(
    () => roles.map((r) => ({ value: r.id, label: `${r.title} (${r.key})` })),
    [roles]
  )

  async function save() {
    if (!selectedRoleId) return
    try {
      await setRolePerms(selectedRoleId, { permission_keys: checked })
      message.success('ذخیره شد')
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در ذخیره')
    }
  }

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card className="sama-card" styles={{ body: { padding: 12 } }} loading={loading}>
        <Space style={{ width: '100%', justifyContent: 'space-between' }}>
          <div>
            <Typography.Title level={5} style={{ margin: 0, fontWeight: 800 }}>
              سطوح دسترسی (نقش‌ها و دسترسی‌ها)
            </Typography.Title>
            <Typography.Text type="secondary">برای شروع، نقش بساز و دسترسی‌ها را تیک بزن.</Typography.Text>
          </div>
          <Button type="primary" onClick={() => setCreateOpen(true)}>
            نقش جدید
          </Button>
        </Space>

        <Divider style={{ margin: '12px 0' }} />

        <Space wrap style={{ width: '100%' }}>
          <Select
            style={{ minWidth: 320 }}
            value={selectedRoleId}
            options={roleOptions}
            onChange={(v) => setSelectedRoleId(v)}
            placeholder="انتخاب نقش"
          />
          <Button type="primary" onClick={save} disabled={!selectedRoleId}>
            ذخیره دسترسی‌های این نقش
          </Button>
        </Space>

        <Divider style={{ margin: '12px 0' }} />

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 8 }}>
          {perms.map((p) => (
            <Checkbox
              key={p.key}
              checked={checked.includes(p.key)}
              onChange={(e) => {
                const on = e.target.checked
                setChecked((prev) => (on ? [...prev, p.key] : prev.filter((x) => x !== p.key)))
              }}
            >
              {p.title}
              <Typography.Text type="secondary" style={{ marginRight: 8 }}>
                ({p.key})
              </Typography.Text>
            </Checkbox>
          ))}
        </div>
      </Card>

      <Modal
        title="ایجاد نقش جدید"
        open={createOpen}
        onCancel={() => setCreateOpen(false)}
        onOk={async () => {
          const values = await form.validateFields()
          try {
            await createRole(values)
            message.success('نقش ساخته شد')
            setCreateOpen(false)
            form.resetFields()
            await refresh()
          } catch (e) {
            message.error(e?.response?.data?.detail || 'خطا در ایجاد نقش')
          }
        }}
        okText="ایجاد"
      >
        <Form layout="vertical" form={form}>
          <Form.Item name="key" label="کلید نقش" rules={[{ required: true }]}
            tooltip="مثلا: admin یا marketer یا custom">
            <Input />
          </Form.Item>
          <Form.Item name="title" label="عنوان" rules={[{ required: true }]}
            >
            <Input placeholder="مثلا: بازاریاب" />
          </Form.Item>
        </Form>
      </Modal>
    

      <Card title="اختصاص نقش/دسترسی به کاربر" style={{ marginTop: 16 }}>
        <Space direction="vertical" style={{ width: '100%' }} size={12}>
          <Space wrap>
            <span>کاربر:</span>
            <Select
              style={{ minWidth: 260 }}
              placeholder="انتخاب کاربر"
              value={selectedUserId}
              onChange={(v) => setSelectedUserId(v)}
              options={(users || []).map((u) => ({
                value: u.id,
                label: `${u.full_name || ''} (${u.mobile})`,
              }))}
            />
          </Space>

          <Divider />

          <Space direction="vertical" style={{ width: '100%' }} size={8}>
            <Typography.Text>محدوده دسترسی داده (کد بازاریاب‌ها)</Typography.Text>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              برای محدود کردن دسترسی این کاربر به بیمه‌نامه‌ها/اقساط/تمدیدهای بازاریاب‌های مشخص، کدها را با کاما جدا کن.
              (برای مدیر خالی بگذار = همه)
            </Typography.Text>
            <Input
              value={selectedUserScope}
              onChange={(e) => setSelectedUserScope(e.target.value)}
              placeholder="مثلاً: 101,102,201"
            />
          </Space>

          <Divider />

          <Space direction="vertical" style={{ width: '100%' }} size={8}>
            <Typography.Text>حریم خصوصی/دسترسی فیلدی</Typography.Text>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 8 }}>
              {Object.keys(fieldRules).map((k) => (
                <div key={k} style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                  <Typography.Text style={{ width: 220, direction: 'ltr' }}>{k}</Typography.Text>
                  <Checkbox
                    checked={!!fieldRules?.[k]?.view}
                    onChange={(e) =>
                      setFieldRules((p) => ({
                        ...p,
                        [k]: { ...(p[k] || {}), view: e.target.checked, edit: e.target.checked ? !!p?.[k]?.edit : false },
                      }))
                    }
                  >
                    مشاهده
                  </Checkbox>
                  <Checkbox
                    disabled={!fieldRules?.[k]?.view}
                    checked={!!fieldRules?.[k]?.edit}
                    onChange={(e) => setFieldRules((p) => ({ ...p, [k]: { ...(p[k] || {}), edit: e.target.checked } }))}
                  >
                    ویرایش
                  </Checkbox>
                </div>
              ))}
            </div>
          </Space>

          <Button
            type="primary"
            disabled={!selectedUserId}
            onClick={async () => {
              try {
                await setUserAccess(selectedUserId, {
                  allowed_marketer_codes: selectedUserScope,
                  field_rules: fieldRules,
                })
                message.success('محدوده/حریم خصوصی ذخیره شد')
              } catch (e) {
                message.error(e?.response?.data?.detail || 'خطا در ذخیره')
              }
            }}
          >
            ذخیره محدوده/حریم خصوصی
          </Button>

          <Space wrap>
            <span>نقش:</span>
            <Select
              style={{ minWidth: 260 }}
              placeholder="انتخاب نقش"
              value={selectedUserRoleId}
              onChange={(v) => setSelectedUserRoleId(v)}
              options={(roles || []).map((r) => ({
                value: r.id,
                label: `${r.title} (${r.key})`,
              }))}
            />
            <Button
              type="primary"
              disabled={!selectedUserId || !selectedUserRoleId}
              onClick={async () => {
                try {
                  await setUserRole(selectedUserId, { role_id: selectedUserRoleId })
                  message.success('نقش کاربر ذخیره شد')
                } catch (e) {
                  message.error(e?.response?.data?.detail || 'خطا در ذخیره نقش')
                }
              }}
            >
              ذخیره نقش
            </Button>
          </Space>

          <Divider />

          <Space direction="vertical" style={{ width: '100%' }} size={8}>
            <Typography.Text>دسترسی‌های اختصاصی (اختیاری)</Typography.Text>
            <Select
              mode="multiple"
              allowClear
              style={{ width: '100%' }}
              placeholder="انتخاب دسترسی‌ها"
              value={selectedUserPerms}
              onChange={(vals) => setSelectedUserPerms(vals)}
              options={(perms || []).map((p) => ({ value: p.id, label: `${p.title} (${p.key})` }))}
            />
            <Button
              type="primary"
              disabled={!selectedUserId}
              onClick={async () => {
                try {
                  await setUserPerms(selectedUserId, { permission_ids: selectedUserPerms || [] })
                  message.success('دسترسی‌های کاربر ذخیره شد')
                } catch (e) {
                  message.error(e?.response?.data?.detail || 'خطا در ذخیره دسترسی‌ها')
                }
              }}
            >
              ذخیره دسترسی‌ها
            </Button>
          </Space>
        </Space>
      </Card>
</Space>
  )
}
