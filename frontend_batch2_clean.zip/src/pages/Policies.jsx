import React, { useEffect, useMemo, useState } from 'react'
import { Alert, Button, Card, Divider, Form, Input, Modal, Select, Space, Table, Tag, Typography, message, Grid } from 'antd'
import { DownOutlined, RightOutlined, EditOutlined, SaveOutlined, CloseOutlined } from '@ant-design/icons'
import JalaliDatePicker from '../components/JalaliDatePicker.jsx'
import SmartFiltersBar from '../components/SmartFiltersBar.jsx'
import SmartTable from '../components/SmartTable.jsx'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { useUserSetting } from '../hooks/useUserSetting.js'
import { http } from '../api/http.js'
import { useDebouncedValue, useSessionState } from '../utils/useSessionState.js'
import { commissionsApi } from '../api/commissions.js'
import { makeGsColumnFilter, uniq } from '../utils/gsFilters.jsx'
import { useMobileRecordDrawer } from '../hooks/useMobileRecordDrawer'
import MobileRecordDrawer from '../components/MobileRecordDrawer'
import { useTableView } from '../hooks/useTableView'
import TableViewBar from '../components/TableViewBar'

function fmtRial(n) {
  try {
    // نمایش عدد به انگلیسی (برای جلوگیری از خطا در کپی/پردازش)
    return new Intl.NumberFormat('en-US').format(n ?? 0)
  } catch {
    return String(n ?? '')
  }
}

function PaidTag({ paid, total }) {
  if ((paid || 0) >= (total || 0)) return <Tag color="green">تسویه</Tag>
  if ((paid || 0) > 0) return <Tag color="blue">نیمه‌پرداخت</Tag>
  return <Tag color="orange">بدهکار</Tag>
}

export default function Policies() {
  const screens = Grid.useBreakpoint()
  const isMobile = !!screens.xs && !screens.md

  const tableView = useTableView('table.policies.v1', { pageSize: 25, dense: false })

  const me = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem('sama_user') || 'null')
    } catch {
      return null
    }
  }, [])

  const { data: insuranceLinesData } = useQuery({
    queryKey: ['insurance-lines'],
    queryFn: () => commissionsApi.listInsuranceLines(),
    staleTime: 5 * 60 * 1000,
  })

  const insuranceLines = useMemo(() => {
    const titles = (insuranceLinesData || []).map((x) => x.title)
    // fallback: اگر هنوز چیزی در DB نباشد، از رشته‌های موجود در جدول بیمه‌نامه‌ها استفاده می‌کنیم
    return titles
  }, [insuranceLinesData])

  const { data: marketersData } = useQuery({
    queryKey: ['marketers'],
    queryFn: async () => {
      const res = await http.get('/marketers')
      return Array.isArray(res.data) ? res.data : []
    },
    staleTime: 5 * 60 * 1000,
  })

  const marketerOptions = useMemo(() => {
    const rows = Array.isArray(marketersData) ? marketersData : []
    const values = rows
      .map((x) => x?.name || x?.full_name || x?.title || x?.marketer_name || x?.code || '')
      .filter(Boolean)
    return uniq(values).map((x) => ({ value: x, label: x }))
  }, [marketersData])
  const isMarketer = me?.user_type === 'marketer'
  // زیرمنوهای باز شده با خروج از صفحه بسته شوند، اما فیلتر/جستجو باقی بماند
  const [expandedRowKeys, setExpandedRowKeys] = useState([])

  const qc = useQueryClient()

  const [state, setState] = useSessionState('policies:antd:v2', {
    global_q: '',
    q: '',
    line: '',
    issue_from: '',
    issue_to: '',
    sortField: 'issue_date_j',
    sortOrder: 'descend',
    pageSize: 25,
    page: 1,
  })

  const viewSetting = useUserSetting('view.policies')
  const view = useMemo(() => {
    try {
      return viewSetting.data?.value ? JSON.parse(viewSetting.data.value) : null
    } catch {
      return null
    }
  }, [viewSetting.data])

  const dq = useDebouncedValue(state.q, 350)
  const dGlobal = useDebouncedValue(state.global_q, 350)
  const dLine = useDebouncedValue(state.line, 350)
  const dFrom = useDebouncedValue(state.issue_from, 350)
  const dTo = useDebouncedValue(state.issue_to, 350)

  const pageSize = tableView.view.pageSize || state.pageSize

  const { data, isFetching, error } = useQuery({
    queryKey: ['policies', {
      q: dq,
      global_q: dGlobal,
      line: dLine,
      issue_from: dFrom,
      issue_to: dTo,
      sortField: state.sortField,
      sortOrder: state.sortOrder,
      page: state.page,
      pageSize,
    }],
    queryFn: async () => {
      const sort_dir = state.sortOrder === 'ascend' ? 'asc' : 'desc'
      const res = await http.get('/policies', {
        params: {
          q: undefined,
          line: dLine || undefined,
          issue_from: dFrom || undefined,
          issue_to: dTo || undefined,
          sort_by: state.sortField || undefined,
          sort_dir,
          page: state.page,
          page_size: pageSize,
        },
      })
      const payload = res.data || {}
      return {
        items: Array.isArray(payload.items) ? payload.items : (Array.isArray(payload) ? payload : []),
        total: Number(payload.total || 0),
      }
    },
    placeholderData: (prev) => prev,
  })

  const rows = data?.items || []
  const totalRows = Number(data?.total || 0)

  // Lazy details cache (must be defined before useMemo that references it)
  const [detailsCache, setDetailsCache] = useSessionState('policies:details:v1', {})

  const filtered = useMemo(() => rows, [rows])

  const policyNumberValues = useMemo(() => uniq(filtered.map((r) => r.policy_number)), [filtered])
  const lineValues = useMemo(() => uniq(filtered.map((r) => r.insurance_line)), [filtered])
  const marketerValues = useMemo(() => uniq(filtered.map((r) => r.marketer)), [filtered])
  const holderValues = useMemo(() => uniq(filtered.map((r) => r.policyholder_name)), [filtered])
  const insuredValues = useMemo(() => uniq(filtered.map((r) => r.insured_item)), [filtered])
  const issueValues = useMemo(() => uniq(filtered.map((r) => r.issue_date_j)), [filtered])
  const totalValues = useMemo(() => uniq(filtered.map((r) => r.total_premium_rial)), [filtered])

  // ثبت دستی بیمه‌نامه
  const [manualOpen, setManualOpen] = useState(false)
  const [manualLoading, setManualLoading] = useState(false)
  const [manualForm] = Form.useForm()
  const manualLine = Form.useWatch('insurance_line', manualForm)
  
  // زیرمنوی باز شده با برگشت به صفحه باید حفظ شود (فقط آخرین مورد باز می‌ماند)

  async function ensureDetail(id) {
    const res = await http.get(`/policies/${id}`)
    setDetailsCache((m) => ({ ...m, [id]: { data: res.data, ts: Date.now() } }))
  }

  const toggleExpand = async (id) => {
    // اگر باز است → ببند
    if (expandedRowKeys.includes(id)) {
      setExpandedRowKeys((prev) => prev.filter((k) => k !== id))
      return
    }

    // اگر بسته است → جزئیات بگیر (پرداخت‌ها ممکن است در صفحه اقساط ثبت شده باشد)
    // اگر دیتا خیلی تازه بود (کمتر از 10 ثانیه)، دوباره درخواست نمی‌زنیم.
    const cached = detailsCache?.[id]
    const ts = cached && typeof cached === 'object' ? cached.ts : null
    const isFresh = ts && (Date.now() - ts) < 10_000
    if (!cached || !isFresh) {
      await ensureDetail(id)
    }

    // فقط آخرین زیرمنو باز بماند
    setExpandedRowKeys([id])
  }

  // ---------------- Actions (inline edit + installments bulk)
  const [editPolicyId, setEditPolicyId] = useState(null)
  const [editSysId, setEditSysId] = useState(null)
  const [editSecId, setEditSecId] = useState(null)
  const [endorseOpen, setEndorseOpen] = useState(false)
  const [activePolicyId, setActivePolicyId] = useState(null)
  const [editEndorseId, setEditEndorseId] = useState(null)
  const [endorseEditForm] = Form.useForm()

  const [policyForm] = Form.useForm()
  const [sysForm] = Form.useForm()
  const [secForm] = Form.useForm()
  const [endorseForm] = Form.useForm()

  function openPolicyEdit(d) {
    if (isMarketer) {
      message.error('برای بازاریاب فقط مشاهده مجاز است')
      return
    }
    setActivePolicyId(d.id)
    setEditPolicyId(d.id)
    setEditSysId(null)
    setEditSecId(null)
    policyForm.setFieldsValue({
      policy_number: d.policy_number,
      insurance_line: d.insurance_line,
      policyholder_name: d.policyholder_name,
      national_id: d.national_id,
      mobile: d.mobile,
      insured_item: d.insured_item,
      start_date_j: d.start_date_j,
      end_date_j: d.end_date_j,
      issue_date_j: d.issue_date_j,
      total_premium_rial: d.total_premium_rial,
      marketer: d.marketer,
      address: d.address,
      birth_date_j: d.birth_date_j,
      phone: d.phone,
      job: d.job,
      prev_policy_number: d.prev_policy_number,
      late_penalty_rial: d.late_penalty_rial,
      notes: d.notes,
    })
  }

  function openSysEdit(d) {
    if (isMarketer) {
      message.error('برای بازاریاب فقط مشاهده مجاز است')
      return
    }
    setActivePolicyId(d.id)
    setEditSysId(d.id)
    setEditPolicyId(null)
    setEditSecId(null)
    const items = (d.payments || [])
      .filter((x) => x.is_system)
      .map((x) => ({
        id: x.payment_item_id,
        system_payment_id: x.system_payment_id || '',
        due_date_j: x.due_date_j || '',
        amount_rial: x.amount_rial || 0,
      }))
    sysForm.setFieldsValue({ items, deleted_ids: [] })
  }

  
function openEndorse(d) {
    if (isMarketer) {
      message.error('برای بازاریاب فقط مشاهده مجاز است')
      return
    }
  setActivePolicyId(d.id)
  endorseForm.resetFields()
  endorseForm.setFieldsValue({
    endorsement_type: 'افزایشی',
    premium_rial: 0,
  })
  setEndorseOpen(true)
}

async function saveEndorse() {
  const v = await endorseForm.validateFields()
  await http.post(`/policies/${activePolicyId}/endorsements`, v)
  message.success('الحاقیه ثبت شد')
  setEndorseOpen(false)
  const res = await http.get(`/policies/${activePolicyId}`)
  setDetailsCache((m) => ({ ...m, [activePolicyId]: { data: res.data, ts: Date.now() } }))
  qc.invalidateQueries({ queryKey: ['policies'] })
}

function openSecEdit(d) {
    if (isMarketer) {
      message.error('برای بازاریاب فقط مشاهده مجاز است')
      return
    }
    setActivePolicyId(d.id)
  setEditSecId(d.id)
  setEditPolicyId(null)
  setEditSysId(null)
    const items = (d.payments || [])
      .filter((x) => !x.is_system && !x.is_discount)
      .map((x) => ({
        id: x.payment_item_id,
        due_date_j: x.due_date_j || '',
        amount_rial: x.amount_rial || 0,
      }))
    secForm.setFieldsValue({ items, deleted_ids: [] })
  }

  async function savePolicyEdit() {
    const v = await policyForm.validateFields()
    if (v.insurance_line !== 'شخص ثالث') {
      v.late_penalty_rial = null
    }
    await http.put(`/policies/${activePolicyId}`, v)
    message.success('بیمه‌نامه ذخیره شد')
    setEditPolicyId(null)
    setDetailsCache((m) => ({
      ...m,
      [activePolicyId]: {
        data: { ...(m[activePolicyId]?.data || {}), ...v },
        ts: Date.now(),
      },
    }))
    qc.invalidateQueries({ queryKey: ['policies'] })
  }

  async function saveEndorseEdit(policyId) {
    const v = await endorseEditForm.validateFields()
    await http.put(`/policies/${policyId}/endorsements/${editEndorseId}`, v)
    message.success('الحاقیه ویرایش شد')
    setEditEndorseId(null)
    const res = await http.get(`/policies/${policyId}`)
    setDetailsCache((m) => ({ ...m, [policyId]: { data: res.data, ts: Date.now() } }))
    qc.invalidateQueries({ queryKey: ['policies'] })
  }

  async function saveSysBulk() {
    const v = await sysForm.validateFields()
    const payload = { items: v.items || [], deleted_ids: v.deleted_ids || [] }
    await http.post(`/policies/${activePolicyId}/payment-items/system/bulk`, payload)
    message.success('اقساط سیستمی ذخیره شد')
    setEditSysId(null)
    // refresh details
    const res = await http.get(`/policies/${activePolicyId}`)
    setDetailsCache((m) => ({ ...m, [activePolicyId]: { data: res.data, ts: Date.now() } }))
    qc.invalidateQueries({ queryKey: ['installments'] })
  }

  async function saveSecBulk(applyDiscount = false) {
    const v = await secForm.validateFields()
    const payload = { items: v.items || [], deleted_ids: v.deleted_ids || [] }
    try {
      await http.post(`/policies/${activePolicyId}/payment-items/secondary/bulk`, payload, {
        params: { apply_discount: applyDiscount },
      })
      message.success('اقساط ثانویه ذخیره شد')
      setEditSecId(null)
      const res = await http.get(`/policies/${activePolicyId}`)
      setDetailsCache((m) => ({ ...m, [activePolicyId]: { data: res.data, ts: Date.now() } }))
      qc.invalidateQueries({ queryKey: ['installments'] })
    } catch (e) {
      const d = e?.response?.data?.detail
      if (d && typeof d === 'object' && d.code === 'SECONDARY_SUM_LESS') {
        Modal.confirm({
          title: 'تأیید تخفیف',
          content: `برای این بیمه‌نامه تخفیف به مبلغ ${fmtRial(d.discount_rial)} ریال در نظر گرفته‌اید؟`,
          okText: 'بله، تخفیف را ثبت کن',
          cancelText: 'خیر',
          onOk: async () => {
            await saveSecBulk(true)
          },
        })
        return
      }
      const msg = d || e?.message || 'خطا'
      message.error(typeof msg === 'string' ? msg : JSON.stringify(msg))
    }
  }
  async function handleDeletePolicy(d) {
  Modal.confirm({
    title: 'حذف بیمه‌نامه',
    content: `برای بیمه‌نامه ${d.policy_number} چه کاری انجام شود؟`,
    okText: 'حذف کامل',
    cancelText: 'انصراف',
    onOk: async () => {
      try {
        await http.delete(`/policies/${d.id}`)
        message.success('بیمه‌نامه حذف شد')
        setDetailsCache((m) => {
          const copy = { ...(m || {}) }
          delete copy[d.id]
          return copy
        })
        qc.invalidateQueries({ queryKey: ['policies'] })
      } catch (e) {
        if (e?.response?.status === 409) {
          Modal.confirm({
            title: 'حذف کامل ممکن نیست',
            content: 'برای این بیمه‌نامه اطلاعات وابسته ثبت شده. می‌خواهی غیرفعال شود و در محاسبات لحاظ نشود؟',
            okText: 'بله، غیرفعال شود',
            cancelText: 'خیر',
            onOk: async () => {
              await http.post(`/policies/${d.id}/deactivate`, null, {
                params: {
                  reason: 'ورود اشتباه / دارای وابستگی',
                  note: 'غیرفعال‌سازی از صفحه بیمه‌نامه‌ها',
                },
              })
              message.success('بیمه‌نامه غیرفعال شد')
              qc.invalidateQueries({ queryKey: ['policies'] })
            },
          })
          return
        }
        message.error(e?.response?.data?.detail?.message || e?.response?.data?.detail || 'خطا در حذف بیمه‌نامه')
      }
    },
  })
}

  const columns = useMemo(() => [
    {
      title: '',
      key: 'exp',
      width: 44,
      fixed: 'right',
      align: 'center',
      render: (_, r) => {
        const isOpen = expandedRowKeys.includes(r.id)
        return (
          <Button
            shape="circle"
            size="small"
            className="sama-expand-btn"
          icon={isOpen ? <DownOutlined /> : <RightOutlined />}
            onClick={(e) => {
              e.stopPropagation()
              toggleExpand(r.id)
            }}
          />
        )
      },
    },
    {
      title: 'رشته',
      dataIndex: 'insurance_line',
      key: 'insurance_line',
      width: 150,
      ellipsis: true,
      sorter: true,
      ...makeGsColumnFilter({ key: 'insurance_line', getValues: () => lineValues }),
    },
    {
      title: 'بازاریاب',
      dataIndex: 'marketer',
      key: 'marketer',
      width: 150,
      ellipsis: true,
      sorter: true,
      ...makeGsColumnFilter({ key: 'marketer', getValues: () => marketerValues }),
    },
    { title: 'شماره بیمه‌نامه', dataIndex: 'policy_number', key: 'policy_number', width: 170, ellipsis: true, sorter: true,
      ...makeGsColumnFilter({ key:'policy_number', getValues:()=>policyNumberValues }),
    },
    { title: 'بیمه‌گذار', dataIndex: 'policyholder_name', key: 'policyholder_name', width: 200, ellipsis: true, sorter: true,
      ...makeGsColumnFilter({ key:'policyholder_name', getValues:()=>holderValues }),
    },
    { title: 'مورد بیمه', dataIndex: 'insured_item', key: 'insured_item', width: 180, ellipsis: true, sorter: true,
      ...makeGsColumnFilter({ key:'insured_item', getValues:()=>insuredValues }),
    },
    { title: 'شروع', dataIndex: 'start_date_j', key: 'start_date_j', width: 110, sorter: true },
    { title: 'پایان', dataIndex: 'end_date_j', key: 'end_date_j', width: 110, sorter: true },
    {
      title: 'حق بیمه',
      dataIndex: 'premium_status',
      key: 'premium_status',
      width: 130,
      render: (v) => {
        const t = String(v || '')
        const color = t.includes('تسویه') ? 'green' : (t.includes('بدهکار') ? 'orange' : 'default')
        return <Tag color={color} style={{ margin: 0 }}>{t || '—'}</Tag>
      },
    },
    {
      title: 'تمدید',
      dataIndex: 'renewal_status',
      key: 'renewal_status',
      width: 120,
      render: (v) => {
        const t = String(v || '')
        const color = t.includes('تمدید') ? 'green' : (t.includes('در انتظار') ? 'gold' : 'default')
        return <Tag color={color} style={{ margin: 0 }}>{t || '—'}</Tag>
      },
    },
    {
      title: 'مستندات',
      dataIndex: 'documents_status',
      key: 'documents_status',
      width: 130,
      render: (v) => {
        const t = String(v || '')
        const color = t.includes('کامل') ? 'green' : (t.includes('ناقص') ? 'red' : 'default')
        return <Tag color={color} style={{ margin: 0 }}>{t || '—'}</Tag>
      },
    },
  ], [expandedRowKeys, toggleExpand, lineValues, marketerValues])

  const mobileDrawer = useMobileRecordDrawer({ title: 'جزئیات بیمه‌نامه', columns })

  const errText = error?.response?.data?.detail || error?.message



  
  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      {errText && <Alert type="error" showIcon message={typeof errText === 'string' ? errText : JSON.stringify(errText)} />}

      <Card className="sama-card" styles={{ body: { padding: 12 } }} extra={!isMarketer ? (<Button type="primary" onClick={() => setManualOpen(true)}>ثبت دستی بیمه‌نامه</Button>) : null}>
        <Typography.Title level={5} style={{ margin: 0 }}>بیمه‌نامه‌ها</Typography.Title>
      </Card>

      <Card className="sama-card" styles={{ body: { padding: 16 } }}>
        <Space wrap style={{ width: '100%' }}>
          <Select
            value={state.line || undefined}
            onChange={(v) => setState((s) => ({ ...s, line: v || '', page: 1 }))}
            placeholder="رشته"
            allowClear
            style={{ width: 220 }}
            options={[{ value: '', label: 'همه' }, ...(insuranceLines || []).map((x) => ({ value: x, label: x }))]}
          />
          <Input
            value={state.issue_from}
            onChange={(e) => setState((s) => ({ ...s, issue_from: e.target.value, page: 1 }))}
            placeholder="از تاریخ صدور (1403/01/01)"
            style={{ width: 190 }}
          />
          <Input
            value={state.issue_to}
            onChange={(e) => setState((s) => ({ ...s, issue_to: e.target.value, page: 1 }))}
            placeholder="تا تاریخ صدور (1403/12/29)"
            style={{ width: 190 }}
          />
        </Space>
      </Card>

      <Card className="sama-card" styles={{ body: { padding: 0 } }} extra={<TableViewBar view={tableView.view} onChange={tableView.save} />}>
        <Table
          size={tableView.view.dense ? 'small' : 'middle'}
          rowKey="id"
          columns={columns}
          dataSource={rows}
          loading={isFetching}
          view={view || {}}
          onSaveView={async (v) => {
            await viewSetting.save(JSON.stringify(v || {}))
          }}
          onResetView={async () => {
            await viewSetting.save(null)
          }}
          tableLayout="auto"
          scroll={{ x: 1600 }}
          pagination={{
            current: state.page,
            pageSize: tableView.view.pageSize || state.pageSize,
            total: totalRows,
            showSizeChanger: true,
            pageSizeOptions: [10, 25, 50, 100],
            onChange: (page, pageSize) => {
              setState((s) => ({ ...s, page, pageSize }))
              tableView.save({ pageSize })
            },
          }}
          onChange={(pagination, __, sorter) => {
            const nextPage = pagination?.current || 1
            const nextPageSize = pagination?.pageSize || pageSize
            const s = Array.isArray(sorter) ? sorter[0] : sorter
            setState((st) => ({
              ...st,
              page: nextPage,
              pageSize: nextPageSize,
              sortField: s?.field || st.sortField,
              sortOrder: s?.order || st.sortOrder,
            }))
            tableView.save({ pageSize: nextPageSize })
          }}
          onRow={
            isMobile
              ? (record) => ({
                  onClick: () => mobileDrawer.open(record),
                  style: { cursor: 'pointer' },
                })
              : undefined
          }
          expandable={
            isMobile
              ? undefined
              : {
                  expandIcon: () => null,
                  expandedRowKeys,
                  expandedRowRender: (record) => {
              const cached = detailsCache[record.id]
              const d = cached && typeof cached === 'object' && ('data' in cached) ? cached.data : cached
              if (!d) return <div style={{ padding: 12 }}>در حال دریافت جزئیات…</div>

              const discount = Number(d.discount_amount_rial || 0)

              return (
                <div style={{ padding: 12 }}>
                  <Space direction="vertical" size={10} style={{ width: '100%' }}>
                    {!isMarketer ? (
                      <Space wrap>
                        <Button onClick={() => openPolicyEdit(d)}>{editPolicyId === d.id ? 'در حال ویرایش بیمه‌نامه' : 'ویرایش بیمه‌نامه'}</Button>
                        <Button onClick={() => openSysEdit(d)}>{editSysId === d.id ? 'در حال ویرایش اقساط سیستمی' : 'ویرایش اقساط سیستمی'}</Button>
                        <Button type="primary" onClick={() => openSecEdit(d)}>{editSecId === d.id ? 'در حال ویرایش اقساط ثانویه' : 'ویرایش اقساط ثانویه'}</Button>
                        <Button onClick={() => openEndorse(d)}>ثبت الحاقیه</Button>
                        <Button danger onClick={() => handleDeletePolicy(d)}>حذف / غیرفعال‌سازی</Button>
                      </Space>
                    ) : null}

                    {/* خلاصه پرداخت‌ها (دو دفتر) */}

                    {editPolicyId === d.id ? (
                      <Card size="small" className="sama-card">
                        <Space style={{ width: '100%', justifyContent: 'space-between' }}>
                          <Typography.Text style={{ fontWeight: 700 }}>ویرایش بیمه‌نامه</Typography.Text>
                          <Button onClick={() => setEditPolicyId(null)}>بستن</Button>
                        </Space>
                        <Form form={policyForm} layout="vertical" style={{ marginTop: 8 }}>
                          <Space wrap>
                            <Form.Item label="شماره بیمه‌نامه" name="policy_number" rules={[{ required: true, message: 'الزامی' }]}>
                              <Input style={{ width: 220 }} />
                            </Form.Item>
                            <Form.Item label="رشته" name="insurance_line" rules={[{ required: true, message: 'الزامی' }]}>
                              <Select
                                style={{ width: 220 }}
                                showSearch
                                options={(insuranceLines || []).map((l) => ({ value: l, label: l }))}
                              />
                            </Form.Item>
                            <Form.Item label="نام بیمه‌گذار" name="policyholder_name" rules={[{ required: true, message: 'الزامی' }]}>
                              <Input style={{ width: 220 }} />
                            </Form.Item>
                          </Space>

                          <Space wrap>
                            <Form.Item label="کدملی" name="national_id" rules={[{ required: true, message: 'الزامی' }]}>
                              <Input style={{ width: 220 }} />
                            </Form.Item>
                            <Form.Item label="موبایل" name="mobile" rules={[{ required: true, message: 'الزامی' }]}>
                              <Input style={{ width: 220 }} />
                            </Form.Item>
                            <Form.Item label="بازاریاب" name="marketer">
                              <Select
                                allowClear
                                showSearch
                                optionFilterProp="label"
                                placeholder="انتخاب از لیست بازاریابان"
                                style={{ width: 220 }}
                                options={marketerOptions}
                              />
                            </Form.Item>
                          </Space>

                          <Form.Item label="مورد بیمه" name="insured_item" rules={[{ required: true, message: 'الزامی' }]}>
                            <Input />
                          </Form.Item>

                          <Space wrap>
                            <Form.Item label="تاریخ صدور" name="issue_date_j" rules={[{ required: true, message: 'الزامی' }]}>
                              <JalaliDatePicker style={{ width: 180 }} />
                            </Form.Item>
                            <Form.Item label="شروع" name="start_date_j" rules={[{ required: true, message: 'الزامی' }]}>
                              <JalaliDatePicker style={{ width: 180 }} />
                            </Form.Item>
                            <Form.Item label="تاریخ انقضاء" name="end_date_j" rules={[{ required: true, message: 'الزامی' }]}>
                              <JalaliDatePicker style={{ width: 180 }} />
                            </Form.Item>
                          </Space>

                          <Space wrap>
                            <Form.Item label="کل حق بیمه (ریال)" name="total_premium_rial" rules={[{ required: true, message: 'الزامی' }]}>
                              <Input style={{ width: 220 }} />
                            </Form.Item>
                            <Form.Item label="تاریخ تولد" name="birth_date_j">
                              <JalaliDatePicker style={{ width: 220 }} />
                            </Form.Item>
                            <Form.Item label="تلفن" name="phone">
                              <Input style={{ width: 220 }} />
                            </Form.Item>
                          </Space>

                          <Space wrap>
                            <Form.Item label="شغل بیمه‌گذار" name="job">
                              <Input style={{ width: 220 }} />
                            </Form.Item>
                            <Form.Item label="شماره بیمه‌نامه سال قبل" name="prev_policy_number">
                              <Input style={{ width: 220 }} />
                            </Form.Item>

                            <Form.Item shouldUpdate noStyle>
                              {() => {
                                const line = policyForm.getFieldValue('insurance_line')
                                return line === 'شخص ثالث' ? (
                                  <Form.Item label="جریمه دیرکرد" name="late_penalty_rial">
                                    <Input style={{ width: 220 }} />
                                  </Form.Item>
                                ) : null
                              }}
                            </Form.Item>
                          </Space>

                          <Form.Item label="آدرس" name="address" rules={[{ required: true, message: 'الزامی' }]}>
                            <Input.TextArea rows={2} />
                          </Form.Item>
                          <Form.Item label="توضیحات" name="notes">
                            <Input.TextArea rows={2} />
                          </Form.Item>

                          <Button type="primary" onClick={savePolicyEdit} block>ثبت نهایی</Button>
                        </Form>
                      </Card>
                    ) : null}

                    {editSysId === d.id ? (
                      <Card size="small" className="sama-card">
                        <Space style={{ width: '100%', justifyContent: 'space-between' }}>
                          <Typography.Text style={{ fontWeight: 700 }}>ویرایش اقساط سیستمی</Typography.Text>
                          <Button onClick={() => setEditSysId(null)}>بستن</Button>
                        </Space>
                        <Form form={sysForm} layout="vertical" initialValues={{ items: [], deleted_ids: [] }} style={{ marginTop: 8 }}>
                          <Form.List name="items">
                            {(fields, { add, remove }) => (
                              <Space direction="vertical" style={{ width: '100%' }} size={8}>
                                <Button onClick={() => add({ system_payment_id: '', due_date_j: '', amount_rial: 0 })}>+ افزودن قسط سیستمی</Button>
                                {fields.map((f) => (
                                  <Card key={f.key} size="small" className="sama-card">
                                    <Space wrap style={{ width: '100%' }}>
                                      <Form.Item name={[f.name, 'id']} hidden><Input /></Form.Item>
                                      <Form.Item label="شناسه پرداخت" name={[f.name, 'system_payment_id']} rules={[{ required: true, message: 'الزامی' }]}><Input style={{ width: 180 }} /></Form.Item>
                                      <Form.Item label="سررسید" name={[f.name, 'due_date_j']} rules={[{ required: true, message: 'الزامی' }]}><JalaliDatePicker style={{ width: 160 }} /></Form.Item>
                                      <Form.Item label="مبلغ" name={[f.name, 'amount_rial']} rules={[{ required: true, message: 'الزامی' }]}><Input style={{ width: 160 }} /></Form.Item>
                                      <Button danger onClick={() => remove(f.name)}>حذف</Button>
                                    </Space>
                                  </Card>
                                ))}
                              </Space>
                            )}
                          </Form.List>
                          <Divider />
                          <Button type="primary" onClick={saveSysBulk} block>ثبت نهایی</Button>
                        </Form>
                      </Card>
                    ) : null}

                    {editSecId === d.id ? (
                      <Card size="small" className="sama-card">
                        <Space style={{ width: '100%', justifyContent: 'space-between' }}>
                          <Typography.Text style={{ fontWeight: 700 }}>ویرایش اقساط ثانویه</Typography.Text>
                          <Button onClick={() => setEditSecId(null)}>بستن</Button>
                        </Space>
                        <Form form={secForm} layout="vertical" initialValues={{ items: [], deleted_ids: [] }} style={{ marginTop: 8 }}>
                          <Form.List name="items">
                            {(fields, { add, remove }) => (
                              <Space direction="vertical" style={{ width: '100%' }} size={8}>
                                <Button onClick={() => add({ due_date_j: '', amount_rial: 0 })}>+ افزودن قسط ثانویه</Button>
                                {fields.map((f) => (
                                  <Card key={f.key} size="small" className="sama-card">
                                    <Space wrap style={{ width: '100%' }}>
                                      <Form.Item name={[f.name, 'id']} hidden><Input /></Form.Item>
                                      <Form.Item label="سررسید" name={[f.name, 'due_date_j']} rules={[{ required: true, message: 'الزامی' }]}><JalaliDatePicker style={{ width: 160 }} /></Form.Item>
                                      <Form.Item label="مبلغ" name={[f.name, 'amount_rial']} rules={[{ required: true, message: 'الزامی' }]}><Input style={{ width: 200 }} /></Form.Item>
                                      <Button danger onClick={() => remove(f.name)}>حذف</Button>
                                    </Space>
                                  </Card>
                                ))}
                              </Space>
                            )}
                          </Form.List>
                          <Divider />
                          <Button type="primary" onClick={() => saveSecBulk(false)} block>ثبت نهایی</Button>
                        </Form>
                      </Card>
                    ) : null}

                    <div className="sama-detail-grid">
                      <div><Typography.Text type="secondary">کدملی</Typography.Text><div className="v">{d.national_id || '—'}</div></div>
                      <div><Typography.Text type="secondary">موبایل</Typography.Text><div className="v">{d.mobile || '—'}</div></div>
                      <div><Typography.Text type="secondary">کل حق بیمه</Typography.Text><div className="v">{fmtRial(d.total_premium_rial)}</div></div>
                      <div><Typography.Text type="secondary">بازاریاب</Typography.Text><div className="v">{d.marketer || '—'}</div></div>
                      <div style={{ gridColumn: '1 / -1' }}><Typography.Text type="secondary">آدرس</Typography.Text><div className="v">{d.address || '—'}</div></div>
                      <div><Typography.Text type="secondary">تاریخ تولد</Typography.Text><div className="v">{d.birth_date_j || '—'}</div></div>
                      <div><Typography.Text type="secondary">تلفن</Typography.Text><div className="v">{d.phone || '—'}</div></div>
                      <div><Typography.Text type="secondary">تاریخ صدور</Typography.Text><div className="v">{d.issue_date_j || '—'}</div></div>
                      <div><Typography.Text type="secondary">شغل</Typography.Text><div className="v">{d.job || '—'}</div></div>
                      <div><Typography.Text type="secondary">شماره سال قبل</Typography.Text><div className="v">{d.prev_policy_number || '—'}</div></div>
                      <div><Typography.Text type="secondary">جریمه دیرکرد</Typography.Text><div className="v">{fmtRial(d.late_penalty_rial)}</div></div>
                      <div style={{ gridColumn: '1 / -1' }}><Typography.Text type="secondary">توضیحات</Typography.Text><div className="v">{d.notes || '—'}</div></div>
                    </div>

                    {/* الحاقیه‌ها باید بالای «اقلام حق بیمه» و به صورت زیر هم نمایش داده شوند */}
                    {(d.endorsements && d.endorsements.length) ? (
                      <Card size="small" className="sama-card" styles={{ body: { padding: 10 } }}>
                        <Typography.Text style={{ fontWeight: 800 }}>الحاقیه‌ها</Typography.Text>
                        <div style={{ marginTop: 8, display: 'flex', flexDirection: 'column', gap: 8 }}>
                          {(d.endorsements || []).map((e) => {
                            const amt = Number(e.premium_rial || 0)
                            const et = String(e.endorsement_type || '')
                            const isNeutral = amt === 0 || et.includes('بدون بار مالی') || et.includes('بدون')
                            const isDec = !isNeutral && (et.includes('کاهشی') || amt < 0)

                            const bg = isNeutral
                              ? 'rgba(148,163,184,0.14)'
                              : (isDec ? 'rgba(220,38,38,0.08)' : 'rgba(22,163,74,0.08)')
                            const border = isNeutral
                              ? 'rgba(148,163,184,0.28)'
                              : (isDec ? 'rgba(220,38,38,0.18)' : 'rgba(22,163,74,0.18)')
                            const amtText = amt === 0 ? '۰' : (amt < 0 ? `-${fmtRial(Math.abs(amt))}` : fmtRial(amt))

                            const isEditing = editEndorseId === e.id
                            return (
                              <div key={e.id} style={{ background: bg, border: `1px solid ${border}`, borderRadius: 10, padding: 10 }}>
                                {(!isEditing || isMarketer) ? (
                                  <Space wrap style={{ width: '100%', justifyContent: 'space-between' }}>
                                    <Space wrap>
                                      <Tag color={isNeutral ? 'default' : (isDec ? 'red' : 'green')} style={{ margin: 0 }}>
                                        {isNeutral ? 'بدون بار مالی' : (isDec ? 'کاهشی' : 'افزایشی')}
                                      </Tag>
                                      <Typography.Text>
                                        <b>شماره الحاقیه:</b> {e.endorsement_number}
                                      </Typography.Text>
                                      <Typography.Text>
                                        <b>نوع الحاقیه:</b> {e.endorsement_type}
                                      </Typography.Text>
                                      <Typography.Text>
                                        <b>توضیحات:</b> {e.notes || '—'}
                                      </Typography.Text>
                                      {/* نمایش خیلی خلاصه مبلغ فقط برای مشخص شدن کاهشی/افزایشی */}
                                      <Typography.Text type="secondary">مبلغ: {amtText} ریال</Typography.Text>
                                    </Space>
                                    {!isMarketer ? (
                                    <Space>
                                      <Button size="small" icon={<EditOutlined />} onClick={() => {
                                        setEditEndorseId(e.id)
                                        endorseEditForm.setFieldsValue({
                                          endorsement_type: e.endorsement_type,
                                          endorsement_number: e.endorsement_number,
                                          notes: e.notes || '',
                                        })
                                      }}>ویرایش</Button>
                                      <Button size="small" danger onClick={async () => {
                                        await http.delete(`/policies/${d.id}/endorsements/${e.id}`)
                                        message.success('الحاقیه حذف شد')
                                        const res = await http.get(`/policies/${d.id}`)
                                        setDetailsCache((m) => ({ ...m, [d.id]: { data: res.data, ts: Date.now() } }))
                                        qc.invalidateQueries({ queryKey: ['policies'] })
                                      }}>حذف</Button>
                                    </Space>
                                    ) : null}

                                  </Space>
                                ) : (
                                  <Form form={endorseEditForm} layout="vertical">
                                    <Space wrap style={{ width: '100%' }}>
                                      <Form.Item label="نوع الحاقیه" name="endorsement_type" rules={[{ required: true, message: 'الزامی' }]}>
                                        <Select style={{ width: 180 }} options={[
                                          { value: 'افزایشی', label: 'افزایشی' },
                                          { value: 'کاهشی', label: 'کاهشی' },
                                          { value: 'بدون بار مالی', label: 'بدون بار مالی' },
                                        ]} />
                                      </Form.Item>
                                      <Form.Item label="شماره الحاقیه" name="endorsement_number" rules={[{ required: true, message: 'الزامی' }]}>
                                        <Input style={{ width: 220 }} />
                                      </Form.Item>
                                      <Form.Item label="توضیحات" name="notes">
                                        <Input style={{ width: 320 }} />
                                      </Form.Item>
                                    </Space>
                                    <Space>
                                      <Button size="small" type="primary" icon={<SaveOutlined />} onClick={async () => {
                                        const v = await endorseEditForm.validateFields()
                                        await http.put(`/policies/${d.id}/endorsements/${e.id}`, v)
                                        message.success('الحاقیه ویرایش شد')
                                        setEditEndorseId(null)
                                        const res = await http.get(`/policies/${d.id}`)
                                        setDetailsCache((m) => ({ ...m, [d.id]: { data: res.data, ts: Date.now() } }))
                                        qc.invalidateQueries({ queryKey: ['policies'] })
                                      }}>ذخیره</Button>
                                      <Button size="small" icon={<CloseOutlined />} onClick={() => setEditEndorseId(null)}>انصراف</Button>
                                    </Space>
                                  </Form>
                                )}
                              </div>
                            )
                          })}
                        </div>

                        {/* نمایش حق بیمه نهایی با احتساب الحاقیه‌ها */}
                        <Divider style={{ margin: '10px 0' }} />
                        <Space wrap style={{ justifyContent: 'space-between', width: '100%' }}>
                          <Typography.Text type="secondary">حق بیمه نهایی با احتساب الحاقیه‌ها</Typography.Text>
                          <Typography.Text style={{ fontWeight: 800 }}>{fmtRial(d.total_premium_rial)} ریال</Typography.Text>
                        </Space>
                      </Card>
                    ) : null}

                    <Typography.Text style={{ fontWeight: 700 }}>اقلام حق بیمه</Typography.Text>

                    {discount > 0 ? (
                      <div className="sama-discount-banner">
                        <Typography.Text style={{ fontWeight: 700 }}>
                          تخفیف اعمال‌شده برای این بیمه‌نامه: {fmtRial(discount)} ریال
                        </Typography.Text>
                      </div>
                    ) : null}

                    {/* نمایش کنترل ۱ و ۲ */}
                    {(() => {
                      const items = (d.payments || []).filter((pi) => !pi.is_discount)
                      const sumSystem = items.filter((x) => x.is_system).reduce((a, b) => a + Number(b.amount_rial || 0), 0)
                      const sumSecondary = items.filter((x) => !x.is_system).reduce((a, b) => a + Number(b.amount_rial || 0), 0)
                      const total = Number(d.total_premium_rial || 0)
                      const ok1 = sumSystem === total
                      const ok2 = (sumSecondary + Number(discount || 0)) === total
                      return (
                        <Space wrap style={{ marginTop: 8 }}>
                          <Tag color={ok1 ? 'green' : 'red'}>
                            کنترل ۱: سیستمی‌ها = {fmtRial(sumSystem)}
                          </Tag>
                          <Tag color={ok2 ? 'green' : 'orange'}>
                            کنترل ۲: ثانویه‌ها({fmtRial(sumSecondary)}) + تخفیف({fmtRial(discount || 0)})
                          </Tag>
                          {!ok1 ? (
                            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                              جمع اقساط سیستمی باید دقیقاً با کل حق بیمه برابر باشد.
                            </Typography.Text>
                          ) : null}
                        </Space>
                      )
                    })()}

                    {/* نمایش تکراری/قدیمی الحاقیه‌ها حذف شد */}

                    <Table
                      size="small"
                      rowKey={(r) => r.payment_item_id}
                      columns={[
                        {
                          title: 'شناسه',
                          dataIndex: 'display_id',
                          key: 'display_id',
                          width: 240,
                          ellipsis: true,
                          render: (_, r) => (
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                              <Typography.Text style={{ fontWeight: 700 }}>{r.display_id || '—'}</Typography.Text>
                              {r.endorsement_label ? (
                                <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                                  {r.endorsement_label}
                                </Typography.Text>
                              ) : null}
                            </div>
                          ),
                        },
                        { title: 'سررسید', dataIndex: 'due_date_j', key: 'due_date_j', width: 120 },
                        { title: 'مبلغ', dataIndex: 'amount_rial', key: 'amount_rial', width: 150, render: (v) => fmtRial(v) },
                        { title: 'پرداخت', dataIndex: 'paid_amount_rial', key: 'paid_amount_rial', width: 150, render: (v) => fmtRial(v) },
                        { title: 'وضعیت', key: 'st', width: 110, render: (_, r) => <PaidTag paid={r.paid_amount_rial} total={r.amount_rial} /> },
                        { title: 'نوع', dataIndex: 'kind', key: 'kind', width: 120 },
                      ]}
                      dataSource={(() => {
                        const labelBySpid = {}
                        ;(d.endorsements || []).forEach((e) => {
                          if (!e.system_payment_id) return
                          const amt = Number(e.premium_rial || 0)
                          const et = String(e.endorsement_type || '')
                          const isNeutral = amt === 0 || et.includes('بدون بار مالی') || et.includes('بدون')
                          const isDec = !isNeutral && (et.includes('کاهشی') || amt < 0)
                          labelBySpid[e.system_payment_id] = isNeutral ? 'الحاقیه بدون بار مالی' : (isDec ? 'الحاقیه کاهشی' : 'الحاقیه افزایشی')
                        })
                        return (d.payments || [])
                          .filter((pi) => !pi.is_discount) // legacy
                          .map((pi) => ({
                            ...pi,
                            display_id: pi.system_payment_id || pi.secondary_debt_id || '',
                            endorsement_label: pi.system_payment_id ? labelBySpid[pi.system_payment_id] : null,
                            kind: pi.is_system ? 'سیستمی' : 'ثانویه',
                          }))
                      })()}
                      pagination={false}
                      tableLayout="auto"
          scroll={{ x: 1600 }}
                    />
                  </Space>
                </div>
              )
                  },
                }
          }
        />
      </Card>

      {/* Mobile details */}
      {isMobile ? <MobileRecordDrawer controller={mobileDrawer} /> : null}

      <Modal title="ثبت الحاقیه" open={endorseOpen} onCancel={() => setEndorseOpen(false)} width={620} destroyOnClose footer={null}>
        <Form form={endorseForm} layout="vertical">
          <Space wrap>
            <Form.Item label="نوع الحاقیه" name="endorsement_type" rules={[{required:true,message:"الزامی"}]}>
              <Select style={{ width: 220 }} options={[
                { value: 'افزایشی', label: 'افزایشی' },
                { value: 'کاهشی', label: 'کاهشی' },
                { value: 'بدون بار مالی', label: 'بدون بار مالی' },
              ]} />
            </Form.Item>
            <Form.Item label="شماره الحاقیه" name="endorsement_number" rules={[{required:true,message:"الزامی"}]}>
              <Input style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="تاریخ صدور" name="issue_date_j" rules={[{required:true,message:"الزامی"}]}>
              <JalaliDatePicker style={{ width: 220 }} />
            </Form.Item>
          </Space>
      
          <Space wrap>
            <Form.Item label="مبلغ (ریال)" name="premium_rial" rules={[{required:true,message:"الزامی"}]}>
              <Input style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="شناسه پرداخت (اختیاری)" name="system_payment_id">
              <Input style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="سررسید (در صورت شناسه)" name="due_date_j">
              <JalaliDatePicker style={{ width: 220 }} />
            </Form.Item>
          </Space>
      
          <Form.Item label="توضیحات" name="notes">
            <Input.TextArea rows={2} />
          </Form.Item>
      
          <Button type="primary" block onClick={saveEndorse}>ثبت نهایی</Button>
        </Form>
      </Modal>

      <Modal
        open={manualOpen}
        onCancel={() => { setManualOpen(false); manualForm.resetFields() }}
        title="ثبت دستی بیمه‌نامه"
        footer={null}
        destroyOnClose
      >
        <Form form={manualForm} layout="vertical" onFinish={async (vals) => {
          try {
            setManualLoading(true)
            const line = vals.insurance_line
            await http.post('/policies', {
              policy_number: vals.policy_number,
              insurance_line: line,
              policyholder_name: vals.policyholder_name,
              national_id: vals.national_id,
              mobile: vals.mobile,
              insured_item: vals.insured_item,
              start_date_j: vals.start_date_j,
              end_date_j: vals.end_date_j,
              issue_date_j: vals.issue_date_j,
              total_premium_rial: Number(String(vals.total_premium_rial).replaceAll(',', '')),
              marketer: vals.marketer || null,
              address: vals.address,
              birth_date_j: vals.birth_date_j || null,
              phone: vals.phone || null,
              job: vals.job || null,
              prev_policy_number: vals.prev_policy_number || null,
              late_penalty_rial: line === 'شخص ثالث' ? (vals.late_penalty_rial ? Number(String(vals.late_penalty_rial).replaceAll(',', '')) : 0) : null,
              notes: vals.notes || null,
              referrer: vals.referrer || null,
            })
            message.success('بیمه‌نامه ثبت شد')
            setManualOpen(false)
            manualForm.resetFields()
            refetch()
          } catch (e) {
            message.error(e?.response?.data?.detail || e.message || 'خطا')
          } finally {
            setManualLoading(false)
          }
        }}>
          <Space wrap style={{ width: '100%' }}>
            <Form.Item label="رشته" name="insurance_line" rules={[{ required: true, message: 'الزامی' }]}>
              <Select
                style={{ width: 220 }}
                options={(insuranceLines || []).map((l) => ({ value: l, label: l }))}
              />
            </Form.Item>
            <Form.Item label="شماره بیمه‌نامه" name="policy_number" rules={[{ required: true, message: 'الزامی' }]}>
              <Input style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="شماره بیمه‌نامه سال قبل" name="prev_policy_number">
              <Input style={{ width: 220 }} />
            </Form.Item>
          </Space>

          <Space wrap style={{ width: '100%' }}>
            <Form.Item label="نام بیمه‌گذار" name="policyholder_name" rules={[{ required: true, message: 'الزامی' }]}>
              <Input style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="کد ملی" name="national_id" rules={[{ required: true, message: 'الزامی' }]}>
              <Input style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="موبایل" name="mobile" rules={[{ required: true, message: 'الزامی' }]}>
              <Input style={{ width: 220 }} />
            </Form.Item>
          </Space>

          <Form.Item label="مورد بیمه" name="insured_item" rules={[{ required: true, message: 'الزامی' }]}>
            <Input />
          </Form.Item>

          <Space wrap style={{ width: '100%' }}>
            <Form.Item label="تاریخ صدور" name="issue_date_j" rules={[{ required: true, message: 'الزامی' }]}>
              <JalaliDatePicker style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="شروع" name="start_date_j" rules={[{ required: true, message: 'الزامی' }]}>
              <JalaliDatePicker style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="پایان" name="end_date_j" rules={[{ required: true, message: 'الزامی' }]}>
              <JalaliDatePicker style={{ width: 220 }} />
            </Form.Item>
          </Space>

          <Space wrap style={{ width: '100%' }}>
            <Form.Item label="کل حق بیمه (ریال)" name="total_premium_rial" rules={[{ required: true, message: 'الزامی' }]}>
              <Input style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="بازاریاب" name="marketer">
              <Select
              allowClear
              showSearch
              optionFilterProp="label"
              placeholder="انتخاب از لیست بازاریابان"
              style={{ width: 220 }}
              options={marketerOptions}
            />
            </Form.Item>
            <Form.Item label="تاریخ تولد" name="birth_date_j">
              <JalaliDatePicker style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="تلفن" name="phone">
              <Input style={{ width: 220 }} />
            </Form.Item>
          </Space>

          <Space wrap style={{ width: '100%' }}>
            <Form.Item label="شغل بیمه‌گذار" name="job">
              <Input style={{ width: 220 }} />
            </Form.Item>
            <Form.Item label="معرف" name="referrer">
              <Input style={{ width: 220 }} />
            </Form.Item>
            {manualLine === 'شخص ثالث' ? (
              <Form.Item label="جریمه دیرکرد" name="late_penalty_rial">
                <Input style={{ width: 220 }} />
              </Form.Item>
            ) : null}
          </Space>

          <Form.Item label="آدرس" name="address" rules={[{ required: true, message: 'الزامی' }]}>
            <Input.TextArea rows={2} />
          </Form.Item>
          <Form.Item label="توضیحات" name="notes">
            <Input.TextArea rows={2} />
          </Form.Item>

          <Button type="primary" htmlType="submit" block loading={manualLoading}>ثبت</Button>
        </Form>
      </Modal>

    </Space>
  )
}