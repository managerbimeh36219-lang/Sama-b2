import React, { useEffect, useMemo, useState } from "react";
import { Button, Card, Form, Input, Space, Switch, Table, Typography, message } from "antd";
import { PlusOutlined, ArrowUpOutlined, ArrowDownOutlined, SaveOutlined } from "@ant-design/icons";
import { http } from "../api/http";

export default function SettingsInsuranceLines() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form] = Form.useForm();

  async function load() {
    setLoading(true);
    try {
      // این endpoint قبلاً در پروژه‌ات هست (batch هم داری)
      const res = await http.get("/commissions/insurance-lines", { params: { include_inactive: true } });
      const data = Array.isArray(res.data) ? res.data : [];
      setRows(data.sort((a,b)=> (a.sort_order||0)-(b.sort_order||0)));
    } catch (e) {
      message.error(e?.response?.data?.detail || "خطا در دریافت رشته‌ها");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { load(); }, []);

  const move = (idx, dir) => {
    const next = [...rows];
    const j = idx + dir;
    if (j < 0 || j >= next.length) return;
    const a = next[idx], b = next[j];
    // swap sort_order
    const tmp = a.sort_order;
    a.sort_order = b.sort_order;
    b.sort_order = tmp;
    next[idx] = b; next[j] = a;
    setRows(next.sort((x,y)=> (x.sort_order||0)-(y.sort_order||0)));
  };

  async function saveAll() {
    setSaving(true);
    try {
      // نرمال‌سازی sort_order
      const normalized = rows
        .sort((a,b)=> (a.sort_order||0)-(b.sort_order||0))
        .map((r, i) => ({ ...r, sort_order: (i+1)*10 }));

      // بک‌اند انتظار دارد: { lines: [...] }
      const payload = {
        lines: normalized.map((r) => ({
          id: typeof r.id === 'number' ? r.id : undefined,
          title: r.title,
          is_active: !!r.is_active,
          sort_order: r.sort_order,
        })),
      };

      await http.post("/commissions/insurance-lines/batch", payload);
      message.success("ذخیره شد");
      setRows(normalized);
    } catch (e) {
      message.error(e?.response?.data?.detail || "خطا در ذخیره");
    } finally {
      setSaving(false);
    }
  }

  async function addNew(values) {
    const next = [...rows];
    const maxSort = Math.max(0, ...next.map(r => r.sort_order || 0));
    next.push({
      // id ندارد تا بک‌اند رکورد جدید بسازد
      id: undefined,
      title: values.title,
      is_active: true,
      sort_order: maxSort + 10,
    });
    setRows(next);
    form.resetFields();
  }

  const columns = useMemo(() => [
    { title: "عنوان", dataIndex: "title", ellipsis: true },
    {
      title: "فعال",
      dataIndex: "is_active",
      width: 90,
      render: (v, r) => (
        <Switch
          checked={!!v}
          onChange={(checked) => {
            setRows(prev => prev.map(x => x === r ? ({...x, is_active: checked}) : x));
          }}
        />
      )
    },
    {
      title: "ترتیب",
      dataIndex: "sort_order",
      width: 140,
      render: (_v, _r, idx) => (
        <Space>
          <Button size="small" icon={<ArrowUpOutlined />} onClick={() => move(idx, -1)} />
          <Button size="small" icon={<ArrowDownOutlined />} onClick={() => move(idx, +1)} />
        </Space>
      )
    }
  ], [rows]);

  return (
    <Space direction="vertical" size={12} style={{ width: "100%" }}>
      <Card className="sama-card" styles={{ body: { padding: 12 } }}>
        <Space style={{ width: "100%", justifyContent: "space-between" }} align="start">
          <div>
            <Typography.Title level={5} style={{ margin: 0, fontWeight: 900 }}>
              تعریف رشته‌های بیمه
            </Typography.Title>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              این لیست منبع اصلی رشته‌ها برای چک‌لیست و سایر بخش‌هاست.
            </Typography.Text>
          </div>
          <Button type="primary" icon={<SaveOutlined />} loading={saving} onClick={saveAll}>
            ذخیره نهایی
          </Button>
        </Space>

        <Form form={form} layout="inline" onFinish={addNew} style={{ marginTop: 12 }}>
          <Form.Item name="title" rules={[{ required: true, message: "عنوان لازم است" }]}>
            <Input placeholder="عنوان مثل شخص ثالث" />
          </Form.Item>
          <Button htmlType="submit" icon={<PlusOutlined />}>افزودن</Button>
        </Form>

        <Table
          style={{ marginTop: 12 }}
          size="small"
          rowKey={(r, idx) => (r.id != null ? r.id : `new_${idx}_${r.title || ''}`)}
          loading={loading}
          dataSource={rows}
          columns={columns}
          pagination={false}
        />
      </Card>
    </Space>
  );
}
