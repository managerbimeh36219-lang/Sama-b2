import React from 'react'
import { Card, Typography } from 'antd'

export default function Guide(){
  return (
    <Card title="راهنمای کلی سامانه">
      <Typography.Paragraph>
        این صفحه برای راهنمای سریع استفاده از سامانه اضافه شده است.
        (فاز B) — ترتیب سایدبار، تنظیمات تم/رنگ، و حالت تست موبایل/تبلت/دسکتاپ در هدر اضافه شده است.
      </Typography.Paragraph>
      <ul>
        <li>ورود: با OTP یا رمز</li>
        <li>سایدبار: ترتیب جدید مطابق فایل Word</li>
        <li>تنظیمات: تم/رنگ و بکگراند لاگین</li>
        <li>حفظ فیلترها: با sessionStorage (تا بسته شدن مرورگر)</li>
      </ul>
    </Card>
  )
}
