import React, { useEffect, useMemo, useState } from 'react'
import { Button, Card, Form, Input, Space, Table, Tag, message, Switch, Popconfirm, Modal } from 'antd'
import FormDrawer from '../components/FormDrawer'
import { listMarketers, createMarketer, updateMarketer, deleteMarketer, setMarketerPassword } from '../api/marketers2'

export default function MarketersPage() {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form] = Form.useForm()

  const [pwdOpen, setPwdOpen] = useState(false)
  const [pwdValue, setPwdValue] = useState('')
  const [pwdRow, setPwdRow] = useState(null)

  async function refresh() {
    setLoading(true)
    try {
      const data = await listMarketers()
      setRows(data)
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در دریافت بازاریابان')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { refresh() }, [])

  const columns = useMemo(() => [
    { title: 'کد', dataIndex: 'code' },
    { title: 'نام', dataIndex: 'full_name' },
    { title: 'موبایل', dataIndex: 'mobile' },
    { title: 'بانک', dataIndex: 'bank_name' },
    { title: 'کارت', dataIndex: 'card_number' },
    { title: 'شبا', dataIndex: 'sheba' },
    {
      title: 'وضعیت',
      dataIndex: 'is_active',
      render: (v) => (v ? <Tag color="green">فعال</Tag> : <Tag color="red">غیرفعال</Tag>),
    },
    {
      title: 'عملیات',
      render: (_, r) => (
        <Space>
          <Button size="small" onClick={() => {
            setEditing(r)
            form.setFieldsValue({
              code: r.code,
              full_name: r.full_name,
              mobile: r.mobile,
              bank_name: r.bank_name,
              card_number: r.card_number,
              sheba: r.sheba,
              is_active: r.is_active,
            })
            setOpen(true)
          }}>ویرایش</Button>

          <Button size="small" onClick={() => { setPwdRow(r); setPwdValue(''); setPwdOpen(true) }}>
            تنظیم رمز
          </Button>
          <Popconfirm
            title="حذف بازاریاب"
            description="بازاریاب غیرفعال یا حذف می‌شود، اما نباید کاربر مرتبط را از دسترس خارج کند."
            okText="حذف"
            cancelText="انصراف"
            onConfirm={async () => {
              try {
                await deleteMarketer(r.id)
                message.success('حذف شد')
                refresh()
              } catch (e) {
                message.error(e?.response?.data?.detail || 'خطا در حذف')
              }
            }}
          >
            <Button danger size="small">حذف</Button>
          </Popconfirm>
        </Space>
      ),
    },
  ], [form])

  async function onSubmit(values) {
    try {
      if (editing) {
        await updateMarketer(editing.id, values)
        message.success('ویرایش شد')
      } else {
        await createMarketer(values)
        message.success('ایجاد شد')
      }
      setOpen(false)
      setEditing(null)
      form.resetFields()
      refresh()
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا')
    }
  }

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card>
        <Space>
          <Button type="primary" onClick={() => { setEditing(null); form.resetFields(); form.setFieldsValue({ is_active: true }); setOpen(true) }}>افزودن بازاریاب</Button>
          <Button onClick={refresh} loading={loading}>به‌روزرسانی</Button>
        </Space>
      </Card>

      <Card>
        <Table rowKey="id" loading={loading} dataSource={rows} columns={columns} pagination={{ pageSize: 20 }} scroll={{ x: 1000 }} />
      </Card>
      <FormDrawer
        title={editing ? 'ویرایش بازاریاب' : 'افزودن بازاریاب'}
        open={open}
        onClose={() => { setOpen(false); setEditing(null) }}
        onSubmit={() => form.submit()}
      >
        <Form form={form} layout="vertical" onFinish={onSubmit}>
          <Form.Item name="code" label="کد" rules={[{ required: true, message: 'کد الزامی است' }]}>
            <Input />
          </Form.Item>
          <Form.Item name="full_name" label="نام" rules={[{ required: true, message: 'نام الزامی است' }]}>
            <Input />
          </Form.Item>
          <Form.Item name="mobile" label="موبایل" rules={[{ required: true, message: 'موبایل الزامی است' }]}>
            <Input />
          </Form.Item>

          <Form.Item name="bank_name" label="نام بانک">
            <Input placeholder="مثلاً: ملی" />
          </Form.Item>
          <Form.Item name="card_number" label="شماره کارت">
            <Input placeholder="16 رقم" />
          </Form.Item>
          <Form.Item name="sheba" label="شماره شبا">
            <Input placeholder="IR..." />
          </Form.Item>

          <Form.Item name="is_active" label="وضعیت" valuePropName="checked" initialValue={true}>
            <Switch checkedChildren="فعال" unCheckedChildren="غیرفعال" />
          </Form.Item>
        </Form>
      </FormDrawer>

      <Modal
        title={`تنظیم رمز برای: ${pwdRow?.full_name || ''}`}
        open={pwdOpen}
        onCancel={() => setPwdOpen(false)}
        okText="ثبت"
        onOk={async () => {
          try {
            await setMarketerPassword(pwdRow.id, pwdValue)
            message.success('رمز ثبت شد')
            setPwdOpen(false)
          } catch (e) {
            message.error(e?.response?.data?.detail || 'خطا در ثبت رمز')
          }
        }}
      >
        <Input.Password value={pwdValue} onChange={(e) => setPwdValue(e.target.value)} placeholder="رمز جدید" />
      </Modal>
    </Space>
  )
}
