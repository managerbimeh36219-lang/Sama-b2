import React, { useEffect, useMemo, useState } from 'react'
import { Button, Card, Input, Select, Space, Table, Typography, message } from 'antd'
import { listAuditEvents } from '../api/audit'
import { listUsers } from '../api/users'

export default function AuditLogs() {
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [q, setQ] = useState('')
  const [module, setModule] = useState(null)
  const [action, setAction] = useState(null)
  const [userId, setUserId] = useState(null)
  const [users, setUsers] = useState([])

  async function refresh() {
    setLoading(true)
    try {
      const data = await listAuditEvents({ limit: 300, q: q || undefined, module: module || undefined, action: action || undefined, user_id: userId || undefined })
      setRows(data || [])
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در دریافت لاگ')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    ;(async () => {
      try {
        const u = await listUsers()
        setUsers(u || [])
      } catch {
        setUsers([])
      }
    })()
    refresh()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const userOptions = useMemo(
    () => (users || []).map((u) => ({ value: u.id, label: `${u.full_name || ''} (${u.mobile})` })),
    [users]
  )

  const columns = [
    { title: 'ID', dataIndex: 'id', width: 90 },
    { title: 'زمان', dataIndex: 'created_at_j', width: 190, render: (v,r)=> v || r.created_at },
    { title: 'ماژول', dataIndex: 'module_fa', width: 170, render: (v,r)=> v || r.module },
    { title: 'عملیات', dataIndex: 'action_fa', width: 140, render: (v,r)=> v || r.action },
    { title: 'نوع', dataIndex: 'entity_type', width: 140 },
    { title: 'شناسه', dataIndex: 'entity_id', width: 100 },
    { title: 'کاربر', dataIndex: 'user_name', width: 160, render: (v,r)=> v || r.user_id },
    {
      title: 'یادداشت',
      dataIndex: 'note',
      render: (v) => <Typography.Text ellipsis={{ tooltip: v }}>{v}</Typography.Text>,
    },
  ]

  const changeColumns = [
    { title: 'فیلد', dataIndex: 'field_fa', width: 180, render: (v, r) => v || r.field },
    { title: 'قبل', dataIndex: 'old', width: 240, render: (v) => <Typography.Text>{v === null || v === undefined || v === '' ? '-' : String(v)}</Typography.Text> },
    { title: 'بعد', dataIndex: 'new', width: 240, render: (v) => <Typography.Text>{v === null || v === undefined || v === '' ? '-' : String(v)}</Typography.Text> },
  ]

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card className="sama-card" styles={{ body: { padding: 12 } }}>
        <Space style={{ width: '100%', justifyContent: 'space-between' }} wrap>
          <div>
            <Typography.Title level={5} style={{ margin: 0, fontWeight: 800 }}>
              لاگ فعالیت
            </Typography.Title>
            <Typography.Text type="secondary">ثبت همه تغییرات مهم (حتی حذف‌ها) برای پیگیری مدیر.</Typography.Text>
          </div>
          <Button onClick={refresh} loading={loading}>
            بروزرسانی
          </Button>
        </Space>

        <Space wrap style={{ marginTop: 12 }}>
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جستجو..." style={{ width: 240 }} />
          <Select allowClear placeholder="ماژول" value={module} onChange={setModule} style={{ width: 160 }} options={[
            { value: 'policies', label: 'بیمه‌نامه' },
            { value: 'endorsements', label: 'الحاقیه' },
            { value: 'payment_items_system', label: 'اقساط سیستمی' },
            { value: 'payment_items_secondary', label: 'اقساط ثانویه' },
            { value: 'rbac', label: 'سطوح دسترسی' },
          ]} />
          <Select allowClear placeholder="اکشن" value={action} onChange={setAction} style={{ width: 140 }} options={[
            { value: 'create', label: 'ایجاد' },
            { value: 'update', label: 'ویرایش' },
            { value: 'delete', label: 'حذف' },
          ]} />
          <Select allowClear placeholder="کاربر" value={userId} onChange={setUserId} style={{ width: 260 }} options={userOptions} />
          <Button type="primary" onClick={refresh} loading={loading}>
            اعمال فیلتر
          </Button>
        </Space>
      </Card>

      <Card className="sama-card" styles={{ body: { padding: 0 } }}>
        <Table
          rowKey="id"
          columns={columns}
          dataSource={rows}
          loading={loading}
          pagination={{ pageSize: 50 }}
          expandable={{
            expandedRowRender: (r) => (
              <div style={{ padding: 12 }}>
                {!!(r.changes && r.changes.length) ? (
                  <>
                    <Typography.Text strong>تغییرات:</Typography.Text>
                    <div style={{ marginTop: 8 }}>
                      <Table
                        rowKey={(x, i) => `${r.id}-${x.field}-${i}`}
                        size="small"
                        columns={changeColumns}
                        dataSource={r.changes}
                        pagination={false}
                      />
                    </div>
                  </>
                ) : (
                  <>
                    <Typography.Text type="secondary">برای این رویداد، تغییرات ساختاری پیدا نشد. (نمایش خام)</Typography.Text>
                    <Typography.Text strong style={{ display: 'block', marginTop: 8 }}>Old:</Typography.Text>
                    <pre style={{ marginTop: 6, whiteSpace: 'pre-wrap' }}>{r.old_data || '-'}</pre>
                    <Typography.Text strong style={{ display: 'block' }}>New:</Typography.Text>
                    <pre style={{ marginTop: 6, whiteSpace: 'pre-wrap' }}>{r.new_data || '-'}</pre>
                  </>
                )}
              </div>
            ),
          }}
        />
      </Card>
    </Space>
  )
}
