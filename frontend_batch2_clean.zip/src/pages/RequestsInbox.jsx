import React, { useEffect, useMemo, useState } from 'react'
import dayjs from 'dayjs'
import { Alert, Badge, Button, Card, Drawer, Form, Input, Select, Space, Table, Tag, Typography, Upload, message } from 'antd'
import { useTableView } from '../hooks/useTableView'
import TableViewBar from '../components/TableViewBar'
import { PaperClipOutlined } from '@ant-design/icons'
import { listRequests, getRequest, createRequest, addRequestMessage, uploadRequestFile, getRequestFileUrl } from '../api/requests2'
import { listMarketers } from '../api/marketers2'
import { errorToText } from '../utils/errorText'
import AuthenticatedImage from '../components/AuthenticatedImage.jsx'
import FilePreviewModal from '../components/FilePreviewModal.jsx'
import { fetchBlob, downloadBlob } from '../utils/fileAccess'

function StatusTag({ status }) {
  const map = {
    open: { color: 'blue', label: 'باز' },
    waiting_user: { color: 'orange', label: 'در انتظار کاربر' },
    waiting_marketer: { color: 'purple', label: 'در انتظار بازاریاب' },
    closed: { color: 'green', label: 'مختومه' },
  }
  const s = map[status] || { color: 'default', label: status }
  return <Tag color={s.color}>{s.label}</Tag>
}

function typeFa(t) {
  const map = { quote: 'استعلام', issue: 'صدور', other: 'سایر' }
  return map[t] || t || ''
}

function fmtJalali(dt) {
  if (!dt) return ''
  try {
    return dayjs(dt).calendar('jalali').locale('fa').format('YYYY/MM/DD HH:mm')
  } catch {
    return String(dt)
  }
}

export default function RequestsInbox() {
  const me = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem('sama_user') || 'null')
    } catch {
      return null
    }
  }, [])
  const isMarketer = me?.user_type === 'marketer'
  const [rows, setRows] = useState([])
  const tableView = useTableView('table.requests.v1', { pageSize: 20, dense: false })
  const [loading, setLoading] = useState(false)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [active, setActive] = useState(null)
  const [preview, setPreview] = useState({ open: false, url: '', title: '', mime: '' })
  const [marketers, setMarketers] = useState([])
  const [createOpen, setCreateOpen] = useState(false)
  const [createForm] = Form.useForm()
  const [msgForm] = Form.useForm()
  const [fileList, setFileList] = useState([])

  async function refresh() {
    setLoading(true)
    try {
      const data = await listRequests()
      setRows(data)
    } catch (e) {
      message.error(errorToText(e, 'خطا در دریافت کارتابل'))
    } finally {
      setLoading(false)
    }
  }

  async function refreshMarketers() {
    try {
      const data = await listMarketers()
      setMarketers(data)
    } catch {
      // ignore
    }
  }

  useEffect(() => {
    refresh()
    refreshMarketers()
  }, [])

  const columns = useMemo(() => [
    { title: 'ID', dataIndex: 'id', width: 90 },
    { title: 'بازاریاب', dataIndex: 'marketer_name', width: 200, ellipsis: true, render: (v) => v || '—' },
    { title: 'عنوان', dataIndex: 'title' },
    { title: 'نوع', dataIndex: 'request_type', width: 120, render: (v) => typeFa(v) },
    {
      title: 'وضعیت',
      dataIndex: 'status',
      width: 160,
      render: (v) => <StatusTag status={v} />,
    },
  ], [])

  async function onCreate(values) {
    try {
      const payload = { ...values }
      // برای بازاریاب، marketer_id در بک‌اند از توکن تعیین می‌شود.
      if (isMarketer) {
        delete payload.marketer_id
      }
      const res = await createRequest(payload)
      message.success('درخواست ثبت شد')
      setCreateOpen(false)
      createForm.resetFields()
      await refresh()
      const full = await getRequest(res.id)
      setActive(full)
      setDrawerOpen(true)
    } catch (e) {
      message.error(errorToText(e, 'خطا'))
    }
  }

  async function onSendMessage(values) {
    if (!active) return
    try {
      const msg = await addRequestMessage(active.id, values)
      // اگر فایل انتخاب شده باشد، بعد از ساخت پیام آپلود کنیم
      if (fileList.length) {
        for (const f of fileList) {
          const raw = f?.originFileObj || f
          if (raw) {
            await uploadRequestFile(active.id, msg.id, raw)
          }
        }
      }
      msgForm.resetFields()
      setFileList([])
      const full = await getRequest(active.id)
      setActive(full)
      refresh()
    } catch (e) {
      message.error(errorToText(e, 'خطا'))
    }
  }

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card
        extra={<TableViewBar view={tableView.view} onChange={tableView.save} />}
      >
        <Space>
          <Button type="primary" onClick={() => setCreateOpen(true)}>درخواست جدید</Button>
          <Button onClick={refresh} loading={loading}>به‌روزرسانی</Button>
        </Space>
      </Card>

      <Card>
        <Table
          rowKey="id"
          dataSource={rows}
          columns={columns}
          loading={loading}
          pagination={{ pageSize: tableView.view.pageSize }}
          rowClassName={(r) => (r.unread ? 'sama-row-unread' : '')}
          onRow={(r) => ({
            onDoubleClick: async () => {
              try {
                const full = await getRequest(r.id)
                setActive(full)
                setDrawerOpen(true)
                refresh() // refresh unread state
              } catch (e) {
                message.error(errorToText(e, 'خطا'))
              }
            },
          })}
        />
      </Card>

      <Drawer
        title="ثبت درخواست جدید"
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        width={560}
      >
        <Form form={createForm} layout="vertical" onFinish={onCreate}>
          <Form.Item name="title" label="عنوان" rules={[{ required: true }]}>
            <Input placeholder="مثلاً استعلام بیمه بدنه" />
          </Form.Item>
          {!isMarketer ? (
            <Form.Item name="marketer_id" label="بازاریاب" rules={[{ required: true }]}>
              <Select
                showSearch
                optionFilterProp="label"
                options={marketers.map(m => ({ value: m.id, label: `${m.code} — ${m.full_name}` }))}
              />
            </Form.Item>
          ) : (
            <Alert type="info" showIcon message="این درخواست برای خودِ بازاریاب ثبت می‌شود." />
          )}
          <Form.Item name="request_type" label="نوع" initialValue="quote">
            <Select options={[
              { value: 'quote', label: 'استعلام' },
              { value: 'issue', label: 'صدور' },
              { value: 'other', label: 'سایر' },
            ]} />
          </Form.Item>
          <Form.Item name="body" label="شرح اولیه">
            <Input.TextArea rows={4} />
          </Form.Item>
          <Space>
            <Button type="primary" htmlType="submit">ثبت</Button>
            <Button onClick={() => setCreateOpen(false)}>انصراف</Button>
          </Space>
        </Form>
      </Drawer>

      <Drawer
        title={active ? `کارتابل #${active.id} — ${active.title}` : 'کارتابل'}
        open={drawerOpen}
        onClose={() => { setDrawerOpen(false); setActive(null) }}
        width={720}
      >
        {!active ? null : (
          <Space direction="vertical" size={12} style={{ width: '100%' }}>
            <Space>
              <Typography.Text>وضعیت:</Typography.Text>
              <StatusTag status={active.status} />
              <Typography.Text type="secondary">نوع: {typeFa(active.request_type)}</Typography.Text>
              {active.unread ? <Badge status="warning" text="خوانده‌نشده" /> : <Badge status="success" text="خوانده‌شده" />}
            </Space>

            <Card size="small" title="ارسال پیام">
              <Form form={msgForm} layout="vertical" onFinish={onSendMessage}>
                <Form.Item name="body" label="متن" rules={[{ required: true }]}>
                  <Input.TextArea rows={3} />
                </Form.Item>
                <Form.Item label="ضمیمه (اختیاری)">
                  <Upload
                    multiple
                    fileList={fileList}
                    beforeUpload={() => false}
                    onChange={({ fileList: fl }) => setFileList(fl)}
                  >
                    <Button icon={<PaperClipOutlined />}>انتخاب فایل</Button>
                  </Upload>
                </Form.Item>
                <Button type="primary" htmlType="submit">ارسال</Button>
              </Form>
            </Card>

            <Card size="small" title="گفتگو" styles={{ body: { maxHeight: 420, overflow: 'auto' } }}>
              <Space direction="vertical" style={{ width: '100%' }} size={10}>
                {(active.messages || []).map((m) => (
                  <div key={m.id} style={{ padding: 10, border: '1px solid rgba(0,0,0,0.06)', borderRadius: 12 }}>
                    <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                      {m.sender_name ? `${m.sender_name} — ` : ''}#{m.id} — {fmtJalali(m.created_at)}
                    </Typography.Text>
                    <div style={{ marginTop: 6 }}>{m.body || <Typography.Text type="secondary">(بدون متن)</Typography.Text>}</div>
                    {!!(m.files && m.files.length) && (
                      <div style={{ marginTop: 8 }}>
                        <Typography.Text type="secondary" style={{ fontSize: 12 }}>فایل‌ها:</Typography.Text>
                        <div style={{ marginTop: 6, display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                          {m.files.map((f) => {
                            const apiUrl = getRequestFileUrl(f.id) // مثل: /requests/files/3
                            const isImg = (f.mime_type || '').startsWith('image/')
                            const filename = f.original_filename || 'file'
                            const download = async () => {
                              const blob = await fetchBlob(apiUrl)
                              downloadBlob(blob, filename)
                            }

                            return isImg ? (
                              <div key={f.id} style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'center' }}>
                                <AuthenticatedImage url={apiUrl} width={84} height={84} />
                                <Button size="small" onClick={() => setPreview({ open: true, url: apiUrl, title: filename, mime: f.mime_type || '' })}>
                                  مشاهده
                                </Button>
                                <Button
                                  size="small"
                                  onClick={async () => {
                                    try {
                                      await download()
                                    } catch (e) {
                                      message.error(errorToText(e, 'خطا در دانلود'))
                                    }
                                  }}
                                >
                                  دانلود
                                </Button>
                              </div>
                            ) : (
                              <Space key={f.id}>
                                <Button size="small" onClick={() => setPreview({ open: true, url: apiUrl, title: filename, mime: f.mime_type || '' })}>
                                  مشاهده
                                </Button>
                                <Button
                                  size="small"
                                  onClick={async () => {
                                    try {
                                      await download()
                                    } catch (e) {
                                      message.error(errorToText(e, 'خطا در دانلود'))
                                    }
                                  }}
                                >
                                  دانلود
                                </Button>
                                <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                                  {filename}
                                </Typography.Text>
                              </Space>
                            )
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </Space>
            </Card>
          </Space>
        )}
      </Drawer>

      <FilePreviewModal
        open={preview.open}
        url={preview.url}
        title={preview.title}
        mimeType={preview.mime}
        onClose={() => setPreview({ open: false, url: '', title: '', mime: '' })}
        onDownload={async () => {
          try {
            const blob = await fetchBlob(preview.url)
            downloadBlob(blob, preview.title || 'file')
          } catch (e) {
            message.error(errorToText(e, 'خطا در دانلود'))
          }
        }}
      />
    </Space>
  )
}
