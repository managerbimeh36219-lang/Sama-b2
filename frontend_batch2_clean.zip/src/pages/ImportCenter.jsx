import React, { useEffect, useMemo } from 'react'
import { Alert, Button, Card, Space, Table, Typography, Upload, message, Divider, Tag } from 'antd'
import { UploadOutlined, DownloadOutlined } from '@ant-design/icons'
import { http } from '../api/http.js'
import { useSessionState } from '../utils/useSessionState.js'
import { loadSettings } from '../utils/appSettings.js'

function fmtRial(n) {
  try {
    return new Intl.NumberFormat('fa-IR').format(n ?? 0)
  } catch {
    return String(n ?? '')
  }
}

function marketerNamesFromSettings(st) {
  const raw = st?.marketers || []
  return raw.map((m) => {
    if (typeof m === 'string') return m.trim()
    if (m?.name) return String(m.name).trim()
    if (m?.full_name) return String(m.full_name).trim()
    if (m?.title) return String(m.title).trim()
    return ''
  }).filter(Boolean)
}

export default function ImportCenter() {
  const [state, setState] = useSessionState('import:antd:v4', {
    preview: null,
    history: [],
    previewLoading: false,
    commitLoading: false,
    undoLoadingId: null,
  })

  const preview = state.preview
  const errors = preview?.errors || []
  const warnings = preview?.warnings || []

  async function loadHistory() {
    try {
      const res = await http.get('/imports/history')
      setState((s) => ({ ...s, history: Array.isArray(res.data) ? res.data : [] }))
    } catch {
      // ignore
    }
  }

  useEffect(() => {
    loadHistory()
  }, [])

  async function onPreview(file) {
    const form = new FormData()
    form.append('file', file)
    const st = loadSettings()
    form.append('allowed_lines', (st.insuranceLines || []).join(','))
    form.append('allowed_marketers', marketerNamesFromSettings(st).join(','))
    setState((s) => ({ ...s, previewLoading: true, preview: null }))

    try {
      const res = await http.post('/imports/preview', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      setState((s) => ({ ...s, preview: res.data }))
      if ((res.data?.errors || []).length > 0) {
        message.warning('پیش‌نمایش آماده شد، اما فایل خطا دارد')
      } else {
        message.success('پیش‌نمایش آماده شد')
      }
    } catch (e) {
      const detail = e?.response?.data?.detail
      const msg = typeof detail === 'string' ? detail : (detail?.message || e?.message || 'خطا')
      setState((s) => ({ ...s, preview: null }))
      message.error(msg)
    } finally {
      setState((s) => ({ ...s, previewLoading: false }))
    }
    return false
  }

  async function onCommit() {
    if (!preview?.preview_token) return
    setState((s) => ({ ...s, commitLoading: true }))
    try {
      await http.post('/imports/commit', null, {
        params: { preview_token: preview.preview_token },
      })
      message.success('ایمپورت انجام شد')
      setState((s) => ({ ...s, preview: null }))
      await loadHistory()
    } catch (e) {
      const detail = e?.response?.data?.detail
      const msg = typeof detail === 'string' ? detail : (detail?.message || e?.message || 'خطا')
      message.error(msg)
    } finally {
      setState((s) => ({ ...s, commitLoading: false }))
    }
  }

  async function onUndo(batchId) {
    setState((s) => ({ ...s, undoLoadingId: batchId, preview: null }))
    try {
      await http.post(`/imports/${batchId}/undo`, null, { params: { note: 'undo توسط کاربر' } })
      message.success('برگشت ایمپورت انجام شد')
      await loadHistory()
    } catch (e) {
      const detail = e?.response?.data?.detail
      const msg = typeof detail === 'string' ? detail : (detail?.message || e?.message || 'خطا')
      message.error(msg)
    } finally {
      setState((s) => ({ ...s, undoLoadingId: null }))
    }
  }

  async function onDownloadSample() {
    try {
      const res = await http.get('/imports/sample-file', { responseType: 'blob' })
      const blob = new Blob([res.data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' })
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'sama_import_sample.xlsx'
      document.body.appendChild(a)
      a.click()
      a.remove()
      window.URL.revokeObjectURL(url)
    } catch {
      message.error('دانلود فایل نمونه انجام نشد')
    }
  }

  const rows = useMemo(() => {
    const policies = preview?.policies || []
    const out = []
    for (const p of policies) {
      const pol = p.policy || {}
      out.push({
        key: `p-${p.excel_row_start}`,
        kind: 'بیمه‌نامه',
        row_index: p.excel_row_start,
        policy_number: pol.policy_number || '',
        insurance_line: pol.insurance_line || '',
        policyholder_name: pol.policyholder_name || '',
        marketer: pol.marketer || '',
        national_id: pol.national_id || '',
        mobile: pol.mobile || '',
        insured_item: pol.insured_item || '',
        start_date_j: pol.start_date_j || '',
        end_date_j: pol.end_date_j || '',
        total_premium_rial: pol.total_premium_rial || 0,
        address: pol.address || '',
        issue_date_j: pol.issue_date_j || '',
        due_date_j: '',
        amount_rial: '',
        payment_id: '',
      })
      for (const [idx, it] of (pol.payment_items || []).entries()) {
        out.push({
          key: `i-${p.excel_row_start}-${idx}`,
          kind: 'قسط سیستمی',
          row_index: p.excel_row_start,
          policy_number: pol.policy_number || '',
          insurance_line: pol.insurance_line || '',
          policyholder_name: pol.policyholder_name || '',
          marketer: pol.marketer || '',
          national_id: pol.national_id || '',
          mobile: pol.mobile || '',
          insured_item: pol.insured_item || '',
          start_date_j: pol.start_date_j || '',
          end_date_j: pol.end_date_j || '',
          total_premium_rial: pol.total_premium_rial || 0,
          address: pol.address || '',
          issue_date_j: pol.issue_date_j || '',
          due_date_j: it.due_date_j || '',
          amount_rial: it.amount_rial || 0,
          payment_id: it.system_payment_id || '',
        })
      }
    }
    return out
  }, [preview])

  const columns = [
    { title: 'نوع', dataIndex: 'kind', key: 'kind', width: 110, fixed: 'right' },
    { title: 'ردیف', dataIndex: 'row_index', key: 'row_index', width: 80 },
    { title: 'شماره بیمه‌نامه', dataIndex: 'policy_number', key: 'policy_number', width: 180 },
    { title: 'رشته', dataIndex: 'insurance_line', key: 'insurance_line', width: 140 },
    { title: 'بیمه‌گذار', dataIndex: 'policyholder_name', key: 'policyholder_name', width: 170 },
    { title: 'بازاریاب', dataIndex: 'marketer', key: 'marketer', width: 150 },
    { title: 'کدملی', dataIndex: 'national_id', key: 'national_id', width: 130 },
    { title: 'موبایل', dataIndex: 'mobile', key: 'mobile', width: 130 },
    { title: 'مورد بیمه', dataIndex: 'insured_item', key: 'insured_item', width: 160 },
    { title: 'تاریخ شروع', dataIndex: 'start_date_j', key: 'start_date_j', width: 110 },
    { title: 'تاریخ انقضاء', dataIndex: 'end_date_j', key: 'end_date_j', width: 110 },
    { title: 'کل حق بیمه', dataIndex: 'total_premium_rial', key: 'total_premium_rial', width: 140, align: 'left', render: fmtRial },
    { title: 'آدرس', dataIndex: 'address', key: 'address', width: 220 },
    { title: 'تاریخ صدور', dataIndex: 'issue_date_j', key: 'issue_date_j', width: 110 },
    { title: 'تاریخ سررسید', dataIndex: 'due_date_j', key: 'due_date_j', width: 110 },
    { title: 'مبلغ', dataIndex: 'amount_rial', key: 'amount_rial', width: 130, align: 'left', render: fmtRial },
    { title: 'شناسه پرداخت', dataIndex: 'payment_id', key: 'payment_id', width: 170 },
  ]

  const historyColumns = [
    { title: 'شناسه', dataIndex: 'id', key: 'id', width: 90 },
    { title: 'فایل', dataIndex: 'source_filename', key: 'source_filename', width: 220 },
    { title: 'زمان', dataIndex: 'created_at', key: 'created_at', width: 180 },
    { title: 'بیمه‌نامه', dataIndex: 'created_policies', key: 'created_policies', width: 110 },
    { title: 'اقساط', dataIndex: 'created_payment_items', key: 'created_payment_items', width: 110 },
    {
      title: 'وضعیت', key: 'status', width: 120,
      render: (_, r) => r.undone_at ? <Tag color="default">undo شده</Tag> : <Tag color="green">فعال</Tag>,
    },
    {
      title: 'عملیات', key: 'actions', width: 140,
      render: (_, r) => (
        <Button danger size="small" disabled={!r.can_undo} loading={state.undoLoadingId === r.id} onClick={() => onUndo(r.id)}>
          Undo
        </Button>
      ),
    },
  ]

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card className="sama-card" styles={{ body: { padding: 16 } }}>
        <Space style={{ width: '100%', justifyContent: 'space-between' }} wrap>
          <Typography.Title level={4} style={{ margin: 0, fontWeight: 800 }}>ایمپورت اکسل</Typography.Title>
          <Button icon={<DownloadOutlined />} onClick={onDownloadSample}>دانلود فایل نمونه</Button>
        </Space>

        <Space style={{ marginTop: 12 }} wrap>
          <Upload key={preview ? 'upload-has-preview' : 'upload-empty'} beforeUpload={onPreview} maxCount={1} showUploadList={false}>
            <Button icon={<UploadOutlined />} loading={state.previewLoading}>انتخاب فایل و پیش‌نمایش</Button>
          </Upload>
          <Button type="primary" onClick={onCommit} disabled={!preview?.preview_token || errors.length > 0} loading={state.commitLoading}>تایید و آپلود</Button>
        </Space>

        <div style={{ marginTop: 12 }}>
          <Alert
            type={errors.length ? 'warning' : 'info'}
            showIcon
            message={preview ? `پیش‌نمایش آماده شد - ${preview.policies?.length || 0} بیمه‌نامه و ${rows.length || 0} ردیف` : 'فایل را انتخاب کن تا پیش‌نمایش ساخته شود'}
            description="کنترل‌های فعال: جمع اقساط با کل حق بیمه برابر باشد، تاریخ شروع از تاریخ انقضا کوچکتر باشد، بازاریاب فقط از لیست بازاریاب‌های سامانه باشد."
          />
        </div>

        {errors.length > 0 && (
          <div style={{ marginTop: 12 }}>
            <Alert
              type="error"
              showIcon
              message={`تعداد خطاها: ${errors.length}`}
              description={<div>{errors.slice(0, 50).map((e, idx) => <div key={idx}>{e.message || JSON.stringify(e)}</div>)}{errors.length > 50 ? <div>…</div> : null}</div>}
            />
          </div>
        )}

        {warnings.length > 0 && (
          <div style={{ marginTop: 12 }}>
            <Alert
              type="warning"
              showIcon
              message={`تعداد هشدارها: ${warnings.length}`}
              description={<div>{warnings.slice(0, 20).map((e, idx) => <div key={idx}>{e.message || JSON.stringify(e)}</div>)}{warnings.length > 20 ? <div>…</div> : null}</div>}
            />
          </div>
        )}
      </Card>

      <Card className="sama-card" styles={{ body: { padding: 0 } }}>
        <Table size="small" rowKey="key" columns={columns} dataSource={rows} pagination={{ pageSize: 30 }} tableLayout="auto" scroll={{ x: 3000 }} locale={{ emptyText: preview ? 'هیچ ردیفی برای نمایش پیدا نشد' : 'هنوز پیش‌نمایشی ایجاد نشده است' }} />
      </Card>

      <Divider style={{ margin: '4px 0' }} />

      <Card className="sama-card" title="سوابق ایمپورت" styles={{ body: { padding: 0 } }}>
        <Table size="small" rowKey="id" columns={historyColumns} dataSource={state.history || []} pagination={{ pageSize: 10, showSizeChanger: false }} tableLayout="auto" scroll={{ x: 1100 }} locale={{ emptyText: 'هنوز سابقه‌ای ثبت نشده است' }} />
      </Card>
    </Space>
  )
}
