import React, { useMemo, useState } from 'react'
import {
  Button,
  Card,
  Col,
  Divider,
  Drawer,
  Form,
  Image,
  Input,
  List,
  Modal,
  Row,
  Select,
  Space,
  Tag,
  Table,
  Typography,
  Upload,
  message,
} from 'antd'
import { Link } from 'react-router-dom'
import {
  UploadOutlined,
  SettingOutlined,
  FileOutlined,
  DeleteOutlined,
  PlusOutlined,
  MessageOutlined,
} from '@ant-design/icons'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { errorToText } from '../utils/errorText'
import AuthenticatedImage from '../components/AuthenticatedImage.jsx'
import FilePreviewModal from '../components/FilePreviewModal.jsx'
import { fetchBlob, downloadBlob } from '../utils/fileAccess'

import { http } from "../api/http";
import { loadSettings } from '../utils/appSettings.js'
import { makeGsColumnFilter, uniq } from '../utils/gsFilters.jsx'
import JalaliDatePicker from '../components/JalaliDatePicker.jsx'
import {
  createDocumentFollowup,
  createDocumentRequirement,
  deleteDocumentRequirement,
  deletePolicyDocument,
  getDownloadUrl,
  getPolicyDocumentsChecklist,
  listDocumentFollowups,
  listDocumentRequirements,
  uploadPolicyDocument,
} from '../api/documents'

function statusTag(status) {
  if (status === 'تکمیل') return <Tag color="green">تکمیل</Tag>
  if (status === 'ناقص') return <Tag color="orange">ناقص</Tag>
  return <Tag>نامشخص</Tag>
}

export default function Docs() {
  const qc = useQueryClient()

  const [selectedPolicy, setSelectedPolicy] = useState(null)
  const [page, setPage] = useState(1)
  const [pageSize, setPageSize] = useState(18)
  const [policyDrawerOpen, setPolicyDrawerOpen] = useState(false)
  // چک‌لیست از این صفحه حذف شد و به تنظیمات منتقل گردید.
  const [followupOpen, setFollowupOpen] = useState(false)
  const [preview, setPreview] = useState({ open: false, url: '', title: '', mime: '' })

  // Policies list (lightweight)
  const policiesQ = useQuery({
    queryKey: ['policies', 'docsCenter', { page, pageSize }],
    queryFn: async () => {
      const res = await http.get('/policies', { params: { sort_by: 'issue_date_j', sort_dir: 'desc', page, page_size: pageSize } })
      return res.data
    },
    keepPreviousData: true,
  })

  const policies = Array.isArray(policiesQ.data) ? policiesQ.data : (policiesQ.data?.items || [])
  const totalPolicies = Array.isArray(policiesQ.data) ? policies.length : (policiesQ.data?.total || 0)

  const selectedPolicyFull = useMemo(() => {
    if (!selectedPolicy) return null
    return policies.find((p) => p.id === selectedPolicy) || null
  }, [selectedPolicy, policies])

  const checklistQ = useQuery({
    queryKey: ['docsChecklist', selectedPolicy],
    enabled: !!selectedPolicy,
    queryFn: () => getPolicyDocumentsChecklist(selectedPolicy),
  })

  const followupsQ = useQuery({
    queryKey: ['docsFollowups', selectedPolicy],
    enabled: !!selectedPolicy,
    queryFn: () => listDocumentFollowups(selectedPolicy),
  })

  const uploadMut = useMutation({
    mutationFn: uploadPolicyDocument,
    onSuccess: () => {
      message.success('سند آپلود شد')
      qc.invalidateQueries({ queryKey: ['docsChecklist', selectedPolicy] })
      qc.invalidateQueries({ queryKey: ['policies', 'docsCenter'] })
    },
    onError: (e) => message.error(errorToText(e, 'خطا در آپلود')),
  })

  const deleteDocMut = useMutation({
    mutationFn: deletePolicyDocument,
    onSuccess: () => {
      message.success('حذف شد')
      qc.invalidateQueries({ queryKey: ['docsChecklist', selectedPolicy] })
      qc.invalidateQueries({ queryKey: ['policies', 'docsCenter'] })
    },
    onError: (e) => message.error(errorToText(e, 'خطا در حذف')),
  })

  const followupMut = useMutation({
    mutationFn: ({ policyId, payload }) => createDocumentFollowup(policyId, payload),
    onSuccess: () => {
      message.success('پیگیری ثبت شد')
      qc.invalidateQueries({ queryKey: ['docsFollowups', selectedPolicy] })
      setFollowupOpen(false)
    },
    onError: (e) => message.error(errorToText(e, 'خطا در ثبت پیگیری')),
  })

  const incompletePolicies = useMemo(() => {
    return policies.filter((p) => p.documents_status === 'ناقص')
  }, [policies])

  const orderedPolicies = useMemo(() => {
    return [...incompletePolicies, ...policies.filter((p) => p.documents_status !== 'ناقص')]
  }, [incompletePolicies, policies])

  const openChecklist = (policy) => {
    setSelectedPolicy(policy.id)
    setPolicyDrawerOpen(true)
  }

  const openFollowupModal = (policy) => {
    setSelectedPolicy(policy.id)
    setFollowupOpen(true)
  }

  return (
    <>
    <Card className="sama-card" styles={{ body: { padding: 12 } }}>
      <Space style={{ width: '100%', justifyContent: 'space-between' }} align="center" wrap>
        <Space direction="vertical" size={2}>
          <Typography.Title level={5} style={{ margin: 0, fontWeight: 800 }}>
            پنل مستندات
          </Typography.Title>
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>
            در این صفحه فقط جدول مستندات نمایش داده می‌شود و عملیات هر رکورد از ستون «عملیات» انجام می‌شود.
          </Typography.Text>
        </Space>
        <Link to="/settings/checklist">
          <Button icon={<SettingOutlined />}>چک‌لیست</Button>
        </Link>
      </Space>

      <Divider style={{ margin: '12px 0' }} />

      <Table
        size="small"
        rowKey="id"
        loading={policiesQ.isLoading}
        pagination={{
          current: page,
          pageSize,
          total: totalPolicies,
          showSizeChanger: true,
          pageSizeOptions: [10, 18, 25, 50],
          onChange: (p, ps) => {
            setPage(p)
            setPageSize(ps)
          },
        }}
        tableLayout="auto"
        scroll={{ x: 'max-content' }}
        dataSource={orderedPolicies}
        columns={[
          {
            title: 'شماره',
            dataIndex: 'policy_number',
            width: 140,
            ellipsis: true,
            sorter: (a, b) => String(a.policy_number).localeCompare(String(b.policy_number)),
            ...makeGsColumnFilter({ key: 'policy_number', getValues: () => uniq(policies.map((x) => x.policy_number)) }),
          },
          {
            title: 'بیمه گذار',
            dataIndex: 'policyholder_name',
            width: 180,
            ellipsis: true,
            sorter: (a, b) => String(a.policyholder_name || '').localeCompare(String(b.policyholder_name || '')),
            ...makeGsColumnFilter({ key: 'policyholder_name', getValues: () => uniq(policies.map((x) => x.policyholder_name)) }),
          },
          {
            title: 'بازاریاب',
            dataIndex: 'marketer',
            width: 160,
            ellipsis: true,
            sorter: (a, b) => String(a.marketer || '').localeCompare(String(b.marketer || '')),
            ...makeGsColumnFilter({ key: 'marketer', getValues: () => uniq(policies.map((x) => x.marketer)) }),
          },
          {
            title: 'رشته',
            dataIndex: 'insurance_line',
            width: 160,
            ellipsis: true,
            sorter: (a, b) => String(a.insurance_line || '').localeCompare(String(b.insurance_line || '')),
            ...makeGsColumnFilter({ key: 'insurance_line', getValues: () => uniq(policies.map((x) => x.insurance_line)) }),
          },
          {
            title: 'تاریخ صدور',
            dataIndex: 'issue_date_j',
            width: 110,
            sorter: (a, b) => String(a.issue_date_j || '').localeCompare(String(b.issue_date_j || '')),
            ...makeGsColumnFilter({ key: 'issue_date_j', getValues: () => uniq(policies.map((x) => x.issue_date_j)) }),
          },
          {
            title: 'مورد بیمه',
            dataIndex: 'insured_item',
            width: 260,
            ellipsis: true,
            sorter: (a, b) => String(a.insured_item || '').localeCompare(String(b.insured_item || '')),
            ...makeGsColumnFilter({ key: 'insured_item', getValues: () => uniq(policies.map((x) => x.insured_item)) }),
          },
          { title: 'وضعیت', dataIndex: 'documents_status', width: 90, render: (v) => statusTag(v) },
          {
            title: 'عملیات',
            key: 'actions',
            width: 220,
            fixed: 'right',
            render: (_, record) => (
              <Space wrap>
                <Button size="small" onClick={() => openFollowupModal(record)} icon={<MessageOutlined />}>
                  ثبت پیگیری
                </Button>
                <Button size="small" onClick={() => openChecklist(record)}>
                  نمایش چک لیست
                </Button>
              </Space>
            ),
          },
        ]}
      />

    </Card>

      <FollowupModal
        open={followupOpen}
        onClose={() => setFollowupOpen(false)}
        onSubmit={(payload) => followupMut.mutate({ policyId: selectedPolicyFull?.id, payload })}
        loading={followupMut.isPending}
        policy={selectedPolicyFull}
      />

    <Drawer
      open={policyDrawerOpen}
      onClose={() => setPolicyDrawerOpen(false)}
      width={920}
      title={selectedPolicyFull ? `مستندات — ${selectedPolicyFull.policy_number}` : 'مستندات'}
      destroyOnClose
    >
      {!selectedPolicyFull ? (
        <Typography.Text type="secondary">از لیست یک بیمه‌نامه را انتخاب کن.</Typography.Text>
      ) : (
        <Space direction="vertical" size={12} style={{ width: '100%' }}>
          <Space style={{ width: '100%', justifyContent: 'space-between' }} align="start">
            <Space direction="vertical" size={2}>
              <Typography.Title level={5} style={{ margin: 0, fontWeight: 900 }}>
                {selectedPolicyFull.policy_number}
              </Typography.Title>
              <Typography.Text type="secondary">
                {selectedPolicyFull.policyholder_name} — {selectedPolicyFull.insurance_line}
              </Typography.Text>
            </Space>
            <Button icon={<MessageOutlined />} onClick={() => setFollowupOpen(true)}>
              ثبت پیگیری
            </Button>
          </Space>

          <Divider style={{ margin: '8px 0' }} />

          <Typography.Text style={{ fontWeight: 800 }}>چک‌لیست مستندات</Typography.Text>

          <List
            dataSource={checklistQ.data || []}
            loading={checklistQ.isLoading}
            renderItem={(item) => {
              const req = item.requirement
              const docs = item.documents || []
              const complete = item.is_complete
              return (
                <List.Item style={{ alignItems: 'flex-start' }}>
                  <Space direction="vertical" size={6} style={{ width: '100%' }}>
                    <Space style={{ width: '100%', justifyContent: 'space-between' }}>
                      <Space wrap>
                        <Typography.Text style={{ fontWeight: 700 }}>{req.title}</Typography.Text>
                        {req.is_required ? <Tag color="red">اجباری</Tag> : <Tag>اختیاری</Tag>}
                        <Tag color={req.source === 'agent' ? 'blue' : 'geekblue'}>
                          {req.source === 'agent' ? 'از طرف نمایندگی' : 'از طرف بیمه‌گذار'}
                        </Tag>
                        {complete ? <Tag color="green">OK</Tag> : req.is_required ? <Tag color="orange">ناقص</Tag> : null}
                      </Space>

                      <Upload
                        maxCount={1}
                        showUploadList={false}
                        beforeUpload={(file) => {
                          uploadMut.mutate({
                            policyId: selectedPolicyFull.id,
                            requirementId: req.id,
                            file,
                            uploadedBy: 'agent',
                          })
                          return false
                        }}
                      >
                        <Button icon={<UploadOutlined />} loading={uploadMut.isPending}>
                          آپلود
                        </Button>
                      </Upload>
                    </Space>

                    {req.note ? (
                      <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                        {req.note}
                      </Typography.Text>
                    ) : null}

                    {docs.length === 0 ? (
                      <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                        هنوز سندی آپلود نشده.
                      </Typography.Text>
                    ) : (
                      <Space direction="vertical" size={4} style={{ width: '100%' }}>
                        {docs.map((d) => (
                          <Space key={d.id} style={{ width: '100%', justifyContent: 'space-between' }}>
                            <Space>
                              <FileOutlined />
                              {(() => {
                                const apiUrl = `/documents/files/${d.id}`
                                const ct = (d.content_type || d.mime_type || '')
                                const isImg = ct.startsWith('image/')
                                const filename = d.original_filename || 'file'
                                if (isImg) {
                                  return (
                                    <Space>
                                      <AuthenticatedImage url={apiUrl} width={56} height={56} />
                                      <Button size="small" onClick={() => setPreview({ open: true, url: apiUrl, title: filename, mime: ct })}>
                                        مشاهده
                                      </Button>
                                      <Button
                                        size="small"
                                        onClick={async () => {
                                          try {
                                            const blob = await fetchBlob(apiUrl)
                                            downloadBlob(blob, filename)
                                          } catch (e) {
                                            message.error(errorToText(e, 'خطا در دانلود'))
                                          }
                                        }}
                                      >
                                        دانلود
                                      </Button>
                                    </Space>
                                  )
                                }
                                return (
                                  <Space>
                                    <Button size="small" onClick={() => setPreview({ open: true, url: apiUrl, title: filename, mime: ct })}>
                                      مشاهده
                                    </Button>
                                    <Button
                                      size="small"
                                      onClick={async () => {
                                        try {
                                          const blob = await fetchBlob(apiUrl)
                                          downloadBlob(blob, filename)
                                        } catch (e) {
                                          message.error(errorToText(e, 'خطا در دانلود'))
                                        }
                                      }}
                                    >
                                      دانلود
                                    </Button>
                                    <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                                      {filename}
                                    </Typography.Text>
                                  </Space>
                                )
                              })()}
                            </Space>

                            <Button
                              size="small"
                              danger
                              icon={<DeleteOutlined />}
                              loading={deleteDocMut.isPending}
                              onClick={() => deleteDocMut.mutate(d.id)}
                            />
                          </Space>
                        ))}
                      </Space>
                    )}
                  </Space>
                </List.Item>
              )
            }}
          />

          <Divider style={{ margin: '12px 0 8px' }} />

          <Typography.Text style={{ fontWeight: 800 }}>سوابق پیگیری</Typography.Text>
          <List
            dataSource={followupsQ.data || []}
            loading={followupsQ.isLoading}
            locale={{ emptyText: 'هنوز پیگیری‌ای ثبت نشده است.' }}
            renderItem={(item) => {
              const channelMap = {
                call: 'تماس',
                sms: 'پیامک',
                whatsapp: 'واتساپ',
                in_person: 'حضوری',
              }
              return (
                <List.Item>
                  <Space direction="vertical" size={2} style={{ width: '100%' }}>
                    <Space wrap style={{ width: '100%', justifyContent: 'space-between' }}>
                      <Space wrap>
                        <Tag color="blue">{channelMap[item.channel] || item.channel || 'پیگیری'}</Tag>
                        {item.result ? <Tag color="default">{item.result}</Tag> : null}
                        {item.next_followup_date_j ? <Tag color="orange">پیگیری بعدی: {item.next_followup_date_j}</Tag> : null}
                      </Space>
                      <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                        {item.created_by_name || 'نامشخص'}
                        {item.created_at ? ` • ${new Date(item.created_at).toLocaleString('fa-IR')}` : ''}
                      </Typography.Text>
                    </Space>
                    {item.note ? (
                      <Typography.Text style={{ whiteSpace: 'pre-wrap' }}>{item.note}</Typography.Text>
                    ) : (
                      <Typography.Text type="secondary">بدون توضیح</Typography.Text>
                    )}
                  </Space>
                </List.Item>
              )
            }}
          />
        </Space>
      )}
    </Drawer>

    <FilePreviewModal
      open={preview.open}
      url={preview.url}
      title={preview.title}
      mimeType={preview.mime}
      onClose={() => setPreview({ open: false, url: '', title: '', mime: '' })}
      onDownload={async () => {
        try {
          const blob = await fetchBlob(preview.url)
          downloadBlob(blob, preview.title || 'file')
        } catch (e) {
          message.error(errorToText(e, 'خطا در دانلود'))
        }
      }}
    />
    </>
  )
}

function FollowupModal({ open, onClose, onSubmit, loading, policy }) {
  const [form] = Form.useForm()


  return (
    <Modal
      open={open}
      title="ثبت پیگیری تکمیل مستندات"
      onCancel={onClose}
      onOk={() => {
        form
          .validateFields()
          .then((v) => {
            onSubmit(v)
            form.resetFields()
          })
          .catch(() => {})
      }}
      confirmLoading={loading}
      okText="ثبت"
      cancelText="انصراف"
    >
      <Space direction="vertical" size={6} style={{ width: '100%' }}>
        {policy ? (
          <Typography.Text type="secondary">
            {policy.policy_number} — {policy.policyholder_name}
          </Typography.Text>
        ) : null}
        <Form layout="vertical" form={form}>
          <Form.Item name="channel" label="کانال" rules={[{ required: true, message: 'کانال را انتخاب کنید' }]}>
            <Select
              options={[
                { value: 'call', label: 'تماس' },
                { value: 'sms', label: 'پیامک' },
                { value: 'whatsapp', label: 'واتساپ' },
                { value: 'in_person', label: 'حضوری' },
              ]}
            />
          </Form.Item>

          <Form.Item name="result" label="نتیجه">
            <Input placeholder="مثلاً: ارسال مدارک تا فردا" />
          </Form.Item>

          <Form.Item name="note" label="توضیحات">
            <Input.TextArea rows={3} placeholder="جزئیات پیگیری/توضیحات" />
          </Form.Item>

          <Form.Item name="next_followup_date_j" label="تاریخ پیگیری بعدی" tooltip="اختیاری (مثلاً 1404/12/30)">
            <JalaliDatePicker style={{ width: '100%' }} allowClear />
          </Form.Item>
        </Form>
      </Space>
    </Modal>
  )
}

function ChecklistSettings({ open, onClose, onChanged }) {
  const settings = loadSettings()
  const insuranceLines = settings.insuranceLines || []

  const qc = useQueryClient()
  const [line, setLine] = useState('')
  const [createOpen, setCreateOpen] = useState(false)
  const [form] = Form.useForm()

  const reqQ = useQuery({
    queryKey: ['docRequirements', line],
    enabled: open,
    queryFn: () => listDocumentRequirements(line ? { insurance_line: line } : {}),
  })

  const createMut = useMutation({
    mutationFn: createDocumentRequirement,
    onSuccess: () => {
      message.success('ثبت شد')
      qc.invalidateQueries({ queryKey: ['docRequirements'] })
      setCreateOpen(false)
      form.resetFields()
      onChanged?.()
    },
    onError: (e) => message.error(errorToText(e, 'خطا')),
  })

  const delMut = useMutation({
    mutationFn: deleteDocumentRequirement,
    onSuccess: () => {
      message.success('حذف شد')
      qc.invalidateQueries({ queryKey: ['docRequirements', line] })
      onChanged?.()
    },
    onError: (e) => message.error(errorToText(e, 'خطا در حذف')),
  })

  return (
    <Drawer open={open} onClose={onClose} title="تعریف چک‌لیست مستندات" width={520}>
      <Space direction="vertical" size={12} style={{ width: '100%' }}>
        <Typography.Text type="secondary">
          برای هر «رشته بیمه» می‌توانید لیست مدارک اجباری/اختیاری را تعریف کنید.
        </Typography.Text>

        <Space>
          <Select
            value={line || undefined}
            onChange={(v) => setLine(v || '')}
            placeholder="فیلتر رشته"
            allowClear
            showSearch
            options={(insuranceLines || []).map((x) => ({ value: x, label: x }))}
            style={{ width: 260 }}
          />
          <Button type="primary" icon={<PlusOutlined />} onClick={() => setCreateOpen(true)}>
            افزودن
          </Button>
        </Space>

        <List
          size="small"
          dataSource={reqQ.data || []}
          loading={reqQ.isLoading}
          renderItem={(r) => (
            <List.Item
              actions={[
                <Button key="del" danger icon={<DeleteOutlined />} size="small" onClick={() => delMut.mutate(r.id)}>
                  حذف
                </Button>,
              ]}
            >
              <Space direction="vertical" size={2}>
                <Space wrap>
                  <Typography.Text style={{ fontWeight: 700 }}>{r.title}</Typography.Text>
                  {r.is_required ? <Tag color="red">اجباری</Tag> : <Tag>اختیاری</Tag>}
                  <Tag color={r.source === 'agent' ? 'blue' : 'geekblue'}>
                    {r.source === 'agent' ? 'نمایندگی' : 'بیمه‌گذار'}
                  </Tag>
                  <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                    {r.insurance_line}
                  </Typography.Text>
                </Space>
                {r.note ? <Typography.Text type="secondary" style={{ fontSize: 12 }}>{r.note}</Typography.Text> : null}
              </Space>
            </List.Item>
          )}
        />
      </Space>

      <Modal
        open={createOpen}
        title="افزودن آیتم چک‌لیست"
        onCancel={() => setCreateOpen(false)}
        okText="ثبت"
        cancelText="انصراف"
        confirmLoading={createMut.isPending}
        onOk={() => {
          form.validateFields().then((v) => createMut.mutate(v))
        }}
      >
        <Form layout="vertical" form={form} initialValues={{ is_required: true, source: 'policyholder', sort_order: 0 }}>
          <Form.Item name="insurance_line" label="رشته" rules={[{ required: true, message: 'رشته را انتخاب کنید' }]}>
            <Select
              showSearch
              placeholder="انتخاب رشته"
              options={(insuranceLines || []).map((x) => ({ value: x, label: x }))}
            />
          </Form.Item>
          <Form.Item name="title" label="عنوان سند" rules={[{ required: true, message: 'عنوان را وارد کنید' }]}>
            <Input placeholder="مثلاً: تصویر کارت ملی" />
          </Form.Item>
          <Row gutter={12}>
            <Col span={12}>
              <Form.Item name="is_required" label="وضعیت" rules={[{ required: true }]}>
                <Select options={[{ value: true, label: 'اجباری' }, { value: false, label: 'اختیاری' }]} />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item name="source" label="تامین‌کننده" rules={[{ required: true }]}>
                <Select options={[{ value: 'policyholder', label: 'بیمه‌گذار' }, { value: 'agent', label: 'نمایندگی' }]} />
              </Form.Item>
            </Col>
          </Row>
          <Form.Item name="sort_order" label="ترتیب" tooltip="عدد کوچکتر = بالاتر">
            <Input type="number" />
          </Form.Item>
          <Form.Item name="note" label="توضیح (اختیاری)">
            <Input.TextArea rows={2} placeholder="مثلاً: فایل PDF یا تصویر خوانا" />
          </Form.Item>
        </Form>
      </Modal>
    </Drawer>
  )
}