import React, { useMemo, useState } from 'react'
import { Button, Card, Space, Table, Tabs, Tag, Typography } from 'antd'
import { ReloadOutlined } from '@ant-design/icons'
import { useQuery } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'
import { getDashboardSummary } from '../api/dashboard'

function fmtNum(n) {
  try { return new Intl.NumberFormat('fa-IR').format(n ?? 0) } catch { return String(n ?? 0) }
}

export default function Dashboard() {
  const nav = useNavigate()
  const me = useMemo(() => {
    try { return JSON.parse(localStorage.getItem('sama_user') || 'null') } catch { return null }
  }, [])
  const isMarketer = me?.user_type === 'marketer'

  const { data, isFetching, refetch } = useQuery({
    queryKey: ['dashboard-summary'],
    queryFn: getDashboardSummary,
    staleTime: 15_000,
  })

  const [renewalsTab, setRenewalsTab] = useState('7')
  const [installmentsTab, setInstallmentsTab] = useState('0')

  const renewalsRows = {
    '7': data?.renewals_next7 || [],
    '15': data?.renewals_next15 || [],
    '30': data?.renewals_next30 || [],
  }[renewalsTab] || []

  const installmentsRows = {
    '0': data?.installments_today || [],
    '3': data?.installments_next3 || [],
    '5': data?.installments_next5 || [],
  }[installmentsTab] || []

  const renewalsColumns = [
    { title: 'شماره بیمه‌نامه', dataIndex: 'policy_number', width: 160 },
    { title: 'بازاریاب', dataIndex: 'marketer', width: 150, render: (v) => v || '—' },
    { title: 'نام', dataIndex: 'policyholder_name', width: 170 },
    { title: 'مورد بیمه', dataIndex: 'insured_item', width: 180 },
    { title: 'تاریخ انقضا', dataIndex: 'end_date_j', width: 110 },
    { title: 'وضعیت', dataIndex: 'status', width: 100, render: (v) => <Tag color={v === 'pending' ? 'orange' : 'green'}>{v === 'pending' ? 'در انتظار' : v}</Tag> },
    { title: 'عملیات', key: 'act', width: 110, render: (_, r) => <Button size="small" onClick={() => nav('/renewals')}>عملیات</Button> },
  ]

  const installmentsColumns = [
    { title: 'شماره بیمه‌نامه', dataIndex: 'policy_number', width: 160 },
    { title: 'بازاریاب', dataIndex: 'marketer', width: 150, render: (v) => v || '—' },
    { title: 'نام', dataIndex: 'policyholder_name', width: 170 },
    { title: 'مبلغ', dataIndex: 'remain_rial', width: 130, render: (v) => fmtNum(v) },
    { title: 'تاریخ سررسید', dataIndex: 'due_date_j', width: 120 },
    { title: 'شناسه', dataIndex: 'display_id', width: 170, ellipsis: true },
    { title: 'وضعیت', dataIndex: 'status', width: 100, render: (v) => <Tag color={v === 'paid' ? 'green' : 'orange'}>{v === 'paid' ? 'پرداخت شده' : 'پرداخت نشده'}</Tag> },
    { title: 'عملیات', key: 'act', width: 110, render: (_, r) => <Button size="small" onClick={() => nav('/installments')}>عملیات</Button> },
  ]

  const tasksColumns = [
    { title: 'عنوان', dataIndex: 'title' },
  ]

  const requestsColumns = [
    { title: 'بازاریاب', dataIndex: 'marketer_name', width: 180, render: (v) => v || '—' },
    { title: 'عنوان', dataIndex: 'title' },
  ]

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card
        title="داشبورد"
        extra={<Button icon={<ReloadOutlined />} size="small" loading={isFetching} onClick={() => refetch()}>بروزرسانی</Button>}
      >
        <Typography.Text type="secondary">
          خلاصه امروز: تمدیدهای نزدیک، اقساط سررسیددار، وظایف امروز و کارتابل.
        </Typography.Text>
      </Card>

      <Card title="تمدیدهای نزدیک">
        <Tabs
          activeKey={renewalsTab}
          onChange={setRenewalsTab}
          items={[
            { key: '7', label: `۷ روز آینده (${(data?.renewals_next7 || []).length})` },
            { key: '15', label: `۱۵ روز آینده (${(data?.renewals_next15 || []).length})` },
            { key: '30', label: `۳۰ روز آینده (${(data?.renewals_next30 || []).length})` },
          ]}
        />
        <Table rowKey={(r) => String(r.policy_id)} columns={renewalsColumns} dataSource={renewalsRows} size="small" pagination={{ pageSize: 8 }} scroll={{ x: 'max-content' }} />
      </Card>

      <Card title="اقساط سررسیددار">
        <Tabs
          activeKey={installmentsTab}
          onChange={setInstallmentsTab}
          items={[
            { key: '0', label: `امروز (${(data?.installments_today || []).length})` },
            { key: '3', label: `۳ روز آینده (${(data?.installments_next3 || []).length})` },
            { key: '5', label: `۵ روز آینده (${(data?.installments_next5 || []).length})` },
          ]}
        />
        <Table rowKey={(r) => String(r.payment_item_id)} columns={installmentsColumns} dataSource={installmentsRows} size="small" pagination={{ pageSize: 8 }} scroll={{ x: 'max-content' }} />
      </Card>

      <Card title="وظایف امروز">
        <Table rowKey="id" columns={tasksColumns} dataSource={data?.tasks_today_items || []} size="small" pagination={{ pageSize: 8 }} />
      </Card>

      {!isMarketer ? (
        <Card title="کارتابل امروز">
          <Table rowKey="id" columns={requestsColumns} dataSource={data?.requests_today_items || []} size="small" pagination={{ pageSize: 8 }} />
        </Card>
      ) : null}
    </Space>
  )
}
