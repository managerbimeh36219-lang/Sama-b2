import React, { useEffect, useMemo, useState } from 'react'
import {
  Button,
  Card,
  Drawer,
  Form,
  Input,
  Select,
  Space,
  Table,
  Tag,
  Typography,
  message,
  Tabs,
  Modal,
} from 'antd'
import { PlusOutlined } from '@ant-design/icons'
import { useQueryClient } from '@tanstack/react-query'

import JalaliDatePicker from '../components/JalaliDatePicker'
import { listTasks, createTask, updateTask } from '../api/tasks'
import { listUsers } from '../api/users'
import { listMarketers } from '../api/marketers2'

const STATUS_OPTIONS = [
  { value: 'open', label: 'باز' },
  { value: 'done', label: 'انجام شده' },
  { value: 'canceled', label: 'لغو شده' },
]

const PRIORITY_OPTIONS = [
  { value: 'low', label: 'کم' },
  { value: 'normal', label: 'عادی' },
  { value: 'high', label: 'بالا' },
]

export default function TasksCenter() {
  const qc = useQueryClient()
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [users, setUsers] = useState([])
  const [marketers, setMarketers] = useState([])
  const [scope, setScope] = useState('assigned')
  const [tab, setTab] = useState('open')
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form] = Form.useForm()
  const [doneModal, setDoneModal] = useState({ open: false, row: null, note: '' })

  const me = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem('sama_user') || 'null')
    } catch {
      return null
    }
  }, [])
  const isAdmin = !!me && (me.user_type === 'admin' || me.role === 'admin')

  const userOptions = useMemo(
    () => users.map((u) => ({ value: u.id, label: `${u.full_name}${u.mobile ? ` (${u.mobile})` : ''}` })),
    [users]
  )
  const marketerOptions = useMemo(
    () => marketers.map((m) => ({ value: m.id, label: `${m.full_name}${m.code ? ` - ${m.code}` : ''}` })),
    [marketers]
  )

  async function refresh(nextTab = tab) {
    setLoading(true)
    try {
      const data = await listTasks({ scope, status: nextTab === 'done' ? 'done' : 'open' })
      setRows(Array.isArray(data) ? data : [])
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در دریافت وظایف')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    listUsers().then(setUsers).catch(() => {})
    listMarketers().then(setMarketers).catch(() => {})
  }, [])

  useEffect(() => {
    refresh()
  }, [scope, tab])

  const byIdUser = useMemo(() => new Map(users.map((u) => [u.id, u])), [users])
  const byIdMarketer = useMemo(() => new Map(marketers.map((m) => [m.id, m])), [marketers])

  const columns = [
    {
      title: 'عنوان',
      dataIndex: 'title',
      key: 'title',
      render: (v, r) => (
        <Space direction="vertical" size={2}>
          <Typography.Text style={{ fontWeight: 700 }}>{v}</Typography.Text>
          {r.description ? <Typography.Text type="secondary">{r.description}</Typography.Text> : null}
        </Space>
      ),
    },
    {
      title: 'اولویت',
      dataIndex: 'priority',
      key: 'priority',
      width: 110,
      render: (v) => <Tag>{PRIORITY_OPTIONS.find((o) => o.value === v)?.label || v}</Tag>,
    },
    {
      title: 'ارجاع به',
      key: 'assignee',
      width: 220,
      render: (_, r) => {
        if (r.assigned_user_id) return byIdUser.get(r.assigned_user_id)?.full_name || `کاربر #${r.assigned_user_id}`
        if (r.assigned_marketer_id) return byIdMarketer.get(r.assigned_marketer_id)?.full_name || `بازاریاب #${r.assigned_marketer_id}`
        return '—'
      },
    },
    {
      title: 'سررسید',
      key: 'due_date_j',
      width: 170,
      render: (_, r) => [r.due_date_j, r.due_time].filter(Boolean).join(' - ') || '—',
    },
    {
      title: 'عملیات',
      key: 'actions',
      width: 190,
      render: (_, r) => (
        <Space>
          <Button
            size="small"
            onClick={() => {
              setEditing(r)
              form.setFieldsValue({
                title: r.title,
                description: r.description,
                status: r.status,
                priority: r.priority,
                assigned_user_id: r.assigned_user_id || null,
                assigned_marketer_id: r.assigned_marketer_id || null,
                due_date_j: r.due_date_j || null,
                due_time: r.due_time || null,
              })
              setDrawerOpen(true)
            }}
          >
            ویرایش
          </Button>
          {tab !== 'done' ? (
            <Button size="small" type="primary" onClick={() => setDoneModal({ open: true, row: r, note: '' })}>
              انجام شد
            </Button>
          ) : null}
        </Space>
      ),
    },
  ]

  const scopeOptions = useMemo(() => {
    const base = [
      { value: 'assigned', label: 'ارجاع‌شده به من' },
      { value: 'created', label: 'ایجادشده توسط من' },
    ]
    if (isAdmin) base.push({ value: 'all', label: 'همه' })
    return base
  }, [isAdmin])

  async function onSubmit() {
    const vals = await form.validateFields()
    const payload = {
      title: vals.title,
      description: vals.description || null,
      status: vals.status || 'open',
      priority: vals.priority || 'normal',
      assigned_user_id: vals.assigned_user_id || null,
      assigned_marketer_id: vals.assigned_marketer_id || null,
      due_date_j: vals.due_date_j || null,
      due_time: vals.due_time || null,
    }
    if (payload.assigned_user_id && payload.assigned_marketer_id) {
      message.error('یا کاربر را انتخاب کن یا بازاریاب')
      return
    }
    try {
      if (editing) {
        await updateTask(editing.id, payload)
        message.success('وظیفه ویرایش شد')
      } else {
        await createTask(payload)
        message.success('وظیفه ایجاد شد')
      }
      setDrawerOpen(false)
      setEditing(null)
      form.resetFields()
      refresh()
      qc.invalidateQueries({ queryKey: ['headerStats'] })
      qc.invalidateQueries({ queryKey: ['dashboard-summary'] })
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا')
    }
  }

  async function completeTask() {
    try {
      const row = doneModal.row
      let description = row?.description || ''
      const note = (doneModal.note || '').trim()
      if (note) {
        description = `${description ? `${description}\n` : ''}[انجام شد] ${note}`
      }
      await updateTask(row.id, { status: 'done', description })
      message.success('وظیفه انجام شد')
      setDoneModal({ open: false, row: null, note: '' })
      refresh('open')
      qc.invalidateQueries({ queryKey: ['headerStats'] })
      qc.invalidateQueries({ queryKey: ['dashboard-summary'] })
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در ثبت انجام')
    }
  }

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card
        title="وظایف"
        extra={
          <Space>
            <Select value={scope} onChange={setScope} options={scopeOptions} style={{ width: 180 }} />
            <Button onClick={() => refresh()} loading={loading}>بروزرسانی</Button>
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={() => {
                setEditing(null)
                form.resetFields()
                form.setFieldsValue({ status: 'open', priority: 'normal' })
                setDrawerOpen(true)
              }}
            >
              وظیفه جدید
            </Button>
          </Space>
        }
      >
        <Tabs
          activeKey={tab}
          onChange={setTab}
          items={[
            { key: 'open', label: 'باز' },
            { key: 'done', label: 'انجام شده' },
          ]}
        />
        <Table rowKey="id" loading={loading} columns={columns} dataSource={rows} pagination={{ pageSize: 25 }} />
      </Card>

      <Drawer
        title={editing ? 'ویرایش وظیفه' : 'ایجاد وظیفه'}
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        width={560}
        destroyOnClose
        extra={<Button type="primary" onClick={onSubmit}>ذخیره</Button>}
      >
        <Form layout="vertical" form={form} initialValues={{ status: 'open', priority: 'normal' }}>
          <Form.Item name="title" label="عنوان" rules={[{ required: true, message: 'عنوان لازم است' }]}>
            <Input />
          </Form.Item>
          <Form.Item name="description" label="توضیحات">
            <Input.TextArea rows={4} />
          </Form.Item>
          <Space style={{ width: '100%' }} wrap>
            <Form.Item name="status" label="وضعیت" style={{ minWidth: 180, flex: 1 }}>
              <Select options={STATUS_OPTIONS} />
            </Form.Item>
            <Form.Item name="priority" label="اولویت" style={{ minWidth: 180, flex: 1 }}>
              <Select options={PRIORITY_OPTIONS} />
            </Form.Item>
          </Space>
          <Form.Item name="assigned_user_id" label="ارجاع به کاربر">
            <Select allowClear showSearch options={userOptions} placeholder="اختیاری" />
          </Form.Item>
          <Form.Item name="assigned_marketer_id" label="ارجاع به بازاریاب">
            <Select allowClear showSearch options={marketerOptions} placeholder="اختیاری" />
          </Form.Item>
          <Space style={{ width: '100%' }} wrap>
            <Form.Item name="due_date_j" label="تاریخ" style={{ minWidth: 220, flex: 1 }}>
              <JalaliDatePicker />
            </Form.Item>
            <Form.Item name="due_time" label="ساعت" style={{ width: 140 }}>
              <Input placeholder="HH:MM" />
            </Form.Item>
          </Space>
        </Form>
      </Drawer>

      <Modal
        open={doneModal.open}
        title="ثبت انجام وظیفه"
        onOk={completeTask}
        onCancel={() => setDoneModal({ open: false, row: null, note: '' })}
        okText="ثبت و انتقال به انجام شده‌ها"
        cancelText="انصراف"
      >
        <Input.TextArea
          rows={4}
          placeholder="اگر لازم است توضیح کوتاه بنویس"
          value={doneModal.note}
          onChange={(e) => setDoneModal((s) => ({ ...s, note: e.target.value }))}
        />
      </Modal>
    </Space>
  )
}
