import React, { useEffect, useState } from 'react'
import { Button, Card, Input, Select, Space, Typography, message } from 'antd'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { getSmsConfig, setSmsConfig } from '../api/settings'
import { errorToText } from '../utils/errorText'

export default function SmsConfigPanel() {
  const qc = useQueryClient()
  const q = useQuery({
    queryKey: ['smsConfig'],
    queryFn: getSmsConfig,
  })

  const [form, setForm] = useState({
    provider: 'irpayamak',
    base_url: '',
    username: '',
    password: '',
    from_number: '',
  })

  useEffect(() => {
    if (!q.data) return
    setForm((prev) => ({
      ...prev,
      provider: q.data.provider || prev.provider,
      base_url: q.data.base_url || '',
      username: q.data.username || '',
      password: '', // برای امنیت، پسورد را نمایش نمی‌دهیم
      from_number: q.data.from_number || '',
    }))
  }, [q.data])

  const saveMut = useMutation({
    mutationFn: () => setSmsConfig({
      provider: form.provider,
      base_url: form.base_url,
      username: form.username,
      // اگر خالی باشد یعنی تغییر نکند
      password: form.password ? form.password : undefined,
      from_number: form.from_number,
    }),
    onSuccess: () => {
      message.success('تنظیمات پیامک ذخیره شد')
      setForm((p) => ({ ...p, password: '' }))
      qc.invalidateQueries({ queryKey: ['smsConfig'] })
      qc.invalidateQueries({ queryKey: ['smsStatus'] })
    },
    onError: (e) => message.error(errorToText(e, 'خطا در ذخیره تنظیمات پیامک')),
  })

  const enabled = !!q.data?.enabled

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card className="sama-card" title="تنظیمات پیامک" styles={{ body: { padding: 12 } }}>
        <Space direction="vertical" size={10} style={{ width: '100%' }}>
          <Typography.Text type="secondary" style={{ fontSize: 12 }}>
            وضعیت فعلی: {enabled ? 'فعال' : 'غیرفعال'}
            {q.data?.has_password ? ' (پسورد ثبت شده)' : ''}
          </Typography.Text>

          <Space wrap style={{ width: '100%' }}>
            <div style={{ width: 220 }}>
              <Typography.Text>سرویس‌دهنده</Typography.Text>
              <Select
                value={form.provider}
                onChange={(v) => setForm((p) => ({ ...p, provider: v }))}
                style={{ width: '100%' }}
                options={[
                  { value: 'irpayamak', label: 'irpayamak' },
                  { value: 'kavenegar', label: 'kavenegar' },
                ]}
              />
            </div>

            <div style={{ width: 360 }}>
              <Typography.Text>Base URL</Typography.Text>
              <Input
                value={form.base_url}
                onChange={(e) => setForm((p) => ({ ...p, base_url: e.target.value }))}
                placeholder="مثلاً https://login.irpayamak.com/"
              />
            </div>
          </Space>

          <Space wrap style={{ width: '100%' }}>
            <div style={{ width: 240 }}>
              <Typography.Text>نام کاربری</Typography.Text>
              <Input value={form.username} onChange={(e) => setForm((p) => ({ ...p, username: e.target.value }))} />
            </div>
            <div style={{ width: 240 }}>
              <Typography.Text>رمز عبور</Typography.Text>
              <Input.Password
                value={form.password}
                onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))}
                placeholder={q.data?.has_password ? '******** (برای تغییر، رمز جدید را وارد کنید)' : 'رمز را وارد کنید'}
              />
            </div>
            <div style={{ width: 220 }}>
              <Typography.Text>شماره خط</Typography.Text>
              <Input value={form.from_number} onChange={(e) => setForm((p) => ({ ...p, from_number: e.target.value }))} />
            </div>
          </Space>

          <Space>
            <Button type="primary" onClick={() => saveMut.mutate()} loading={saveMut.isPending}>
              ذخیره
            </Button>
            <Button onClick={() => q.refetch()} loading={q.isFetching}>رفرش</Button>
          </Space>
        </Space>
      </Card>
    </Space>
  )
}
