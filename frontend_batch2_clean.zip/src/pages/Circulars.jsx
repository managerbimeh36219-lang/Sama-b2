import React, { useMemo, useState } from 'react'
import { Button, Card, Descriptions, Divider, Drawer, Form, Input, Modal, Popconfirm, Popover, Space, Table, Tag, Tabs, Typography, Upload, message } from 'antd'
import { PlusOutlined, UploadOutlined, FilePdfOutlined, EditOutlined, DeleteOutlined, SearchOutlined, CalendarOutlined } from '@ant-design/icons'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { addCircularFiles, createCircular, deleteCircular, deleteCircularFile, downloadCircularBlob, downloadCircularFileBlob, listCirculars, markCircularRead, markCircularUnread, updateCircular } from '../api/circulars'
import { downloadBlob } from '../utils/fileAccess'
import { useAppStore } from '../store/appStore'
import dayjs from 'dayjs'
import jalaliday from 'jalaliday'
import DatePicker from 'react-multi-date-picker'
import persian from 'react-date-object/calendars/persian'
import persian_fa from 'react-date-object/locales/persian_fa'
import 'react-multi-date-picker/styles/layouts/mobile.css'

dayjs.extend(jalaliday)

export default function Circulars() {
  const qc = useQueryClient()
  const { user } = useAppStore()
  const isMarketer = user?.user_type === 'marketer'

  const errToText = (e) => {
    const d = e?.response?.data?.detail
    if (!d) return e?.message || 'خطا'
    if (typeof d === 'string') return d
    if (Array.isArray(d)) return d.map((x) => x?.msg || JSON.stringify(x)).join(' | ')
    if (typeof d === 'object') return JSON.stringify(d)
    return String(d)
  }

  const [q, setQ] = useState('')
  const [createOpen, setCreateOpen] = useState(false)
  const [editRow, setEditRow] = useState(null)
  const [selectedFiles, setSelectedFiles] = useState([])
  const [editNewFiles, setEditNewFiles] = useState([])
  const [detailRow, setDetailRow] = useState(null)
  const [preview, setPreview] = useState({ open: false, url: '', title: '' })
  const [form] = Form.useForm()
  const [editForm] = Form.useForm()

  const listQ = useQuery({
    queryKey: ['circulars', q],
    queryFn: () => listCirculars(q),
  })

  const rows = listQ.data || []
  const unreadCount = useMemo(() => rows.filter((r) => !r.is_read).length, [rows])

  const createMut = useMutation({
    mutationFn: (fd) => createCircular(fd),
    onSuccess: () => {
      message.success('بخشنامه ثبت شد')
      setCreateOpen(false)
      form.resetFields()
      setSelectedFiles([])
      qc.invalidateQueries({ queryKey: ['circulars'] })
      qc.invalidateQueries({ queryKey: ['headerStats'] })
    },
    onError: (e) => message.error(errToText(e) || 'خطا در ثبت'),
  })

  const updateMut = useMutation({
    mutationFn: ({ id, payload }) => updateCircular(id, payload),
    onSuccess: () => {
      message.success('ذخیره شد')
      setEditRow(null)
      qc.invalidateQueries({ queryKey: ['circulars'] })
    },
    onError: (e) => message.error(errToText(e) || 'خطا در ذخیره'),
  })

  const addFilesMut = useMutation({
    mutationFn: ({ id, fd }) => addCircularFiles(id, fd),
    onSuccess: (data) => {
      message.success('فایل‌ها اضافه شد')
      setEditNewFiles([])
      // آپدیت سریع UI
      setEditRow((x) => (x ? { ...x, files: data?.files || x.files } : x))
      setDetailRow((x) => (x && x.id === data?.id ? { ...x, files: data?.files || x.files } : x))
      qc.invalidateQueries({ queryKey: ['circulars'] })
    },
    onError: (e) => message.error(errToText(e) || 'خطا در افزودن فایل'),
  })

  const deleteFileMut = useMutation({
    mutationFn: ({ id, fileId }) => deleteCircularFile(id, fileId),
    onSuccess: () => {
      message.success('فایل حذف شد')
      qc.invalidateQueries({ queryKey: ['circulars'] })
    },
    onError: (e) => message.error(errToText(e) || 'خطا در حذف فایل'),
  })

  const DateJField = ({ formRef, name = 'circular_date_j' }) => {
    const val = Form.useWatch(name, formRef)
    return (
      <Space.Compact style={{ width: '100%' }}>
        <Form.Item
          name={name}
          noStyle
          rules={[{ pattern: /^\d{4}\/\d{2}\/\d{2}$/, message: 'فرمت تاریخ باید مثل 1404/12/01 باشد' }]}
        >
          <Input placeholder="1404/12/01" />
        </Form.Item>
        <Popover
          trigger="click"
          placement="bottomLeft"
          content={
            <div style={{ padding: 6 }}>
              <DatePicker
                calendar={persian}
                locale={persian_fa}
                calendarPosition="bottom-right"
                format="YYYY/MM/DD"
                value={val || undefined}
                onChange={(d) => {
                  const s = d ? String(d.format?.('YYYY/MM/DD') || d) : ''
                  formRef?.setFieldValue(name, s)
                }}
              />
            </div>
          }
        >
          <Button icon={<CalendarOutlined />} />
        </Popover>
      </Space.Compact>
    )
  }

  const deleteMut = useMutation({
    mutationFn: (id) => deleteCircular(id),
    onSuccess: () => {
      message.success('حذف شد')
      qc.invalidateQueries({ queryKey: ['circulars'] })
      qc.invalidateQueries({ queryKey: ['headerStats'] })
    },
    onError: (e) => message.error(errToText(e) || 'خطا در حذف'),
  })

  const markReadMut = useMutation({
    mutationFn: (id) => markCircularRead(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['circulars'] })
      qc.invalidateQueries({ queryKey: ['headerStats'] })
      setDetailRow((x) => (x ? { ...x, is_read: true } : x))
    },
    onError: (e) => message.error(errToText(e) || 'خطا'),
  })

  const markUnreadMut = useMutation({
    mutationFn: (id) => markCircularUnread(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['circulars'] })
      qc.invalidateQueries({ queryKey: ['headerStats'] })
      setDetailRow((x) => (x ? { ...x, is_read: false } : x))
    },
    onError: (e) => message.error(errToText(e) || 'خطا'),
  })

  const columns = useMemo(
    () => [
      { title: 'رشته', dataIndex: 'insurance_line', width: 140, ellipsis: true, sorter: (a, b) => String(a.insurance_line || '').localeCompare(String(b.insurance_line || '')) },
      { title: 'موضوع', dataIndex: 'subject', ellipsis: true, sorter: (a, b) => String(a.subject || '').localeCompare(String(b.subject || '')) },
      { title: 'شماره نامه', dataIndex: 'letter_no', width: 130, ellipsis: true },
      { title: 'شناسه نامه', dataIndex: 'ref_no', width: 130, ellipsis: true },
      { title: 'تاریخ', dataIndex: 'circular_date_j', width: 110 },
      // طبق درخواست: «وضعیت» آخرین ستون سمت چپ باشد (در RTL آخر آرایه)
      {
        title: 'وضعیت',
        dataIndex: 'is_read',
        width: 90,
        render: (v) => (v ? <Tag color="green">خوانده‌شده</Tag> : <Tag color="orange">جدید</Tag>),
      },
    ],
    []
  )

  const openPreviewFromBlob = (blob, title) => {
    const url = URL.createObjectURL(blob)
    setPreview({ open: true, url, title })
  }

  const closePreview = () => {
    try {
      if (preview.url) URL.revokeObjectURL(preview.url)
    } catch (_) {}
    setPreview({ open: false, url: '', title: '' })
  }

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card className="sama-card" styles={{ body: { padding: 12 } }}>
        <Space style={{ width: '100%', justifyContent: 'space-between' }} align="start">
          <div>
            <Typography.Title level={5} style={{ margin: 0, fontWeight: 900 }}>
              بخشنامه‌ها
            </Typography.Title>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              جستجو (Ctrl+F) + مرتب‌سازی/فیلتر. تعداد جدید: {unreadCount}
            </Typography.Text>
          </div>
          {!isMarketer ? (
            <Button type="primary" icon={<PlusOutlined />} onClick={() => setCreateOpen(true)}>
              افزودن بخشنامه
            </Button>
          ) : null}
        </Space>

        <Space style={{ width: '100%', marginTop: 12 }} wrap>
          <Input
            allowClear
            value={q}
            onChange={(e) => setQ(e.target.value)}
            style={{ minWidth: 320 }}
            prefix={<SearchOutlined />}
            placeholder="جستجو در همه ستون‌ها (موضوع/رشته/شماره/تاریخ...)"
          />
        </Space>

        <Table
          style={{ marginTop: 12 }}
          size="small"
          rowKey="id"
          loading={listQ.isLoading}
          dataSource={rows}
          columns={columns}
          pagination={{ pageSize: 20, showSizeChanger: false }}
          onRow={(record) => ({
            onClick: (ev) => {
              // جلوگیری از باز شدن Drawer هنگام کلیک روی دکمه‌ها
              const tag = ev?.target?.tagName?.toLowerCase?.()
              if (tag === 'button' || tag === 'svg' || tag === 'path' || tag === 'a') return
              setDetailRow(record)
            },
          })}
        />
      </Card>

      <Drawer
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        width={520}
        title="افزودن بخشنامه"
      >
        <Form layout="vertical" form={form}>
          <Form.Item name="insurance_line" label="رشته" tooltip="مثلاً: شخص ثالث / بدنه / آتش‌سوزی ...">
            <Input />
          </Form.Item>
          <Form.Item name="subject" label="موضوع" rules={[{ required: true, message: 'موضوع الزامی است' }]}>
            <Input />
          </Form.Item>
          <Space style={{ width: '100%' }}>
            <Form.Item name="letter_no" label="شماره نامه" style={{ flex: 1 }}>
              <Input />
            </Form.Item>
            <Form.Item name="ref_no" label="شناسه نامه" style={{ flex: 1 }}>
              <Input />
            </Form.Item>
          </Space>
          <Form.Item name="circular_date_j" label="تاریخ (شمسی)" tooltip="می‌تونی تایپ کنی یا از تقویم انتخاب کنی">
            <DateJField formRef={form} name="circular_date_j" />
          </Form.Item>
          <Form.Item name="summary" label="خلاصه">
            <Input.TextArea rows={4} />
          </Form.Item>
          <Form.Item label="فایل‌ها (می‌تواند چند فایل باشد)" required>
            <Upload
              multiple
              maxCount={10}
              beforeUpload={() => false}
              fileList={selectedFiles}
              onChange={(info) => setSelectedFiles(info.fileList)}
              onPreview={async (file) => {
                const f = file?.originFileObj
                if (!f) return
                openPreviewFromBlob(f, file.name)
              }}
            >
              <Button icon={<UploadOutlined />}>انتخاب فایل‌ها</Button>
            </Upload>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              برای پیش‌نمایش روی اسم فایل کلیک کن.
            </Typography.Text>
          </Form.Item>

          <Button
            type="primary"
            loading={createMut.isPending}
            onClick={() => {
              const values = form.getFieldsValue()
              if (!values.subject) return message.error('موضوع را وارد کنید')
              if (!selectedFiles?.length) return message.error('حداقل یک فایل انتخاب کنید')

              const fd = new FormData()
              Object.keys(values).forEach((k) => {
                if (values[k] !== undefined && values[k] !== null && values[k] !== '') fd.append(k, values[k])
              })
              // FastAPI: files: list[UploadFile]
              selectedFiles.forEach((it) => {
                if (it?.originFileObj) fd.append('files', it.originFileObj)
              })
              createMut.mutate(fd)
            }}
          >
            ثبت
          </Button>
        </Form>
      </Drawer>

      {/* Drawer حرفه‌ای جزئیات */}
      <Drawer
        open={!!detailRow}
        onClose={() => setDetailRow(null)}
        width={760}
        title={detailRow ? `جزئیات بخشنامه` : 'جزئیات'}
        extra={
          detailRow ? (
            <Space wrap>
              <Button
                size="small"
                onClick={() => {
                  if (detailRow.is_read) markUnreadMut.mutate(detailRow.id)
                  else markReadMut.mutate(detailRow.id)
                }}
                loading={markReadMut.isPending || markUnreadMut.isPending}
              >
                {detailRow.is_read ? 'علامت‌گذاری خوانده‌نشده' : 'علامت‌گذاری خوانده‌شده'}
              </Button>
              <Button size="small" icon={<EditOutlined />} disabled={isMarketer} onClick={() => setEditRow(detailRow)}>
                ویرایش
              </Button>
              <Popconfirm
                title="حذف شود؟"
                okText="حذف"
                cancelText="انصراف"
                onConfirm={() => {
                  deleteMut.mutate(detailRow.id)
                  setDetailRow(null)
                }}
              >
                <Button size="small" danger icon={<DeleteOutlined />} disabled={isMarketer} loading={deleteMut.isPending}>
                  حذف
                </Button>
              </Popconfirm>
            </Space>
          ) : null
        }
      >
        {detailRow ? (
          <Space direction="vertical" size={10} style={{ width: '100%' }}>
            <Space style={{ width: '100%', justifyContent: 'space-between' }} wrap>
              <Typography.Title level={5} style={{ margin: 0, fontWeight: 900 }}>
                {detailRow.subject}
              </Typography.Title>
              {detailRow.is_read ? <Tag color="green">خوانده‌شده</Tag> : <Tag color="orange">جدید</Tag>}
            </Space>

            <Descriptions bordered size="small" column={2} styles={{ label: { width: 140 } }}>
              <Descriptions.Item label="رشته">{detailRow.insurance_line || '-'}</Descriptions.Item>
              <Descriptions.Item label="تاریخ (شمسی)">{detailRow.circular_date_j || '-'}</Descriptions.Item>
              <Descriptions.Item label="شماره نامه">{detailRow.letter_no || '-'}</Descriptions.Item>
              <Descriptions.Item label="شناسه نامه">{detailRow.ref_no || '-'}</Descriptions.Item>
              <Descriptions.Item label="تاریخ ثبت" span={2}>
                {detailRow.created_at ? new Date(detailRow.created_at).toLocaleString('fa-IR') : '-'}
              </Descriptions.Item>
            </Descriptions>

            <Tabs
              items={[
                {
                  key: 'summary',
                  label: 'خلاصه',
                  children: (
                    <Card size="small">
                      {detailRow.summary ? (
                        <Typography.Paragraph style={{ margin: 0, whiteSpace: 'pre-wrap' }}>
                          {detailRow.summary}
                        </Typography.Paragraph>
                      ) : (
                        <Typography.Text type="secondary">خلاصه‌ای ثبت نشده است.</Typography.Text>
                      )}
                    </Card>
                  ),
                },
                {
                  key: 'files',
                  label: `فایل‌ها (${Array.isArray(detailRow.files) ? detailRow.files.length : 0})`,
                  children: (
                    <Space direction="vertical" style={{ width: '100%' }} size={10}>
                      {(detailRow.files || []).map((f, idx) => (
                        <Card key={`${f.id ?? 'main'}-${idx}`} size="small">
                          <Space style={{ width: '100%', justifyContent: 'space-between' }} wrap>
                            <Typography.Text style={{ fontWeight: 700 }}>{f.file_name || `فایل ${idx + 1}`}</Typography.Text>
                            <Space>
                              <Button
                                size="small"
                                onClick={async () => {
                                  const blob = f.id
                                    ? await downloadCircularFileBlob(detailRow.id, f.id)
                                    : await downloadCircularBlob(detailRow.id)
                                  openPreviewFromBlob(blob, f.file_name || `circular_${detailRow.id}`)
                                  // auto-read در دانلود/پیش‌نمایش
                                  qc.invalidateQueries({ queryKey: ['circulars'] })
                                  qc.invalidateQueries({ queryKey: ['headerStats'] })
                                  setDetailRow((x) => (x ? { ...x, is_read: true } : x))
                                }}
                              >
                                پیش‌نمایش
                              </Button>
                              <Button
                                size="small"
                                icon={<FilePdfOutlined />}
                                onClick={async () => {
                                  const blob = f.id
                                    ? await downloadCircularFileBlob(detailRow.id, f.id)
                                    : await downloadCircularBlob(detailRow.id)
                                  downloadBlob(blob, f.file_name || `circular_${detailRow.id}`)
                                  qc.invalidateQueries({ queryKey: ['circulars'] })
                                  qc.invalidateQueries({ queryKey: ['headerStats'] })
                                  setDetailRow((x) => (x ? { ...x, is_read: true } : x))
                                }}
                              >
                                دانلود
                              </Button>
                            </Space>
                          </Space>
                        </Card>
                      ))}
                      {!detailRow.files?.length ? <Typography.Text type="secondary">فایلی یافت نشد.</Typography.Text> : null}
                      <Divider style={{ margin: '6px 0' }} />
                      <Typography.Text type="secondary" style={{ fontSize: 12 }}>
                        نکته: با پیش‌نمایش/دانلود، بخشنامه به صورت خودکار «خوانده‌شده» می‌شود.
                      </Typography.Text>
                    </Space>
                  ),
                },
              ]}
            />
          </Space>
        ) : null}
      </Drawer>

      <Modal
        open={preview.open}
        onCancel={closePreview}
        footer={null}
        width={900}
        title={preview.title}
        destroyOnClose
      >
        {/* تشخیص ساده: اگر URL blob و نام pdf داشتیم، iframe */}
        {preview.url ? (
          <div style={{ width: '100%' }}>
            {String(preview.title || '').toLowerCase().includes('.pdf') ? (
              <iframe title="preview" src={preview.url} style={{ width: '100%', height: '75vh', border: 'none' }} />
            ) : (
              <img alt="preview" src={preview.url} style={{ width: '100%', maxHeight: '75vh', objectFit: 'contain' }} />
            )}
          </div>
        ) : null}
      </Modal>

      <Drawer
        open={!!editRow}
        onClose={() => setEditRow(null)}
        width={520}
        title="ویرایش بخشنامه"
      >
        {editRow ? (
          <Form
            layout="vertical"
            form={editForm}
            initialValues={editRow}
            onFinish={(vals) => updateMut.mutate({ id: editRow.id, payload: vals })}
          >
            <Form.Item name="insurance_line" label="رشته">
              <Input />
            </Form.Item>
            <Form.Item name="subject" label="موضوع" rules={[{ required: true }]}>
              <Input />
            </Form.Item>
            <Space style={{ width: '100%' }}>
              <Form.Item name="letter_no" label="شماره نامه" style={{ flex: 1 }}>
                <Input />
              </Form.Item>
              <Form.Item name="ref_no" label="شناسه نامه" style={{ flex: 1 }}>
                <Input />
              </Form.Item>
            </Space>
            <Form.Item name="circular_date_j" label="تاریخ (شمسی)">
              <DateJField formRef={editForm} name="circular_date_j" />
            </Form.Item>
            <Form.Item name="summary" label="خلاصه">
              <Input.TextArea rows={4} />
            </Form.Item>

            <Divider style={{ margin: '10px 0' }} />
            <Typography.Title level={5} style={{ margin: 0 }}>فایل‌ها</Typography.Title>
            <Typography.Text type="secondary" style={{ fontSize: 12 }}>
              می‌تونی فایل جدید اضافه کنی یا فایل‌های قبلی را حذف کنی.
            </Typography.Text>

            <Space direction="vertical" style={{ width: '100%', marginTop: 10 }}>
              {(editRow.files || []).map((f) => (
                <Card key={String(f.id || f.file_name)} size="small" styles={{ body: { padding: 10 } }}>
                  <Space style={{ width: '100%', justifyContent: 'space-between' }}>
                    <Space>
                      <FilePdfOutlined />
                      <Typography.Text>{f.file_name || 'فایل'}</Typography.Text>
                    </Space>
                    <Space>
                      <Button
                        size="small"
                        onClick={async () => {
                          const blob = f.id
                            ? await downloadCircularFileBlob(editRow.id, f.id)
                            : await downloadCircularBlob(editRow.id)
                          openPreviewFromBlob(blob, f.file_name || `circular_${editRow.id}`)
                          markReadMut.mutate(editRow.id)
                        }}
                      >
                        پیش‌نمایش
                      </Button>
                      <Button
                        size="small"
                        onClick={async () => {
                          const blob = f.id
                            ? await downloadCircularFileBlob(editRow.id, f.id)
                            : await downloadCircularBlob(editRow.id)
                          downloadBlob(blob, f.file_name || `circular_${editRow.id}`)
                          markReadMut.mutate(editRow.id)
                        }}
                      >
                        دانلود
                      </Button>
                      {f.id ? (
                        <Popconfirm
                          title="حذف فایل"
                          description="این فایل حذف شود؟"
                          okText="حذف"
                          cancelText="انصراف"
                          onConfirm={async () => {
                            await deleteFileMut.mutateAsync({ id: editRow.id, fileId: f.id })
                            // refresh list locally
                            setEditRow((x) => (x ? { ...x, files: (x.files || []).filter((z) => z.id !== f.id) } : x))
                          }}
                        >
                          <Button danger size="small">حذف</Button>
                        </Popconfirm>
                      ) : null}
                    </Space>
                  </Space>
                </Card>
              ))}

              <Upload
                multiple
                maxCount={10}
                beforeUpload={() => false}
                fileList={editNewFiles}
                onChange={(info) => setEditNewFiles(info.fileList)}
              >
                <Button icon={<UploadOutlined />}>افزودن فایل جدید</Button>
              </Upload>
              <Button
                type="dashed"
                disabled={!editNewFiles?.length}
                loading={addFilesMut.isPending}
                onClick={() => {
                  if (!editNewFiles?.length) return
                  const fd = new FormData()
                  editNewFiles.forEach((it) => {
                    if (it?.originFileObj) fd.append('files', it.originFileObj)
                  })
                  addFilesMut.mutate({ id: editRow.id, fd })
                }}
              >
                ثبت فایل‌های جدید
              </Button>
            </Space>

            <Divider style={{ margin: '12px 0' }} />
            <Button type="primary" htmlType="submit" loading={updateMut.isPending}>
              ذخیره
            </Button>
          </Form>
        ) : null}
      </Drawer>
    </Space>
  )
}
