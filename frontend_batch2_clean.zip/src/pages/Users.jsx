import React, { useEffect, useMemo, useState } from 'react'
import { Button, Card, Form, Input, Select, Space, Table, Tag, message, Popconfirm } from 'antd'
import FormDrawer from '../components/FormDrawer'
import { listUsers, createUser, updateUser, deleteUser } from '../api/users'
import { useNavigate } from 'react-router-dom'

export default function UsersPage() {
  const nav = useNavigate()
  const [rows, setRows] = useState([])
  const [loading, setLoading] = useState(false)
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState(null)
  const [form] = Form.useForm()

  const me = useMemo(() => {
    try {
      return JSON.parse(localStorage.getItem('sama_user') || 'null')
    } catch {
      return null
    }
  }, [])
  const canHardDelete = me?.role === 'super_admin'

  async function refresh() {
    setLoading(true)
    try {
      const data = await listUsers()
      setRows(data)
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در دریافت کاربران')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    refresh()
  }, [])

  const columns = useMemo(() => [
    { title: 'نام', dataIndex: 'full_name' },
    { title: 'موبایل', dataIndex: 'mobile' },
    {
      title: 'نوع',
      dataIndex: 'user_type',
      render: (v) => {
        const map = { admin: 'مدیر', user: 'کاربر', marketer: 'بازاریاب' }
        return <Tag>{map[v] || v}</Tag>
      },
    },
    { title: 'کد', dataIndex: 'code' },
    { title: 'سمت', dataIndex: 'title' },
    {
      title: 'وضعیت',
      dataIndex: 'is_active',
      render: (v) => (v ? <Tag color="green">فعال</Tag> : <Tag color="red">غیرفعال</Tag>),
    },
    {
      title: 'عملیات',
      key: 'actions',
      render: (_, r) => (
        <Space>
          <Button size="small" onClick={() => {
            setEditing(r)
            form.setFieldsValue({
              full_name: r.full_name,
              mobile: r.mobile,
              user_type: r.user_type,
              code: r.code,
              title: r.title,
              is_active: r.is_active,
              password: '',
            })
            setOpen(true)
          }}>ویرایش</Button>

          <Popconfirm
            title="غیرفعال‌سازی کاربر"
            description="کاربر غیرفعال می‌شود و بعداً می‌توانی دوباره فعالش کنی."
            okText="غیرفعال کن"
            cancelText="انصراف"
            onConfirm={async () => {
              try {
                await deleteUser(r.id)
                message.success('غیرفعال شد')
                refresh()
              } catch (e) {
                message.error(e?.response?.data?.detail || 'خطا در غیرفعال‌سازی')
              }
            }}
          >
            <Button danger size="small">غیرفعال</Button>
          </Popconfirm>

          {canHardDelete && (
            <Popconfirm
              title="حذف کامل کاربر"
              description="این عملیات برگشت‌پذیر نیست و کاربر به صورت کامل حذف می‌شود."
              okText="حذف کامل"
              cancelText="انصراف"
              onConfirm={async () => {
                try {
                  await deleteUser(r.id, { hard: true })
                  message.success('حذف کامل انجام شد')
                  refresh()
                } catch (e) {
                  message.error(e?.response?.data?.detail || 'خطا در حذف کامل')
                }
              }}
            >
              <Button danger size="small" type="primary">حذف کامل</Button>
            </Popconfirm>
          )}
        </Space>
      ),
    },
  ], [form, canHardDelete])

  async function onSubmit(values) {
    try {
      const payload = { ...values }
      if (!payload.password) delete payload.password

      if (editing) {
        await updateUser(editing.id, payload)
        message.success('ویرایش شد')
      } else {
        await createUser(payload)
        message.success('ایجاد شد')
      }
      setOpen(false)
      setEditing(null)
      form.resetFields()
      refresh()
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا')
    }
  }

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card>
        <Space>
          <Button type="primary" onClick={() => { setEditing(null); form.resetFields(); form.setFieldsValue({ is_active: true, user_type: 'user' }); setOpen(true) }}>افزودن کاربر</Button>
          <Button onClick={refresh} loading={loading}>به‌روزرسانی</Button>
          <Button onClick={() => nav('/settings')}>سطوح دسترسی و لاگ فعالیت</Button>
        </Space>
      </Card>

      <Card>
        <Table
          rowKey="id"
          loading={loading}
          dataSource={rows}
          columns={columns}
          pagination={{ pageSize: 20 }}
          scroll={{ x: 900 }}
        />
      </Card>

      <FormDrawer
        title={editing ? 'ویرایش کاربر' : 'افزودن کاربر'}
        open={open}
        onClose={() => { setOpen(false); setEditing(null) }}
        onSubmit={() => form.submit()}
      >
        <Form form={form} layout="vertical" onFinish={onSubmit}>
          <Form.Item name="full_name" label="نام" rules={[{ required: true, message: 'نام الزامی است' }]}>
            <Input />
          </Form.Item>
          <Form.Item name="mobile" label="موبایل" rules={[{ required: true, message: 'موبایل الزامی است' }]}>
            <Input />
          </Form.Item>
          <Form.Item name="user_type" label="نوع" rules={[{ required: true, message: 'نوع کاربر را انتخاب کن' }]}>
            <Select options={[
              { value: 'admin', label: 'مدیر' },
              { value: 'user', label: 'کاربر' },
            ]} />
          </Form.Item>

          <Form.Item name="password" label="رمز" extra="برای تغییر یا تعیین رمز پر کن؛ اگر خالی باشد تغییری نمی‌کند.">
            <Input.Password />
          </Form.Item>
          <Form.Item name="code" label="کد">
            <Input />
          </Form.Item>
          <Form.Item name="title" label="سمت">
            <Input />
          </Form.Item>
          <Form.Item name="is_active" label="وضعیت" initialValue={true}>
            <Select options={[{ value: true, label: 'فعال' }, { value: false, label: 'غیرفعال' }]} />
          </Form.Item>
        </Form>
      </FormDrawer>
    </Space>
  )
}
