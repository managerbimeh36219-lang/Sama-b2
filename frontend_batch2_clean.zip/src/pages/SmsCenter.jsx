import React, { useMemo, useState } from 'react'
import { Button, Card, Drawer, Form, Input, Space, Table, Tabs, Tag, Typography, Switch, message } from 'antd'
import { useQuery, useQueryClient } from '@tanstack/react-query'

import { listInbox, listOutbox, sendSms, smsStatus, syncInbox, listSmsRules, updateSmsRule } from '../api/sms.js'

function statusTag(s) {
  if (s === 'sent') return <Tag color="blue">ارسال شد</Tag>
  if (s === 'delivered') return <Tag color="green">تحویل شد</Tag>
  if (s === 'failed') return <Tag color="red">ناموفق</Tag>
  if (s === 'received') return <Tag color="green">دریافت</Tag>
  return <Tag color="orange">در صف</Tag>
}

export default function SmsCenter() {
  const qc = useQueryClient()

  const { data: st } = useQuery({ queryKey: ['sms-status'], queryFn: smsStatus })

  const { data: inbox, isFetching: inboxLoading } = useQuery({
    queryKey: ['sms-inbox'],
    queryFn: listInbox,
  })

  const { data: outbox, isFetching: outboxLoading } = useQuery({
    queryKey: ['sms-outbox'],
    queryFn: listOutbox,
  })

  const { data: rules, isFetching: rulesLoading } = useQuery({
    queryKey: ['sms-rules'],
    queryFn: listSmsRules,
  })

  const [drawerOpen, setDrawerOpen] = useState(false)
  const [draftTo, setDraftTo] = useState('')
  const [draftBody, setDraftBody] = useState('')

  const inboxRows = useMemo(() => (inbox || []).map((x) => ({ ...x, key: x.id })), [inbox])
  const outboxRows = useMemo(() => (outbox || []).map((x) => ({ ...x, key: x.id })), [outbox])

  const openReply = (row) => {
    setDraftTo(String(row.from_number || ''))
    setDraftBody('')
    setDrawerOpen(true)
  }

  async function doSend() {
    const to = (draftTo || '').trim()
    const body = (draftBody || '').trim()
    if (!to) return message.error('شماره مقصد را وارد کنید')
    if (!body) return message.error('متن پیامک را وارد کنید')

    try {
      await sendSms({ to_number: to, body })
      message.success('ارسال انجام شد')
      setDrawerOpen(false)
      setDraftBody('')
      await qc.invalidateQueries({ queryKey: ['sms-outbox'] })
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در ارسال')
    }
  }

  async function doSync() {
    try {
      const r = await syncInbox()
      message.success(`همگام‌سازی انجام شد (جدید: ${r?.new_messages || 0})`)
      await qc.invalidateQueries({ queryKey: ['sms-inbox'] })
    } catch (e) {
      message.error(e?.response?.data?.detail || 'خطا در دریافت')
    }
  }

  const rulesRows = useMemo(() => (rules || []).map((r) => ({ ...r, key: r.id })), [rules])

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card className="sama-card" size="small">
        <Space wrap align="center" style={{ width: '100%', justifyContent: 'space-between' }}>
          <Space>
            <Typography.Text style={{ fontWeight: 800 }}>پیامک</Typography.Text>
            {st?.enabled ? <Tag color="green">فعال</Tag> : <Tag color="red">غیرفعال</Tag>}
            {st?.enabled ? <Typography.Text type="secondary">خط: {st?.from_number}</Typography.Text> : null}
          </Space>
          <Space>
            <Button onClick={() => { setDraftTo(''); setDraftBody(''); setDrawerOpen(true) }} type="primary">ارسال پیام جدید</Button>
            <Button onClick={doSync} loading={inboxLoading}>دریافت پیام‌ها</Button>
          </Space>
        </Space>
      </Card>

      <Tabs
        defaultActiveKey="inbox"
        items={[
          {
            key: 'inbox',
            label: 'دریافتی',
            children: (
              <Card className="sama-card" size="small">
                <Table
                  size="small"
                  loading={inboxLoading}
                  dataSource={inboxRows}
                  pagination={{ pageSize: 20 }}
                  columns={[
                    { title: 'از', dataIndex: 'from_number', key: 'from_number', width: 140 },
                    { title: 'به', dataIndex: 'to_number', key: 'to_number', width: 140 },
                    { title: 'متن', dataIndex: 'body', key: 'body', ellipsis: true },
                    { title: 'وضعیت', dataIndex: 'status', key: 'status', width: 90, render: (v) => statusTag(v) },
                    { title: 'عملیات', key: 'actions', width: 120, render: (_, row) => (
                      <Button size="small" onClick={() => openReply(row)}>پاسخ</Button>
                    )},
                  ]}
                  tableLayout="fixed"
                />
              </Card>
            ),
          },
          {
            key: 'outbox',
            label: 'ارسالی',
            children: (
              <Card className="sama-card" size="small">
                <Table
                  size="small"
                  loading={outboxLoading}
                  dataSource={outboxRows}
                  pagination={{ pageSize: 20 }}
                  columns={[
                    { title: 'به', dataIndex: 'to_number', key: 'to_number', width: 140 },
                    { title: 'متن', dataIndex: 'body', key: 'body', ellipsis: true },
                    { title: 'وضعیت', dataIndex: 'status', key: 'status', width: 90, render: (v) => statusTag(v) },
                    { title: 'کد پنل', dataIndex: 'provider_message_id', key: 'provider_message_id', width: 120, render: (v) => v || '-' },
                    { title: 'خطا', dataIndex: 'error', key: 'error', width: 220, ellipsis: true, render: (v) => v || '-' },
                  ]}
                  tableLayout="fixed"
                />
              </Card>
            ),
          },
          {
            key: 'rules',
            label: 'ارسال اتوماتیک',
            children: (
              <Card className="sama-card" size="small">
                <Table
                  size="small"
                  loading={rulesLoading}
                  dataSource={rulesRows}
                  pagination={false}
                  columns={[
                    { title: 'عنوان', dataIndex: 'title', key: 'title' },
                    { title: 'کلید', dataIndex: 'key', key: 'key', width: 170 },
                    {
                      title: 'فعال',
                      dataIndex: 'is_enabled',
                      key: 'is_enabled',
                      width: 90,
                      render: (v, row) => (
                        <Switch
                          checked={!!v}
                          onChange={async (checked) => {
                            try {
                              await updateSmsRule(row.id, { is_enabled: checked })
                              message.success('ذخیره شد')
                              await qc.invalidateQueries({ queryKey: ['sms-rules'] })
                            } catch (e) {
                              message.error(e?.response?.data?.detail || 'خطا')
                            }
                          }}
                        />
                      ),
                    },
                    {
                      title: 'تنظیمات (JSON)',
                      dataIndex: 'config_json',
                      key: 'config_json',
                      ellipsis: true,
                      render: (v, row) => (
                        <Input.TextArea
                          defaultValue={v || '{}'}
                          rows={2}
                          onBlur={async (ev) => {
                            const val = ev.target.value || '{}'
                            try {
                              await updateSmsRule(row.id, { config_json: val })
                              message.success('ذخیره شد')
                              await qc.invalidateQueries({ queryKey: ['sms-rules'] })
                            } catch (e) {
                              message.error(e?.response?.data?.detail || 'JSON نامعتبر یا خطا')
                            }
                          }}
                        />
                      ),
                    },
                  ]}
                  tableLayout="fixed"
                />

                <Typography.Paragraph type="secondary" style={{ marginTop: 12 }}>
                  نکته: تنظیمات هر قانون به صورت JSON ذخیره می‌شود. مثال‌ها:
                  <br />
                  <Typography.Text code>{'{"days_after_due":[1,3,7],"template_key":"installment_overdue"}'}</Typography.Text>
                  <br />
                  <Typography.Text code>{'{"days_before_end":[30,7,1],"template_key":"renewal_reminder"}'}</Typography.Text>
                  <br />
                  <Typography.Text code>{'{"hour":9,"minute":0,"template_key":"birthday"}'}</Typography.Text>
                </Typography.Paragraph>
              </Card>
            ),
          },
        ]}
      />

      <Drawer
        title="ارسال پیامک"
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        width={520}
        destroyOnClose
      >
        <Space direction="vertical" size={10} style={{ width: '100%' }}>
          {!st?.enabled ? (
            <Typography.Text type="danger">
              پنل پیامکی هنوز تنظیم نشده است. فعلاً پیامک‌ها با وضعیت «ناموفق» ثبت می‌شوند.
            </Typography.Text>
          ) : null}
          <Form layout="vertical">
            <Form.Item label="شماره مقصد">
              <Input value={draftTo} onChange={(e) => setDraftTo(e.target.value)} placeholder="09..." />
            </Form.Item>
            <Form.Item label="متن پیامک">
              <Input.TextArea value={draftBody} onChange={(e) => setDraftBody(e.target.value)} rows={5} />
            </Form.Item>
            <Button type="primary" onClick={doSend} block>
              ارسال
            </Button>
          </Form>
        </Space>
      </Drawer>
    </Space>
  )
}
