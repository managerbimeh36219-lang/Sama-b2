import { create } from 'zustand'
import { persist } from 'zustand/middleware'

export const useAppStore = create(persist((set) => ({
  user: null,
  ui: null,
  viewport: 'desktop',
  setUser: (user) => set({ user }),
  setUi: (ui) => set({ ui }),
  setViewport: (viewport) => set({ viewport }),
}), { name: 'sama_app_v2' }))
