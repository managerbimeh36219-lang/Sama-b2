// فرمت‌های ساده برای نمایش اعداد/مبالغ در UI

export function formatRial(value) {
  if (value == null) return '-'
  const n = Number(value)
  if (!Number.isFinite(n)) return String(value)
  // جداکننده هزارگان + پسوند ریال
  return n.toLocaleString('fa-IR') + ' ریال'
}
