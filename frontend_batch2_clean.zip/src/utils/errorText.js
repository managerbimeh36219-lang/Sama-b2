export function errorToText(err, fallback = 'خطا') {
  try {
    const data = err?.response?.data
    const detail = data?.detail ?? data
    if (!detail) return fallback

    if (typeof detail === 'string') return detail

    // FastAPI validation errors: {detail: [{loc, msg, type, ...}, ...]}
    if (Array.isArray(detail)) {
      const msgs = detail
        .map((x) => {
          if (typeof x === 'string') return x
          const loc = Array.isArray(x?.loc) ? x.loc.join('.') : ''
          const msg = x?.msg || x?.message || JSON.stringify(x)
          return loc ? `${loc}: ${msg}` : msg
        })
        .filter(Boolean)
      return msgs.length ? msgs.join(' | ') : fallback
    }

    // object
    if (typeof detail === 'object') {
      if (detail?.message && typeof detail.message === 'string') return detail.message
      return JSON.stringify(detail)
    }
  } catch {
    // ignore
  }
  return fallback
}
