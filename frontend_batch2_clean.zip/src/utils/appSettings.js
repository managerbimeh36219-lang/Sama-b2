export const SETTINGS_KEY = 'sama_settings_v1'

export function loadSettings() {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY)
    if (!raw) {
      return {
        insuranceLines: [
          'شخص ثالث','بدنه سواری','بدنه بارکش','بدنه مسافربر','حوادث','مسئولیت',
          'آتش سوزی مسکونی','آتش سوزی غیرصنعتی','آتش سوزی حامی','آتش سوزی اصناف','آتش سوزی صنعتی',
          'باربری وارداتی','باربری صادراتی و داخلی','عمر','مهندسی','AXA',
        ],
        marketers: [],
        dashboardWidgets: {
          kpi: true,
          dueToday: true,
          renew7: true,
          chartPayments: true,
        },
      }
    }
    return JSON.parse(raw)
  } catch {
    return { insuranceLines: ['شخص ثالث'], marketers: [],
        dashboardWidgets: { kpi: true } }
  }
}

export function saveSettings(next) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(next))
}

export function getInsuranceLines() {
  return loadSettings().insuranceLines || []
}


export function getMarketers() {
  return loadSettings().marketers || []
}
