import { useEffect, useState } from 'react'

/**
 * نگهداری state صفحه در sessionStorage تا وقتی کاربر بین صفحات می‌رود و برمی‌گردد،
 * وضعیت (فیلتر/سورت/صفحه‌بندی/...) از بین نرود.
 */
export function useSessionState(key, initialValue) {
  const storageKey = `sama:${key}`

  const [value, setValue] = useState(() => {
    try {
      const raw = sessionStorage.getItem(storageKey)
      if (raw == null) return initialValue
      return JSON.parse(raw)
    } catch {
      return initialValue
    }
  })

  useEffect(() => {
    try {
      sessionStorage.setItem(storageKey, JSON.stringify(value))
    } catch {
      // ignore
    }
  }, [storageKey, value])

  return [value, setValue]
}

export function useDebouncedValue(value, delayMs = 350) {
  const [debounced, setDebounced] = useState(value)
  useEffect(() => {
    const t = setTimeout(() => setDebounced(value), delayMs)
    return () => clearTimeout(t)
  }, [value, delayMs])
  return debounced
}
