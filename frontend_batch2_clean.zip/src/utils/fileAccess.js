import { http } from "../api/http";

// دریافت فایل به صورت Blob با هدرهای احراز هویت (Authorization + X-Tenant-Id)
export async function fetchFileBlob(fileUrl) {
  const res = await http.get(fileUrl, { responseType: "blob" });
  return res.data;
}

// سازگاری با کدهای قبلی (fetchBlob)
export const fetchBlob = fetchFileBlob;

export function blobToObjectUrl(blob) {
  return URL.createObjectURL(blob);
}

export function downloadBlob(blob, filename = "file") {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1200);
}
