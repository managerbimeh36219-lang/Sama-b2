import React from 'react'
import { Checkbox, Input, Space, Typography } from 'antd'

// Google-Sheets-like column filter dropdown (search + tick values)
export function makeGsColumnFilter({
  key,
  getValues,
  renderValue,
}) {
  return {
    filterDropdown: ({ setSelectedKeys, selectedKeys, confirm, clearFilters }) => {
      const sel = Array.isArray(selectedKeys) ? selectedKeys : []
      const allValues = getValues()
      const [search, setSearch] = React.useState('')
      const shown = allValues.filter((v) =>
        String(v ?? '')
          .toLowerCase()
          .includes(search.toLowerCase())
      )

      return (
        <div style={{ padding: 10, width: 260 }}>
          <Space direction="vertical" size={8} style={{ width: '100%' }}>
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="جستجو در مقادیر ستون"
              allowClear
            />
            <Checkbox
              checked={sel.length === 0}
              onChange={() => {
                setSelectedKeys([])
                confirm({ closeDropdown: false })
              }}
            >
              همه
            </Checkbox>
            <div style={{ maxHeight: 220, overflow: 'auto', paddingRight: 4 }}>
              <Checkbox.Group
                value={sel}
                onChange={(vals) => {
                  setSelectedKeys(vals)
                  confirm({ closeDropdown: false })
                }}
              >
                <Space direction="vertical" size={6} style={{ width: '100%' }}>
                  {shown.map((v) => (
                    <Checkbox key={String(v)} value={v}>
                      <Typography.Text ellipsis style={{ maxWidth: 200, display: 'inline-block' }}>
                        {renderValue ? renderValue(v) : String(v ?? '—')}
                      </Typography.Text>
                    </Checkbox>
                  ))}
                </Space>
              </Checkbox.Group>
            </div>
            <a
              onClick={() => {
                clearFilters?.()
                confirm()
              }}
            >
              پاک کردن
            </a>
          </Space>
        </div>
      )
    },
    onFilter: (value, record) => {
      // selectedKeys empty => no filtering
      if (value === undefined || value === null) return true
      const v = record[key]
      return String(v ?? '') === String(value)
    },
  }
}

export function uniq(values) {
  const s = new Set()
  for (const v of values) {
    const k = String(v ?? '')
    if (!k) continue
    s.add(v)
  }
  return Array.from(s)
}
