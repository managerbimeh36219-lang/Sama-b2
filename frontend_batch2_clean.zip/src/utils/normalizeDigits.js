// تبدیل اعداد فارسی/عربی به انگلیسی برای ورودی‌های عددی (مثل InputNumber)
export function normalizeDigits(value) {
  if (value === null || value === undefined) return value
  const s = String(value)
  const fa = '۰۱۲۳۴۵۶۷۸۹'
  const ar = '٠١٢٣٤٥٦٧٨٩'
  let out = ''
  for (const ch of s) {
    const iFa = fa.indexOf(ch)
    if (iFa >= 0) {
      out += String(iFa)
      continue
    }
    const iAr = ar.indexOf(ch)
    if (iAr >= 0) {
      out += String(iAr)
      continue
    }
    out += ch
  }
  return out
}
