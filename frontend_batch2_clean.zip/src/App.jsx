import React, { useEffect, useMemo } from 'react'
import { ConfigProvider, theme as antdTheme, App as AntdApp } from 'antd'
import faIR from 'antd/locale/fa_IR'
import { Route, Routes, useLocation, useNavigate } from 'react-router-dom'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Guide from './pages/Guide'
import Policies from './pages/Policies'
import InstallmentsCenter from './pages/InstallmentsCenter'
import RenewalsCenter from './pages/RenewalsCenter'
import Docs from './pages/Docs'
import DebtCenter from './pages/DebtCenter'
import TasksCenter from './pages/TasksCenter'
import SmsCenter from './pages/SmsCenter'
import CommissionCenter from './pages/CommissionCenter'
import RequestsInbox from './pages/RequestsInbox'
import NotificationsCenter from './pages/NotificationsCenter'
import ImportCenter from './pages/ImportCenter'
import Settings from './pages/Settings'
import SettingsUi from './pages/SettingsUi'
import SettingsChecklist from './pages/SettingsChecklist'
import SettingsRates from './pages/SettingsRates'
import SettingsFinancial from './pages/SettingsFinancial'
import Users from './pages/Users'
import Marketers from './pages/Marketers'
import BackupCenter from './pages/BackupCenter'
import Circulars from './pages/Circulars'
import CustomerPortal from './pages/CustomerPortal'
import ReceiptsReview from './pages/ReceiptsReview'
import AppLayout from './layout/AppLayout'
import { me } from './api/auth'
import { getUiPublic } from './api/settings'
import { useAppStore } from './store/appStore'
import SettingsInsuranceLines from "./pages/SettingsInsuranceLines";

export default function App(){
  const loc = useLocation()
  const nav = useNavigate()
  const { setUser, user, ui, setUi } = useAppStore()

  useEffect(() => {
    (async () => {
      try {
        const publicUi = await getUiPublic()
        setUi(publicUi)
      } catch {}
      const token = localStorage.getItem('token')
      if (!token) return
      try {
        const u = await me()
        setUser(u)
      } catch {
        localStorage.removeItem('token')
      }
    })()
  }, [])

  useEffect(() => {
    const token = localStorage.getItem('token')
    if (!token && !loc.pathname.startsWith('/login')) nav('/login')
  }, [loc.pathname])

  // Customer guard: force customer to use customer portal (avoid 403 on admin pages)
  useEffect(() => {
    if (user?.user_type === 'customer') {
      const p = loc.pathname
      const allowed = p.startsWith('/customer') || p.startsWith('/login') || p.startsWith('/guide')
      if (!allowed) nav('/customer', { replace: true })
    }
  }, [user?.user_type, loc.pathname])

  const algorithm = (ui?.theme || 'dark') === 'light' ? antdTheme.defaultAlgorithm : antdTheme.darkAlgorithm
  const token = useMemo(() => ({
    colorPrimary: ui?.accent_color || undefined,
    borderRadius: 12,
  }), [ui?.accent_color])

  const wrap = (child) => (
    <ConfigProvider locale={faIR} direction="rtl" theme={{ algorithm, token }}>
      <AntdApp>
        {child}
      </AntdApp>
    </ConfigProvider>
  )

  if (loc.pathname.startsWith('/login')) return wrap(<Login />)

  return wrap(
    <AppLayout>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/import" element={user?.user_type === 'admin' ? <ImportCenter /> : <Dashboard />} />
        <Route path="/customer" element={<CustomerPortal />} />
        <Route path="/guide" element={<Guide />} />

        <Route path="/requests" element={user?.user_type === 'customer' ? <CustomerPortal /> : <RequestsInbox />} />
        <Route path="/notifications" element={user?.user_type === 'customer' ? <CustomerPortal /> : <NotificationsCenter />} />
        <Route path="/policies" element={user?.user_type === 'customer' ? <CustomerPortal /> : <Policies />} />
        <Route path="/installments" element={user?.user_type === 'customer' ? <CustomerPortal /> : <InstallmentsCenter />} />
        <Route path="/renewals" element={user?.user_type === 'customer' ? <CustomerPortal /> : <RenewalsCenter />} />
        <Route path="/docs" element={user?.user_type === 'customer' ? <CustomerPortal /> : <Docs />} />
        <Route path="/debts" element={user?.user_type === 'marketer' ? <Dashboard /> : <DebtCenter />} />
        <Route path="/tasks" element={<TasksCenter />} />
        <Route path="/sms" element={user?.user_type === 'marketer' ? <Dashboard /> : <SmsCenter />} />
        <Route path="/commissions" element={user?.user_type === 'marketer' ? <Dashboard /> : <CommissionCenter />} />
        <Route path="/receipts-review" element={user?.user_type === 'marketer' ? <Dashboard /> : <ReceiptsReview />} />

        <Route path="/settings" element={<Settings />} />
        <Route path="/settings/ui" element={<SettingsUi />} />
        <Route path="/settings/users" element={<Users />} />
        <Route path="/settings/marketers" element={<Marketers />} />
        <Route path="/settings/checklist" element={<SettingsChecklist />} />
        <Route path="/settings/insurance-lines" element={<SettingsInsuranceLines />} />
        <Route path="/settings/lines" element={<SettingsInsuranceLines />} />
        <Route path="/settings/rates" element={<SettingsRates />} />
        <Route path="/settings/financial" element={<SettingsFinancial />} />
        <Route path="/settings/backup" element={<BackupCenter />} />

        <Route path="/circulars" element={<Circulars />} />
        <Route path="*" element={user?.user_type === 'customer' ? <CustomerPortal /> : <Dashboard />} />
      </Routes>
    </AppLayout>
  )
}
