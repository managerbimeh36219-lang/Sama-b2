import { http } from "./http.js"

export async function listNotifications(unreadOnly = false) {
  const { data } = await http.get('/notifications', { params: { unread_only: unreadOnly } })
  return data
}

export async function markNotificationRead(id) {
  const { data } = await http.post(`/notifications/${id}/read`)
  return data
}
