import { http } from './http.js'

export async function smsStatus() {
  const { data } = await http.get('/sms/status')
  return data
}

export async function listInbox() {
  const { data } = await http.get('/sms/inbox')
  return data
}

export async function listOutbox() {
  const { data } = await http.get('/sms/outbox')
  return data
}

export async function syncInbox() {
  const { data } = await http.post('/sms/inbox/sync')
  return data
}

export async function sendSms(payload) {
  const { data } = await http.post('/sms/send', payload)
  return data
}

export async function listSmsRules() {
  const { data } = await http.get('/sms/rules')
  return data
}

export async function updateSmsRule(rule_id, payload) {
  const { data } = await http.patch(`/sms/rules/${rule_id}`, payload)
  return data
}
