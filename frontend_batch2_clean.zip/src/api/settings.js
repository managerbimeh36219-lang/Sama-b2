import { http } from './http'

export async function getUiPublic(){
  const { data } = await http.get('/settings/ui-public')
  return data
}

export async function getUi(){
  const { data } = await http.get('/settings/ui')
  return data
}

export async function setUi(payload){
  const { data } = await http.put('/settings/ui', payload)
  return data
}

export async function uploadLoginBackground(file){
  const fd = new FormData()
  fd.append('file', file)
  const { data } = await http.post('/settings/ui/login-background', fd, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
  return data
}
// Session timeout (minutes)
export async function getSessionTimeout() {
  const { data } = await http.get("/settings/session-timeout")
  return data
}

export async function setSessionTimeout(minutes) {
  const { data } = await http.put("/settings/session-timeout", { minutes })
  return data
}

// SMS config (tenant-level)
export async function getSmsConfig() {
  const { data } = await http.get('/settings/sms-config')
  return data
}

export async function setSmsConfig(payload) {
  const { data } = await http.put('/settings/sms-config', payload)
  return data
}

// VAT rates
export async function getVatRates() {
  const { data } = await http.get("/settings/vat-rates")
  return data
}

export async function saveVatRates(rates) {
  // rates: [{ effective_from_j, rate_percent }]
  const { data } = await http.put("/settings/vat-rates", { items: rates })
  return data
}

// Marketer commission share rules
export async function getMarketerCommissionRules(params = {}) {
  const { data } = await http.get('/settings/marketer-commission-rules', { params })
  return data
}

export async function saveMarketerCommissionRules(items) {
  const { data } = await http.put('/settings/marketer-commission-rules', { items })
  return data
}