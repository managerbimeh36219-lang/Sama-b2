import { http } from './http'

export async function listBackups() {
  const res = await http.get('/backups')
  return res.data
}

export async function createBackup(name) {
  const res = await http.post('/backups', { name })
  return res.data
}

export async function restoreBackup(id) {
  const res = await http.post(`/backups/${id}/restore`)
  return res.data
}

// دانلود بکاپ به صورت JSON (blob)
export async function downloadBackup(id) {
  const res = await http.get(`/backups/${id}/download`, { responseType: 'blob' })
  return res.data
}
