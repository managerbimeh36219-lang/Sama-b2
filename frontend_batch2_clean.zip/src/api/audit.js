import { http } from './http'

export async function listAuditEvents(params = {}) {
  const { data } = await http.get('/audit/events', { params })
  return data
}
