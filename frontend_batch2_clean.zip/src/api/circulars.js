import { http } from './http'

export async function listCirculars(q) {
  const res = await http.get('/circulars', { params: q ? { q } : {} })
  return res.data
}

export async function createCircular(formData) {
  const res = await http.post('/circulars', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return res.data
}

export async function updateCircular(id, payload) {
  const res = await http.put(`/circulars/${id}`, payload)
  return res.data
}

export async function deleteCircular(id) {
  const res = await http.delete(`/circulars/${id}`)
  return res.data
}

export async function markCircularRead(id) {
  const res = await http.post(`/circulars/${id}/read`)
  return res.data
}

export async function markCircularUnread(id) {
  const res = await http.post(`/circulars/${id}/unread`)
  return res.data
}

export async function downloadCircularBlob(id) {
  const res = await http.get(`/circulars/${id}/download`, { responseType: 'blob' })
  return res.data
}

export async function downloadCircularFileBlob(id, fileId) {
  const res = await http.get(`/circulars/${id}/files/${fileId}/download`, { responseType: 'blob' })
  return res.data
}

export async function addCircularFiles(id, formData) {
  const res = await http.post(`/circulars/${id}/files`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  })
  return res.data
}

export async function deleteCircularFile(id, fileId) {
  const res = await http.delete(`/circulars/${id}/files/${fileId}`)
  return res.data
}
