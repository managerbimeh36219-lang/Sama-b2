import { http } from './http';

export const commissionsApi = {
  listVatRates() {
    return http.get('/commissions/vat-rates').then(r => r.data);
  },

  upsertVatRate(payload) {
    return http.post('/commissions/vat-rates', payload).then(r => r.data);
  },

  listCommissionRates() {
    return http.get('/commissions/rates').then(r => r.data);
  },

  upsertCommissionRate(payload) {
    return http.post('/commissions/rates', payload).then(r => r.data);
  },

  getReport(params) {
    return http.get('/commissions/report', { params }).then(r => r.data);
  },

  updateCommission(id, payload) {
    return http.put(`/commissions/${id}`, payload).then(r => r.data);
  },

  createStatement(payload) {
    return http.post('/commissions/statements', payload).then(r => r.data);
  },

  listStatements(params) {
    return http.get('/commissions/statements', { params }).then(r => r.data);
  },

  voidStatement(id) {
    return http
      .delete(`/commissions/statements/${id}`, { params: { mode: 'void' } })
      .then(r => r.data);
  },

  deleteStatement(id) {
    return http
      .delete(`/commissions/statements/${id}`, { params: { mode: 'delete' } })
      .then(r => r.data);
  },

  async downloadStatementBlob(id, format = 'xlsx') {
    const res = await http.get(
      `/commissions/statements/${id}/download`,
      { params: { format }, responseType: 'blob' }
    );
    return res.data;
  },

  async uploadReceipt(id, file) {
    const fd = new FormData();
    const raw = file && file.originFileObj ? file.originFileObj : file;
    const fileName = raw && raw.name ? raw.name : 'receipt';
    fd.append('file', raw, fileName);

    const res = await http.post(
      `/commissions/statements/${id}/receipt`,
      fd
    );
    return res.data;
  },

  async downloadReceiptBlob(id) {
    const res = await http.get(
      `/commissions/statements/${id}/receipt`,
      { responseType: 'blob' }
    );
    return res.data;
  },

  listInsuranceLines() {
    return http.get('/commissions/insurance-lines').then(r => r.data);
  },

  saveInsuranceLinesBatch(payload) {
    return http
      .post('/commissions/insurance-lines/batch', payload)
      .then(r => r.data);
  },
};