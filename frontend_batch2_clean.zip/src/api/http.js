import axios from 'axios'

export const http = axios.create({
  baseURL: '/api',
})

http.interceptors.request.use((config) => {
  // هم نسخه‌های جدید هم قدیمی
  const token =
    localStorage.getItem('sama_token') ||
    localStorage.getItem('token') ||
    localStorage.getItem('access_token')

  if (token && token !== 'undefined' && token !== 'null') {
    config.headers.Authorization = `Bearer ${token}`
  } else {
    delete config.headers.Authorization
  }

  const tenantId = localStorage.getItem('tenant_id') || '1'
  config.headers['X-Tenant-Id'] = tenantId
  return config
})

// مدیریت خطاهای عمومی (خصوصاً 401)
http.interceptors.response.use(
  (res) => res,
  (err) => {
    try {
      const status = err?.response?.status
      if (status === 401) {
        // توکن نامعتبر/منقضی
        localStorage.removeItem('sama_token')
        localStorage.removeItem('token')
        localStorage.removeItem('access_token')
        // اگر داخل صفحه لاگین نیستیم، هدایت شود
        if (typeof window !== 'undefined') {
          const p = window.location?.pathname || ''
          if (!p.startsWith('/login')) window.location.href = '/login'
        }
      }
    } catch {
      // ignore
    }
    return Promise.reject(err)
  }
)

// for legacy imports: `import http from './http'`
export default http
