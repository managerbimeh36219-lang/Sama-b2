import { http } from "./http.js"

export async function listRequests(params = {}) {
  const { data } = await http.get('/requests', { params })
  return data
}

export async function getRequest(id) {
  const { data } = await http.get(`/requests/${id}`)
  return data
}

export async function createRequest(payload) {
  const { data } = await http.post('/requests', payload)
  return data
}

export async function addRequestMessage(requestId, payload) {
  const { data } = await http.post(`/requests/${requestId}/messages`, payload)
  return data
}

export async function uploadRequestFile(requestId, messageId, file) {
  const form = new FormData()
  const raw = file?.originFileObj || file
  // Ant UploadFile wrapper -> use originFileObj
  form.append('file', raw, raw?.name || file?.name || 'file')
  const { data } = await http.post(`/requests/${requestId}/messages/${messageId}/files`, form)
  return data
}

export function getRequestFileUrl(fileId) {
  return `/requests/files/${fileId}`
}
