import { http } from './http'

export async function listRoles() {
  const { data } = await http.get('/rbac/roles')
  return data
}

export async function createRole(payload) {
  const { data } = await http.post('/rbac/roles', payload)
  return data
}

export async function listPermissions() {
  const { data } = await http.get('/rbac/permissions')
  return data
}

export async function getRolePerms(roleId) {
  const { data } = await http.get(`/rbac/roles/${roleId}/permissions`)
  return data
}

export async function setRolePerms(roleId, payload) {
  const { data } = await http.put(`/rbac/roles/${roleId}/permissions`, payload)
  return data
}


export async function setUserRole(userId, payload) {
  const { data } = await http.put(`/rbac/users/${userId}/role`, payload)
  return data
}

export async function setUserPerms(userId, payload) {
  const { data } = await http.put(`/rbac/users/${userId}/permissions`, payload)
  return data
}

export async function getUserAccess(userId) {
  const { data } = await http.get(`/rbac/users/${userId}/access`)
  return data
}

export async function setUserAccess(userId, payload) {
  const { data } = await http.put(`/rbac/users/${userId}/access`, payload)
  return data
}
