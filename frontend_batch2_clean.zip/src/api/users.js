import { http } from "./http.js"

export async function listUsers() {
  const { data } = await http.get('/users')
  return data
}

export async function createUser(payload) {
  const { data } = await http.post('/users', payload)
  return data
}

export async function updateUser(id, payload) {
  const { data } = await http.patch(`/users/${id}`, payload)
  return data
}

export async function deleteUser(id, opts = {}) {
  const params = {}
  if (opts?.hard) params.hard = true
  const { data } = await http.delete(`/users/${id}`, { params })
  return data
}
