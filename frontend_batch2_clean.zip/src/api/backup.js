import { http } from './http'

export async function listBackups() {
  const { data } = await http.get('/backup')
  return data
}

export async function createBackup() {
  const { data } = await http.post('/backup')
  return data
}

export function getBackupDownloadUrl(name) {
  return `/backup/${encodeURIComponent(name)}/download`
}

export async function restoreBackup(name) {
  const { data } = await http.post(`/backup/${encodeURIComponent(name)}/restore`, { confirm: true })
  return data
}
