import { http } from './http'

export async function getUserSetting(key) {
  const { data } = await http.get(`/user-settings/${encodeURIComponent(key)}`)
  return data
}

export async function setUserSetting(key, value) {
  const { data } = await http.put(`/user-settings/${encodeURIComponent(key)}`, { value })
  return data
}
