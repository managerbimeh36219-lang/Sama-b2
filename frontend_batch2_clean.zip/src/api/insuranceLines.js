import { http } from './http'

// لیست رشته‌های بیمه (از بک‌اند سما)
export async function listInsuranceLines(params = {}) {
  const res = await http.get('/commissions/insurance-lines', { params })
  return res.data
}
