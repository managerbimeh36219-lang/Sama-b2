import { http } from './http'

export async function listDocumentRequirements(params = {}) {
  const res = await http.get('/documents/requirements', { params })
  return res.data
}

export async function createDocumentRequirement(payload) {
  const res = await http.post('/documents/requirements', payload)
  return res.data
}

export async function updateDocumentRequirement(id, payload) {
  const res = await http.patch(`/documents/requirements/${id}`, payload)
  return res.data
}

export async function deleteDocumentRequirement(id) {
  const res = await http.delete(`/documents/requirements/${id}`)
  return res.data
}

export async function getPolicyDocumentsChecklist(policyId) {
  const res = await http.get(`/documents/policies/${policyId}/checklist`)
  return res.data
}

export async function uploadPolicyDocument({ policyId, requirementId, file, notes, uploadedBy }) {
  const form = new FormData()
  if (requirementId !== null && requirementId !== undefined) form.append('requirement_id', String(requirementId))
  if (notes) form.append('notes', notes)
  if (uploadedBy) form.append('uploaded_by', uploadedBy)
  const raw = file?.originFileObj || file
  form.append('file', raw, raw?.name || file?.name || 'file')

  // Do not set Content-Type manually; browser/axios will set proper boundary.
  const res = await http.post(`/documents/policies/${policyId}/upload`, form)
  return res.data
}

export function getDownloadUrl(docId) {
  // backend returns file with Content-Disposition
  return `${http.defaults.baseURL}/documents/files/${docId}`
}

export async function deletePolicyDocument(docId) {
  const res = await http.delete(`/documents/files/${docId}`)
  return res.data
}

export async function listDocumentFollowups(policyId) {
  const res = await http.get(`/documents/policies/${policyId}/followups`)
  return res.data
}

export async function createDocumentFollowup(policyId, payload) {
  const res = await http.post(`/documents/policies/${policyId}/followups`, payload)
  return res.data
}
