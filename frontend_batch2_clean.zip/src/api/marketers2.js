import { http } from "./http.js"

export async function listMarketers() {
  const { data } = await http.get('/marketers')
  return data
}

export async function createMarketer(payload) {
  const { data } = await http.post('/marketers', payload)
  return data
}

export async function updateMarketer(id, payload) {
  const { data } = await http.patch(`/marketers/${id}`, payload)
  return data
}

export async function deleteMarketer(id) {
  const { data } = await http.delete(`/marketers/${id}`)
  return data
}

export async function setMarketerPassword(id, password) {
  const { data } = await http.post(`/marketers/${id}/set-password`, { password })
  return data
}
