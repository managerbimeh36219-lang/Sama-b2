import { http } from './http.js'

export async function fetchInstallments({
  status='all',
  q='',
  due_from,
  due_to,
  is_system='all',
  insurance_line,
  sort_by,
  sort_dir,
  page,
  page_size,
} = {}) {
  const res = await http.get('/installments', {
    params: {
      status,
      q: q || undefined,
      due_from,
      due_to,
      is_system,
      insurance_line,
      sort_by,
      sort_dir,
      page,
      page_size,
    },
  })
  return res.data
}

export async function addTransaction(paymentItemId, payload) {
  const res = await http.post(`/installments/${paymentItemId}/transactions`, payload)
  return res.data
}

export async function listFollowups(paymentItemId) {
  const res = await http.get(`/installments/${paymentItemId}/followups`)
  return res.data
}

export async function createFollowup(paymentItemId, payload) {
  const res = await http.post(`/installments/${paymentItemId}/followups`, payload)
  return res.data
}


export async function listTransactions(paymentItemId) {
  const res = await http.get(`/installments/${paymentItemId}/transactions`)
  return res.data
}

export async function updateTransaction(transactionId, payload) {
  const res = await http.patch(`/installments/transactions/${transactionId}`, payload)
  return res.data
}

export async function deleteTransaction(transactionId) {
  const res = await http.delete(`/installments/transactions/${transactionId}`)
  return res.data
}

export async function uploadTransactionAttachment(transactionId, file) {
  const fd = new FormData()
  const raw = file?.originFileObj || file
  fd.append('file', raw, raw?.name || file?.name || 'file')
  // Do not set Content-Type manually; browser/axios will set proper boundary.
  const res = await http.post(`/installments/transactions/${transactionId}/attachments`, fd)
  return res.data
}

export async function listTransactionAttachments(transactionId) {
  const res = await http.get(`/installments/transactions/${transactionId}/attachments`)
  return res.data
}


export async function listPendingReceipts() {
  const res = await http.get('/installments/receipts/pending')
  return res.data
}

export async function reviewReceipt(transactionId, { status, note }) {
  const res = await http.patch(`/installments/transactions/${transactionId}/review`, null, {
    params: { status, note: note || undefined },
  })
  return res.data
}

export async function downloadReceiptAttachmentBlob(attachmentId) {
  const res = await http.get(`/installments/receipts/attachments/${attachmentId}`, { responseType: 'blob' })
  return res.data
}
