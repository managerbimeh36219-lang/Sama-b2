import { http } from './http.js'

export async function fetchRenewals({ q = '', status, insurance_line, sort_by, sort_dir, page, page_size } = {}) {
  const res = await http.get('/renewals', {
    params: {
      q: q || undefined,
      status: status || undefined,
      insurance_line: insurance_line || undefined,
      sort_by: sort_by || undefined,
      sort_dir: sort_dir || undefined,
      page,
      page_size,
    },
  })
  return res.data
}

export async function getRenewal(policyId) {
  const res = await http.get(`/renewals/${policyId}`)
  return res.data
}

export async function upsertRenewal(policyId, payload) {
  const res = await http.post(`/renewals/${policyId}`, payload)
  return res.data
}

export async function listRenewalFollowups(policyId) {
  const res = await http.get(`/renewals/${policyId}/followups`)
  return res.data
}

export async function createRenewalFollowup(policyId, payload) {
  const res = await http.post(`/renewals/${policyId}/followups`, payload)
  return res.data
}


export async function recomputeCreditScores(){
  const res = await http.post('/policies/recompute-credit-scores')
  return res.data
}
