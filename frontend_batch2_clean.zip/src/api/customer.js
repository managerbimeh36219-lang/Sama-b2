import http from './http'

export async function customerMe() {
  const { data } = await http.get('/customer/me')
  return data
}

export async function customerDashboard() {
  const { data } = await http.get('/customer/dashboard')
  return data
}

export async function customerPolicies() {
  const { data } = await http.get('/customer/policies')
  return data
}

export async function customerPolicyDetails(policyId) {
  const { data } = await http.get(`/customer/policies/${policyId}`)
  return data
}

export async function customerReceipts() {
  const { data } = await http.get('/customer/receipts')
  return data
}

export async function submitCustomerReceipt(paymentItemId, formData) {
  const { data } = await http.post(`/customer/installments/${paymentItemId}/submit-receipt`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
  return data
}

export async function requestPolicyRenewal(policyId, formData) {
  const { data } = await http.post(`/customer/policies/${policyId}/renewal-request`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  })
  return data
}

export async function downloadPolicyFile(policyId) {
  const res = await http.get(`/customer/policies/${policyId}/download`, { responseType: 'blob' })
  return res
}

// دریافت فایل رسید مشتری (برای پیش‌نمایش/دانلود در پنل مشتری)
export async function downloadCustomerReceipt(attachmentId) {
  const res = await http.get(`/customer/receipts/${attachmentId}`, { responseType: 'blob' })
  return res
}


export async function setCustomerPassword(password){
  const { data } = await http.post('/customer/set-password', { password })
  return data
}
