import { http } from './http.js'

export async function fetchDebts(params = {}) {
  const res = await http.get('/debts', { params })
  return res.data
}
