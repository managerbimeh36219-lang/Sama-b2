import { http } from './http'

export async function requestOtp(mobile){
  const { data } = await http.post('/auth/request-otp', { mobile })
  return data
}

export async function loginOtp(mobile, code){
  const { data } = await http.post('/auth/login-otp', { mobile, code })
  return data
}

export async function loginPassword(mobile, password){
  const { data } = await http.post('/auth/login-password', { mobile, password })
  return data
}

export async function me(){
  const { data } = await http.get('/auth/me')
  return data
}
