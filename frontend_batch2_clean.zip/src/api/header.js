import { http } from './http'

export async function getHeaderStats() {
  const { data } = await http.get('/header/stats')
  return data
}
