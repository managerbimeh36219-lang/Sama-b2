import { http } from './http.js'

export async function listSmsTemplates() {
  const res = await http.get('/installments/sms-templates')
  return res.data
}

export async function createSmsTemplate(payload) {
  const res = await http.post('/installments/sms-templates', payload)
  return res.data
}

export async function updateSmsTemplate(id, payload) {
  const res = await http.patch(`/installments/sms-templates/${id}`, payload)
  return res.data
}

export async function deleteSmsTemplate(id) {
  const res = await http.delete(`/installments/sms-templates/${id}`)
  return res.data
}
