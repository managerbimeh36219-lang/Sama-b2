import { http } from './http'

export async function listTasks(params = {}) {
  const { data } = await http.get('/tasks', { params })
  return data
}

export async function createTask(payload) {
  const { data } = await http.post('/tasks', payload)
  return data
}

export async function updateTask(id, payload) {
  const { data } = await http.patch(`/tasks/${id}`, payload)
  return data
}

export async function deleteTask(id) {
  const { data } = await http.delete(`/tasks/${id}`)
  return data
}

export async function listTaskAttachments(id) {
  const { data } = await http.get(`/tasks/${id}/attachments`)
  return data
}

export async function uploadTaskAttachment(id, file, kind = 'file') {
  const form = new FormData()
  const raw = file?.originFileObj || file
  form.append('file', raw, raw?.name || file?.name || 'file')
  const { data } = await http.post(`/tasks/${id}/attachments?kind=${encodeURIComponent(kind)}`, form)
  return data
}

export function getTaskAttachmentUrl(attachmentId) {
  return `/tasks/attachments/${attachmentId}`
}
